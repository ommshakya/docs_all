getwd()
setwd("D:\\01 01 0001 oms\\R.Learning")

if(!file.exists("course2"))
        dir.create("course2")


## Question 1 - starts
library(httr)
require(httpuv)
require(jsonlite)

oauth_endpoints("github")
myapp <- oauth_app("github", "b994d69fc10ee6c28be9", secret="3d9a8e714edba37260766c9a6cc9cdad8894a806")
myapp
github_token <- oauth2.0_token(oauth_endpoints("github"), myapp)
github_token
req <- GET("https://api.github.com/users/jtleek/repos", config(token = github_token))
req
stop_for_status(req)
output <- content(req)
output

jsondata <- fromJSON(toJSON(content(req)))
jsondata
list <- subset(jsondata, jsondata$name == "datasharing", select = c(created_at))
list

## Question 1 - ends

## Question 2 - starts
list.files("./course2")
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06pid.csv"
destfile <- "./course2/quiz2-AmericanCommunitySurvey_Q2.csv"
downData <- download.file(url, destfile)

acs <- read.csv(destfile, header = TRUE, sep = ",", quote = "\"")
head(acs)

library(sqldf)
sqldf("select pwgtp1 from acs where AGEP < 50")

## Question 2 - ends
## Question 3 - starts
sqldf("select distinct AGEP from acs")

## Question 3 - ends

## Question 4 - starts
connection <- url("http://biostat.jhsph.edu/~jleek/contact.html")
htmlCode <- readLines(connection)
close(connection)
nchar(htmlCode[10])
c(nchar(htmlCode[10]), nchar(htmlCode[20]), nchar(htmlCode[30]), nchar(htmlCode[100]))

#########OR## But it is not working at this time#############
require(httr)
require(XML)
htmlCode <- GET("http://biostat.jhsph.edu/~jleek/contact.html")
content <- content(htmlCode, as="text")
htmlParsed <- htmlParse(content, asText=TRUE)
htmlParsed[10]
xpathSApply(htmlParsed, "//title", xmlValue)


## Question 4 - ends

## Question 5 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fwksst8110.for"
lines <- readLines(url, n=10)
lines
w <- c(1, 9, 5, 4, 1, 3, 5, 4, 1, 3, 5, 4, 1, 3, 5, 4, 1, 3)
colNames <- c("filler", "week", "filler", "sstNino12", "filler", "sstaNino12", "filler", "sstNino3", "filler", "sstaNino3", "filler", "sstNino34", "filler", "sstaNino34", "filler", "sstNino4", "filler", "sstaNino4")
d <- read.fwf(url, w, header=FALSE, skip=4, col.names=colNames)
d <- d[, grep("^[^filler]", names(d))]
sum(d[, 4])

######OR########
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fwksst8110.for"
q5 <- read.fwf(file = url, skip = 4, widths = c(12, 7,4, 9,4, 9,4, 9,4))

# find the sum of forth column
sum(q5[, 4])

## Question 5 - ends