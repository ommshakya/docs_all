##Course 2 [Getting and Cleaning Data] -- Quiz 4 starts
getwd()
setwd("D:\\01 01 0001 oms\\R.Learning")

if(!file.exists("course2"))
        dir.create("course2")

## Question 1 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06hid.csv"
destfile <- "./course2/quiz4-AmericanCommunitySurvey.csv"
data <- download.file(url, destfile)
list.files("./course2")

data <- read.csv(destfile, header = TRUE, sep = ",", quote = "\"")

head(data)
str(data)
names(data)
splittedName <- strsplit(names(data),"wgtp")
splittedName[[123]]
## Question 1 - ends

## Question 2 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv"
destfile <- "./course2/quiz4-GrossDomesticProduct.csv"
data <- download.file(url, destfile)
list.files("./course2")

data <- read.csv(destfile, header = TRUE, sep = ",", quote = "\"",skip=4, nrows=190)
head(data)
str(data)
withoutCOmma <- gsub(",", "",data$X.4)
withoutCOmma <- as.numeric(withoutCOmma)
mean(withoutCOmma, na.rm = TRUE)

## Question 2 - ends

## Question 3 - starts
countryNames <- data$X.3
length(grep("^United",countryNames))
## Question 3 - ends

## Question 4 - starts
urlGDP <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv"
urlEDU <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FEDSTATS_Country.csv"
destfileGDP <- "./course2/quiz4-GDP.csv"
destfileEDU <- "./course2/quiz4-EDU.csv"
download.file(urlGDP, destfileGDP)
download.file(urlEDU, destfileEDU)

dataGDP <- read.csv(destfileGDP,skip=4,nrows=190)
dataEDU <- read.csv(destfileEDU)
str(dataGDP)
str(dataEDU)

dataMerged <- merge(dataGDP,dataEDU,by.x="X", by.y="CountryCode")
dataMerged$Special.Notes
FYJune <- grep('Fiscal year end: June', dataMerged$Special.Notes)
length(FYJune)

## Question 4 - ends

## Question 5 - starts
library(quantmod)
library(lubridate)
amzn = getSymbols("AMZN",auto.assign=FALSE)
sampleTimes = index(amzn)

year2012 <- grepl('2012-*', sampleTimes)
sampleTimes2012 <- subset(sampleTimes, year2012)
day <- format(sampleTimes2012, '%A')
table(day)
table(year2012)

addmargins(table(year(sampleTimes), weekdays(sampleTimes)))

## Question 5 - ends
