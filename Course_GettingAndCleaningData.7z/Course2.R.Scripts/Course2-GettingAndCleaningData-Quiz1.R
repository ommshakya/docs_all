##Course 2 [Getting and Cleaning Data] -- Quiz 1 starts
getwd()
setwd("D:\\01 01 0001 oms\\R.Learning")

if(!file.exists("course2"))
        dir.create("course2")

## Question 1 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06hid.csv"
destfile <- "./course2/quiz1-AmericanCommunitySurvey.csv"
data <- download.file(url, destfile)
list.files("./course2")

data <- read.csv(destfile, header = TRUE, sep = ",", quote = "\"")

head(data)
reqData <- data$VAL[data$VAL == 24 & !is.na(data$VAL)]
nrow(data.frame(reqData))
length(reqData)
## Question 1 - ends


## Question 3 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FDATA.gov_NGAP.xlsx"
destfile <- "./course2/quiz1-NaturalGasAquisition.xlsx"
data <- download.file(url, destfile, mode='wb')
list.files("./course2")
library(xlsx)

rowIndex = 18 : 23
colIndex = 7 : 15
dat <- read.xlsx(destfile, sheetIndex = 1, rowIndex = rowIndex, 
                 colIndex = colIndex, header = TRUE)
dat
sum(dat$Zip*dat$Ext,na.rm=T) 
## Question 3 - ends

## Question 4 - starts
fileUrl <- "http://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Frestaurants.xml"
library(XML)
doc <- xmlTreeParse(fileUrl, useInternal = TRUE)
rootNode <- xmlRoot(doc)
xmlName(rootNode)
names(rootNode)
rootNode[[1]][[1]][[2]]
## Question 4:

# Method 1: remove the letter "s" from "https", and use the "http" instead
library(XML)
fileUrl <- "http://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Frestaurants.xml"
doc <- xmlTreeParse(fileUrl, useInternal = TRUE)
rootNode <- xmlRoot(doc)

zip <- xpathSApply(rootNode, "//zipcode", xmlValue) == "21231"
zipData <- zip[zip == TRUE]
length(zipData)

## Question 4 - ends

## Question 5 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06pid.csv"
destfile <- "./course2/quiz1-2006MicrodataSurvey.csv"
data <- download.file(url, destfile)
list.files("./course2")

library(data.table)
DT <- fread(destfile)
#system.time(rowMeans(DT)[DT$SEX==1], rowMeans(DT)[DT$SEX==2])
system.time(mean(DT$pwgtp15,by=DT$SEX))
system.time(mean(DT[DT$SEX==1,]$pwgtp15), mean(DT[DT$SEX==2,]$pwgtp15))
system.time(sapply(split(DT$pwgtp15,DT$SEX),mean))
system.time(tapply(DT$pwgtp15,DT$SEX,mean))
system.time(DT[,mean(pwgtp15),by=SEX])

head(DT)
## Question 5 - ends