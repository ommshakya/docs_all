##Course 2 [Getting and Cleaning Data] -- Quiz 3 starts
getwd()
setwd("D:\\01 01 0001 oms\\R.Learning")

if(!file.exists("course2"))
        dir.create("course2")

## Question 1 - starts
url <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2Fss06hid.csv"
destfile <- "./course2/quiz3-AmericanCommunitySurvey.csv"
data <- download.file(url, destfile)
list.files("./course2")

data <- read.csv(destfile, header = TRUE, sep = ",", quote = "\"")

head(data)
agricultureLogical <- data$ACR == 3 & data$AGS == 6
which(agricultureLogical)[1:3]
## Question 1 - ends
## Question 2 - starts
library(jpeg)
urlImg <- "https://d396qusza40orc.cloudfront.net/getdata%2Fjeff.jpg"
f <- file.path(getwd(), "jeff.jpg")
download.file(urlImg, f, mode = "wb")
img <- readJPEG(f, native = TRUE)
quantile(img, probs = c(0.3, 0.8))

## Question 2 - ends

## Question 3 - starts
urlGDP <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FGDP.csv"
urlEDU <- "https://d396qusza40orc.cloudfront.net/getdata%2Fdata%2FEDSTATS_Country.csv"
destfileGDP <- "./course2/quiz3-GrossDomesticProduct.csv"
destfileEDU <- "./course2/quiz3-EducationalData.csv"
dataGDP <- download.file(urlGDP, destfileGDP)
dataEDU <- download.file(urlEDU, destfileEDU)
list.files("./course2")

dataGDP <- read.csv(destfileGDP, header = TRUE, sep = ",", quote = "\"")
dataEDU <- read.csv(destfileEDU, header = TRUE, sep = ",", quote = "\"")
dataGDP <- read.csv(destfileGDP, skip = 5, nrows = 190, stringsAsFactors = F, header = F)
dataEDU <- read.csv(destfileEDU, stringsAsFactors = F)
head(dataGDP)
str(dataEDU)

dataGDP <- dataGDP[, c(1, 2, 4, 5)]
colnames(dataGDP) <- c("CountryCode", "Rank", "Country.Name", "GDP.Value")
dataGDP$GDP.Value <- as.numeric(gsub(",", "", dataGDP$GDP.Value))

matchedData <- merge(dataGDP, dataEDU, by.x = "CountryCode", by.y = "CountryCode")
matchedData
dim(matchedData)[1]

library(plyr)
arrange(matchedData, desc(Rank))[13, 3]

## Question 3 - ends

## Question 4 - starts
mean(subset(matchedData, Income.Group %in% "High income: OECD", select = c(Rank))$Rank)
mean(subset(matchedData, Income.Group %in% "High income: nonOECD", select = c(Rank))$Rank)
## Question 4 - ends

## Question 5 - starts
library(Hmisc)
matchedData$Rank.Groups = cut2(matchedData$Rank, g = 5)
table(matchedData$Income.Group, matchedData$Rank.Groups)
## Question 5 - ends
