SELECT COUNT(*) FROM [dbo].[TB_ACCOUNT_DIM]
SELECT COUNT(*) FROM [dbo].[TB_CATEGORY_DIM]
SELECT COUNT(*) FROM [dbo].[TB_CONTRACT_DIM]
SELECT COUNT(*) FROM [dbo].[TB_COSTCENTER_DIM]
SELECT COUNT(*) FROM [dbo].[TB_GBPA_DIM]
SELECT COUNT(*) FROM [dbo].[TB_ITEM_DIM]
SELECT COUNT(*) FROM [dbo].[TB_PackagesLogHistory]
SELECT COUNT(*) FROM [dbo].[TB_PROCUREMENT_RAW_DATA]
SELECT COUNT(*) FROM [dbo].[TB_PROCUREMENT_RAW_DATA_ERRORS]
SELECT COUNT(*) FROM [dbo].[TB_PROCURESPEND_FACT]
SELECT COUNT(*) FROM [dbo].[TB_PROJECT_DIM]
SELECT COUNT(*) FROM [dbo].[TB_REQUESTOR_DIM]
SELECT COUNT(*) FROM [dbo].[TB_SUPPLIER_DIM]
SELECT COUNT(*) FROM [dbo].[TB_TGT_PROCUREMENT]

--TRUNCATE TABLE [dbo].[TB_ACCOUNT_DIM]
--TRUNCATE TABLE [dbo].[TB_CATEGORY_DIM]
--TRUNCATE TABLE [dbo].[TB_CONTRACT_DIM]
--TRUNCATE TABLE [dbo].[TB_COSTCENTER_DIM]
--TRUNCATE TABLE [dbo].[TB_GBPA_DIM]
--TRUNCATE TABLE [dbo].[TB_ITEM_DIM]
--TRUNCATE TABLE [dbo].[TB_PackagesLogHistory]
--TRUNCATE TABLE [dbo].[TB_PROCUREMENT_RAW_DATA]
--TRUNCATE TABLE [dbo].[TB_PROCUREMENT_RAW_DATA_ERRORS]
--TRUNCATE TABLE [dbo].[TB_PROCURESPEND_FACT]
--TRUNCATE TABLE [dbo].[TB_PROJECT_DIM]
--TRUNCATE TABLE [dbo].[TB_REQUESTOR_DIM]
--TRUNCATE TABLE [dbo].[TB_SUPPLIER_DIM]
--TRUNCATE TABLE [dbo].[TB_TGT_PROCUREMENT]


SELECT * FROM [dbo].[TB_PackagesLogHistory]



SELECT COUNT(*) FROM [dbo].[TB_PROCUREMENT_RAW_DATA]

SELECT COUNT(*) FROM (SELECT DISTINCT * FROM [dbo].[TB_PROCUREMENT_RAW_DATA]) AS t






SELECT COUNT(*)
FROM
(
	SELECT * FROM [dbo].[TB_TGT_PROCUREMENT]
) AS b


SELECT SUM(cnt) AS total FROM(

	SELECT COUNT(*) AS cnt FROM [dbo].[TB_TGT_PROCUREMENT]
	GROUP BY [PO NUMBER], [Requestor Name], [PO Account Number]
			, [PO Cost Centre], [Supplier Number], [Category 1]
			, [Category 2], [Category 3], [PO Line Num], [Invoice Number]
	HAVING COUNT(*) > 1

) AS A



SELECT * FROM [TB_TGT_PROCUREMENT] WHERE [PO NUMBER] = 35549136


SELECT SUM(cnt) AS total FROM(

	SELECT COUNT(*) AS cnt
	FROM [dbo].[TB_PROCUREMENT_RAW_DATA]
	WHERE 
	(
		([PO NUMBER]			IS NOT NULL AND LEN(LTRIM(RTRIM([PO NUMBER]))) <> 0)
		AND						    
		([Requestor Name]		IS NOT NULL AND LEN(LTRIM(RTRIM([Requestor Name]))) <> 0)
		AND						    
		([PO Account Number]	IS NOT NULL AND LEN(LTRIM(RTRIM([PO Account Number]))) <> 0)
		AND						    
		([PO Cost Centre]		IS NOT NULL AND LEN(LTRIM(RTRIM([PO Cost Centre]))) <> 0)
		AND						    
		([Supplier Number]		IS NOT NULL AND LEN(LTRIM(RTRIM([Supplier Number]))) <> 0)
		AND						    
		([Category 1]			IS NOT NULL AND LEN(LTRIM(RTRIM([Category 1]))) <> 0)
		AND						    
		([Category 2]			IS NOT NULL AND LEN(LTRIM(RTRIM([Category 2]))) <> 0)
		AND						    
		([Category 3]			IS NOT NULL AND LEN(LTRIM(RTRIM([Category 3]))) <> 0)
	)
	GROUP BY [PO NUMBER], [Requestor Name], [PO Account Number]
			, [PO Cost Centre], [Supplier Number], [Category 1]
			, [Category 2], [Category 3]
	HAVING COUNT(*) > 1

) AS A


SELECT DISTINCT 
	   [GBPA Number]
	  ,[GBPA]
	  ,[GBPA Limit]
	  --[GBPA End Date]
	  ,CASE WHEN [GBPA End Date] = '' OR LEN([GBPA End Date]) < 9 THEN NULL ELSE CAST([GBPA End Date] AS DATE) END AS [GBPA End Date]
FROM [dbo].[TB_TGT_PROCUREMENT]