--DECLARE @str_date AS VARCHAR(20) = '03 Jun 2017 1:2:3'
--DECLARE @str_date AS VARCHAR(20) = '03Jun2017 1:2:3'
--DECLARE @str_date AS VARCHAR(20) = '03/Jun/2017 1:2:3'
--DECLARE @str_date AS VARCHAR(20) = '03/Jun/2017'
--DECLARE @str_date AS VARCHAR(20) = '03-Jun-2017'
--SELECT PARSE(@str_date AS DATE)

--DECLARE @str_date AS VARCHAR(20) = '03/12/2017'
--DECLARE @str_date1 AS VARCHAR(20) = '12/03/2017'
--SELECT PARSE(@str_date AS DATE), PARSE(@str_date1 AS DATE)
--SELECT CAST(@str_date AS DATE),CAST(@str_date1 AS DATE)
--SELECT FORMAT(CAST(@str_date AS DATE), 'dd/MM/yyyy'),FORMAT(CAST(@str_date1 AS DATE), 'MM/dd/yyyy')


--DECLARE @str_date AS VARCHAR(20) = '2/3/2017'
DECLARE @str_date AS VARCHAR(20) = '16/07/2017'
----SELECT CONVERT(DATETIME,@str_date,120)
--SELECT PARSE(@str_date AS DATE), FORMAT(CAST(@str_date AS DATE), 'dd/MM/yyyy', 'en-gb'), FORMAT(CAST(@str_date AS DATE), 'MM/dd/yyyy', 'en-gb')
SELECT PARSE(@str_date AS DATE using 'en-gb'), 
FORMAT(@str_date, 'dd/MM/yyyy', 'en-gb'), FORMAT(CAST(@str_date AS DATE), 'MM/dd/yyyy', 'en-gb')