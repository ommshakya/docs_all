﻿SELECT COUNT(DISTINCT SKU) FROM TB_LOOSE_SKU




Project 1
We are developing an application for data manipulation, cleansing, standarizing and scheduling & automating the data modelling and loading into the Data Warehouse on 
SQL Server. I am working on to develop the core libraries to perform the data modelling also designing and developing the Windows Service & Windows application in C# on .Net framework 4.0. 
The backeded of this application is handled in the Microsoft SQL Server. 

Project 3
The objective of this project is to connect the PMS (Patient Monitoring System) devices (e.g. BioNet, Cardell, DigiCare, VetLand) and collect & send the data in real-time to 
the server for generating the reports to display on IPad native application. I designed the protocol for a PMS device and developed the complete application by implemented the 
complete flow by designing and developing the Windows Service & Windows Application in C# on .Net framework 4.0. The backeded of this application is handled in the Microsoft SQL Server.

Project 2
It is a medicine dispenser device that runs on TCP/IP protocol connected through the Internet network. The medicine doses of patient are scheduled through a web/native application and TLC device dispenses the medicines as per schedule.
I contributed to design the protocol specification and implemented the complete flow by designing and developing the Windows Service in C# on .Net framework 4.0. The backeded of this application is handled in the Microsoft SQL Server.

Project 1
It is a project to collect the files from the email and classifying the received files into the directories and uploading to a server. I designed & developed the Windows Service in C# on .Net framework 4.0. 
The backeded of this application is handled in the Microsoft SQL Server.
--------------------------

EXPERIENCES

Sr. Software Engineer: 5+ Yrs.

TECHNICAL SKILLS

Microsoft.Net | C# | LINQ | Ado.Net | Socket Programming | Windows Services | Windwows Application | Microsoft SQL Server 2008 R2, 2012, 2014 | 2016 | T-SQL Scripting | SSIS (Sql Server Integration Services) | ETL (Extract-Transform-Load) | Power BI | Python | R

CERTIFICATIONS/COURSES

•	"C# Intermediate: Classes, Interfaces and OOP" from Udemy
•	"Exam 70-461 : Querying Microsoft SQL Server 2012/2014" from Microsoft
•	"C# Advanced Topics: Take Your C# Skills to the Next Level" from Udemy
•	"Getting and Cleaning Data” from Coursera
•	"R Programming" from Coursera.
•	"R Programming: Advanced Analytics In R For Data Science" from Udemy
•	"R Programming A-Z™: R For Data Science With Real Exercises!" from Udemy
•	"Python A-Z™: Python For Data Science With Real Exercises!" from Udemy
•	"Data Analysis in Python with Pandas" from Udemy


SUMMARY

Having 5+ years of experience in object oriented database driven software applications in Microsoft Technologies. 

Design & development of C#.Net applications.
Creating Windows Services & Windows Applications.
Optimization, & troubleshooting & deployment of applications.
Design & development of databases, data modeling & data analyses.
Design & development, schedule & refresh of ETL packages in SSIS.
Requirement gathering & discussion and preparation of technical specifications.

Initially started my career as a VBA/Macro developer and explored it with .Net for 3.0 years.

EDUCATION

GGSIP UNIVERSITY NEW DELHI
MASTER OF COMPUTER APPLICATIONS
2008

-----------------------------------------------



THE SMART CUBE PVT. LTD. | SR. DOMAIN ANALYST | May. 2017 – present | Noida
Responsible for the following activities

	Developing database design and writing T-SQL scripts like SQL Queries, Stored procedures, Functions and query optimization.
	Developing ETL packages in SSIS to perform the ETL and data modelling and historical database preparation and SQL Agent Jobs scheduling.
	Optimization and troubleshooting of existing SSIS packages. 
	Hands on experience in creating Power BI, Tableau & SSRS Reports.
	Converting R data preparation scripts into T-SQL scripts and creating POCs in R.

CHETU INDIA PVT. LTD. | SR. SOFTWARE ENGINEER | Sep. 2013 – May. 2017 | Noida

	Worked with project owners and stack holders to implement the business requirements.
	Worked on database design, writing T-SQL scripts to implement the business logic and query optimization.
	Developed ETL packages in SSIS for ETL and data modelling and historical database storage.
	Developed reports and dashboards in Power BI, Tableau & SSRS. Managed Power BI Online portal.

UNIFY CLOUD PVT. LTD. | SOFTWARE ENGINEER | Dec. 2012 – Jul. 2013 | Noida

	Worked on to automate the product monitoring reports in C# console applications and a web interface in Asp.net.
	Worked on Microsoft SQL Server 2008 R2 and MS Excel 2010 and developing SQL Queries, Stored procedures, Functions to model the data for generating the reports for data visualizations and analyses in MS Excel.

DAMCO SOLUTIONS | SOFTWARE ENGINEER | Jul. 2010 – Nov. 2012 | Faridabad

	Developed the application components in VBA/macro for MS Access.

PROJECTS(Z-A)

@THE SMART CUBE 

PROJECT 1 (UK based client)
A second largest e-commerce company in retail domain. 

RESPONSIBILITY: Database modelling and designing, developing ETL packages, converting R scripts and other scripts into T-SQL scripts, refreshing data as per cycle, developing and refreshing the reports and dashboards.

Scheduling the ETL packages for automating the data loads, taking complete ownership for data refresh in both data storage and reporting, solving ad-hoc issues in multiple projects.
 
@CHETU INDIA PVT. LTD. 

PROJECT 4 (USA based client)
A cloud based Patient monitoring system services provider. 

RESPONSIBILITY: Requirement analyses, Database design, Creating ETL packages for performing the ETL operations, writing T-SQL scripts to retrieve the data and authoring the reports in Tableau. Collecting data from SQL Server, Flat Files, MongoDB sources.

PROJECT 3
This is the internal organization project to renovate the reports in Tableau. 

RESPONSIBILITY: Requirement analyses, performing the ETL operations in Tableau and authoring and publishing reports. Visualizing the data in Power BI Visuals like Bar, Line, Area, Column, Pie chart & tree & Geological maps, Table & Matrix and others.

PROJECT 2 (USA based consulting firm) 
A 3rd party vendor bringing data ware house, historical databases and data modelling.

RESPONSIBILITY: Requirement analyses, Working with data sources to perform the ETL operations using SSIS, data modelling data for preparing the consolidated databases.

PROJECT 1 (USA based client)
It is a US based financial product company providing the economic and financial analysis software products to various organizations and institutions in respective fields. 

RESPONSIBILITY: Requirement analyses, SSIS package development for data modelling & filling the OLAP database tables, writing T-SQL scripts for database objects creation & data retrieval and converting the MS Access sql queries into T-SQL queries.

@UNIFY CLOUD PVT. LTD.

PROJECT 1 
It is a product of the company that controls the Wi-Fi network within a building in collaboration of Aruba Network Server.

RESPONSIBILITY: Developing application for the automation of performance monitoring reports using the MS SQL, Excel & C#.

@ DAMCO SOLUTIONS PVT. LTD. (Responsible for VBA/Macro programming)
PROJECT 1 (USA based client) A desktop application in MS Access of a financial organization where various reports has to be generated based on some financial data. 

