﻿Om is a Senior Software Engineer Professional with 7.5 years of experience involving in full cycle software development. He has expertise in database oriented 
applications (Data Analyses & Desktop/Windows applications/services) in Microsoft & Open Source technologies. He is confident in reasearch & development of any new idea 
or concept. He is skilled to design, develop, deploy, maintain & automat the tasks/applications to acheive the business objectives by applying the object oriented programming (oop) concepts.

 Since last 4.5 years he is working on Microsoft SQL & .Net platform including SQL, SSIS, C#, Python tools and technologies. Prior to that for 2.5 years he worked 
 on Microsoft Visual Basic for Applications.

Roles and Responsibilities :

Design & Development of applications (Implementing the business logics)
Deployment & Maintenance of applications (Deploying & configuring the environment to run application)
Automation (Automating the application and it conponents to perform the routine or scheduled business jobs)
Data Analyses & Modelling (Preparing the Data warehouse and performing the data cleansing, data transpormation, data manipulation, data retreival, data visualization etc)


Core competencies/skills : 

Databases : Microsoft SQL Server, MongoDB
ETL tools & technologies : SSIS, Python, R 
Programming/scripting languages : C#, Python, R, Javascript
Data Visualization : SSRS, Power BI, Tableau


SQL -

- Database designing, T-SQL scripting to develop user defined functions, stored procedures, triggers, views.
- Debugging the stored procedure, complex queries , Query performance optimization using indexes and other techniques.

C#  -

- Writing the business logic with object oriented programming (oop) methodology to develop the applications
- Developing web & windows applications (web applications, desktop applications, windows services, console applications)
- Developing utilities, libraries and independent modules for simulation , proof of concepts (POCs)

SSIS - 

- Designing & development of SSIS package to perform the ETL (Extract, Transform, and Load) operations and deployment on SSIS Catalog & scheduling in SQL Server Agent Jobs.
- Debugging SSIS packages, logging, event handlers, improving the performance of SSIS packages.


Python/R -

- Writing the script for extracting the data from the data sources
- Writing the scripts to manipulat & trasform the data to prepare the data for reporting & analyses and loading the data.
- Developing proof of concepts (POCs) in Centre of Excellence.


Power BI/SSRS/Tableau - 

- Authoring, publishing and sharing the reports & dashboards with interactive data visuals.
- Scheduling & refreshing the report data, managing the Auto refresh schedule & Power BI Personal Gateway.





---------CONFIDENTIAL------------
Working on to develop an application in Microsoft .Net & SQL technology
The objective is to develop an application to perform the common data transformations & manipulations and to do data modelling and to laod the data into the data warehouse/data mart.
 
 Designing & developing an application in Microsoft .Net & SQL technology
 Designing, developing database, data warehouse & writing T-SQL scripts like SQL Queries, Stored procedures, Functions and query optimization.
 Designing & developing ETL packages in SSIS to perform the ETL operations and Optimizating & troubleshooting of existing SSIS packages.
 Writing scripts in Python for data manipulation & data analyses.

------------CHETU--------------

Developed the applications in Microsoft .Net & SQL technology for simulating the Patient Monitoring Devices, realtime data extraction and loading using TCP/IP Socket programming.
Created proof of concepts (POCs) in the form of windows applications/services and console applications.
Designed & developed databases, data warehouses, data marts, ETL packages for performing ETL operations.
Optimized SQL queries, stored procedures, SSIS packages.

