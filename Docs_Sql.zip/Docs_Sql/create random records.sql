--=============================================================================
--      Author:  Jeff Moden
--      Create the test data.  
--      Usually takes something less than 12 seconds to generate.
--=============================================================================
--===== Conditionally drop the test table to make reruns easier.
     IF OBJECT_ID('tempdb..#MyHead','U') IS NOT NULL
        DROP TABLE #MyHead
;
GO
--===== Create the table and populate it on the fly.
     -- This builds a table with random dates and amounts for 20 years starting
     -- in the year 2000.
 SELECT TOP (5000000) --This is the number of rows inserted.
        SomeDateTime = RAND(CHECKSUM(NEWID()))*7305 + CAST('2005' AS DATETIME),
        SomeAmount   = CAST(RAND(CHECKSUM(NEWID()))*100 AS MONEY)
       ,SomeDecimal = CAST(RAND(CHECKSUM(NEWID()))*100 AS DECIMAL(8,2))
       ,SomeInteger = CAST(RAND(CHECKSUM(NEWID()))*100 AS INT)
       ,SomeVarchar =CAST(RAND(CHECKSUM(NEWID()))*100 AS VARCHAR(50))
   INTO #MyHead
   FROM master.sys.all_columns ac1
  CROSS JOIN master.sys.all_columns ac2
;
--===== Add a clustered index to the table just to keep it from being a heap
     -- and to help with speed a bit by sorting the data.
 CREATE CLUSTERED INDEX IX_#MyHead_SomeDateTime
     ON #MyHead (SomeDateTime)
;

SELECT * FROM #MyHead --Just to check to make sure it worked


