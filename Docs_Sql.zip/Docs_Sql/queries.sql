--1.
CREATE TABLE #TEMP_T1
(
ID INT
)

CREATE TABLE #TEMP_T2
(
ID INT
)

INSERT INTO #TEMP_T1 VALUES (1),(2),(3),(4),(5)
INSERT INTO #TEMP_T2 VALUES (2),(2),(3),(NULL)

SELECT * FROM #TEMP_T1 WHERE ID NOT IN (SELECT ID FROM #TEMP_T2)
SELECT * FROM #TEMP_T1 WHERE ID NOT IN (SELECT ID FROM #TEMP_T2 WHERE ID IS NOT NULL)

--2.
CREATE TABLE #TEMP_CUST
(
ID INT,
CUST_ID VARCHAR(20)
)

INSERT INTO #TEMP_CUST VALUES (7, '100')
						   ,(8, '200')
						   ,(9, '300')
						   ,(10, '400')


SELECT * FROM #TEMP_CUST
SELECT COUNT(*) FROM #TEMP_CUST
SELECT COUNT(*) FROM #TEMP_CUST WHERE CUST_ID = '100'
SELECT COUNT(*) FROM #TEMP_CUST WHERE CUST_ID <> '100'

--3.
CREATE TABLE dbo.envelope(id int, user_id int);
CREATE TABLE dbo.docs(idnum int, pageseq int, doctext varchar(100));

INSERT INTO dbo.envelope VALUES
  (1,1),
  (2,2),
  (3,3);

INSERT INTO dbo.docs(idnum,pageseq) VALUES
  (1,5),
  (2,6),
  (null,0);

SELECT * FROM envelope
SELECT * FROM docs

UPDATE docs SET doctext=pageseq FROM docs INNER JOIN envelope ON envelope.id=docs.idnum
WHERE EXISTS (
  SELECT 1 FROM dbo.docs
  WHERE id=envelope.id
);

SELECT * FROM docs

--4.


SELECT 'A' as RESULT -- *--CUST_ID, COUNT(*)
FROM #TEMP_CUST
--GROUP BY CUST_ID
HAVING MIN(CAST(CUST_ID AS INT)) < MAX(CAST('200' AS INT))

SELECT COUNT(CUST_ID)
FROM #TEMP_CUST
HAVING CUST_ID < MAX(CAST(CUST_ID AS INT))


SELECT SUM(CAST(CUST_ID AS INT)) as totSpending
FROM #TEMP_CUST
HAVING SUM(CAST(CUST_ID AS INT)) >= 1000;

--5.

SELECT CUST_ID 
FROM #TEMP_CUST

SELECT CUST_ID + ';'
FROM #TEMP_CUST
FOR XML PATH('')

--OR

SELECT STRING_AGG(CUST_ID, ';') -- CUST_ID + ';'
FROM #TEMP_CUST

--6.

SELECT CUST_ID FROM #TEMP_CUST ORDER BY 2 DESC

--7.


SELECT * FROM docs


BEGIN TRAN
TRUNCATE TABLE docs
SELECT * FROM docs
ROLLBACK
SELECT * FROM docs

--8.
SELECT value from string_split('INDIA',' ')

--9.
SELECT SUM(1) FROM docs
SELECT SUM(2) FROM docs
SELECT SUM(3) FROM docs

--10.
CREATE TABLE #TEMP_COLOR
(
ID INT IDENTITY(1,1)
,C1 VARCHAR(20)
,C2 VARCHAR(20)
,C3 VARCHAR(20)
)

INSERT INTO #TEMP_COLOR VALUES ('RED','BLACK','GREEN')
							  ,('YELLO','BLACK','RED')
							  ,('BLUE','BLACK','WHITE')

SELECT * FROM #TEMP_COLOR WHERE 'RED' IN (C1, C2, C3)

--11. How do you get the last id without the max function?

select top 1 id from table order by id desc

--12.
DROP TABLE #TEMP_SALARY
CREATE TABLE #TEMP_SALARY
(
	ID INT IDENTITY(1,1)
	,[NAME] VARCHAR(20)
	,SALARY INT
)
INSERT INTO #TEMP_SALARY VALUES
 ('A',900)
,('Z',950)
,('P',500)
,('B',500)
,('L',650)

SELECT ID, [NAME], SALARY, ROW_NUMBER() OVER(ORDER BY SALARY DESC) AS RN
FROM #TEMP_SALARY

--13.
--If values are unique in table -- 3rd highest salary

SELECT SALARY from #TEMP_SALARY order by SALARY DESC
OFFSET 2 ROWS
FETCH NEXT 1 ROW ONLY

-- OR
-- If values are not unique -- 3rd highest salary
SELECT DISTINCT SALARY from #TEMP_SALARY order by SALARY DESC
OFFSET 2 ROWS
FETCH NEXT 1 ROW ONLY


--14.

DECLARE @DECIMAL_VALUE NUMERIC(18,4) = 4215.254
SELECT @DECIMAL_VALUE, CAST(@DECIMAL_VALUE AS INT), @DECIMAL_VALUE - CAST(@DECIMAL_VALUE AS INT)

--OR

CREATE TABLE #tbl_sample
(
 [Col_ID] INT,
 [Col_Decimal] decimal(18,4)
)
GO
INSERT INTO #tbl_sample VALUES (1,12345.9876)
INSERT INTO #tbl_sample VALUES (2,-12345.9876)
INSERT INTO #tbl_sample VALUES (3,123.45)
INSERT INTO #tbl_sample VALUES (4,12.90)
GO

SELECT [Col_ID], [Col_Decimal], CAST([Col_Decimal] AS INT),  [Col_Decimal] % 1
FROM #tbl_sample

--15.


CREATE TABLE #EMP
(
emp_id int,
emp_name varchar(50),
salary int,
manager_id int
)
INSERT INTO #EMP VALUES 
(10, 'Anil', 50000, 18),
(11, 'Vikas', 75000, 16),
(12, 'Nisha', 40000, 18),
(13, 'Nidhi', 60000, 17),
(14, 'Priya', 80000, 18),
(15, 'Mohit', 45000, 18),
(16, 'Rajesh', 90000, NULL),
(17, 'Raman', 55000, 16),
(18, 'Santosh', 65000, 17)

SELECT * FROM #EMP

SELECT manager_id, AVG(salary)
FROM #EMP
WHERE manager_id IS NOT NULL
GROUP BY manager_id
