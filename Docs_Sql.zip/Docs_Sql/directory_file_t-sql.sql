EXEC
master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE

EXEC
master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE
/*-----------------*/
DECLARE @cmd nvarchar(500), @folderName varchar(100),@move varchar(100),@destinationpath varchar(50)

SET @folderName = 'Newfolder_' + REPLACE(CONVERT(varchar(10), GETDATE(), 101), '/', '') 

SET @cmd = 'mkdir D:\oms\' + @folderName

EXEC master..xp_cmdshell @cmd   --- this will create folder(newfolder_mmddyyy)

set @destinationpath='D:\oms\'+@folderName 
set @move ='move d:\source\* '+ @destinationpath

exec master.dbo.xp_cmdshell @move  ---this will move files to newly created folder

/*-----------*/
declare @inpath varchar(100)
SET @inpath = 'move "\\abcdef\INPUT\input*.csv" "\\abcdef\ARCHIVE\archive.csv"'
EXEC @filestatus = master..xp_cmdshell @inpath



declare @inpath varchar(100), @filestatus varchar(200)
SET @inpath = 'move "d:\source\iris.csv" "d:\oms\iris_arc.csv"'
EXEC @filestatus = master..xp_cmdshell @inpath

/*
DECLARE
 @TodayDate as varchar(40),
 @TodayHour as varchar(40),
 @TodayMinu  as varchar(40),
 @NewFileName as varchar(100),
 @cmdstr as varchar(128),
 @cmd VARCHAR(255),
 @sFileName AS VARCHAR(255),
 @sPath AS VARCHAR(255)
 
 SET @sFileName = 'EandWTest.txt'
 SET @sPath = 'C:\Auto Import\Auto Import\'
 
 SELECT @TodayDate = CONVERT(varchar(10), GETDATE(), 112)
 SELECT @TodayHour = DATEPART(hh,GETDATE())
 SELECT @TodayMinu = DATEPART(mi,GETDATE())
 SELECT @NewFileName = @sFileName + '_' + @TodayDate + '_' + @TodayHour + '_' + @TodayMinu + '.txt'
 print @NewFileName
 set @cmdstr='MOVE /Y C:\Auto Import\Auto Import\EandWTest.txt C:\Auto Import\Auto Import\Archive\'  + @NewFileName  
 print @cmdstr
 EXEC master..xp_cmdshell @cmdstr
 
*/


--Script 1: Determine if Directory Exists
 
DECLARE @FullDirectoryPathStatement VARCHAR(255)
--Test... This one does NOT exist on my system
--SET @FullDirectoryPathStatement = 'DIR "C:\Program Files\Microsoft SQL Server\BrianKMcDonald\BigMacFilletOFishQuarterPounderFrenchFries" /B'
 
--Test... This one does exist on my system
SET @FullDirectoryPathStatement = 'DIR "C:\Program Files\Microsoft SQL Server" /B'
 
CREATE TABLE #DirectoryExists (IsValid VARCHAR(MAX))
INSERT INTO #DirectoryExists
EXEC xp_cmdshell @FullDirectoryPathStatement
 
SELECT * FROM #DirectoryExists

DECLARE @Exists SMALLINT = 0
SELECT @Exists =
      (SELECT COUNT(IsValid) FROM #DirectoryExists
      WHERE IsValid <> 'File Not Found' AND IsValid IS NOT NULL)
 
IF @Exists = 0
            SELECT 'DIRECTORY DOES NOT EXIST!'
ELSE
            SELECT 'DIRECTORY EXISTS!'
 
DROP TABLE #DirectoryExists


-------------------------------------------
/*Enable the functionality of file processing*/
EXEC
master.dbo.sp_configure 'show advanced options', 1
RECONFIGURE

EXEC
master.dbo.sp_configure 'xp_cmdshell', 1
RECONFIGURE


/*
Script 1 :
Move the specified file to the archive folder*/
DECLARE @inpath VARCHAR(100), 
		@filestatus VARCHAR(200)
SET @inpath = 'move "d:\source\iris.csv" "d:\destination\iris_arc.csv"'
EXEC MASTER..xp_cmdshell @inpath--, NO_OUTPUT


/*
Script 2 :
Create the archive folder and move all the files from source to archive folder*/
DECLARE @cmd nvarchar(500), 
		@folderName varchar(100),
		@move varchar(100),
		@destinationpath varchar(50)

--Make the name of the archive folder
SET @folderName = 'Newfolder_' + REPLACE(CONVERT(varchar(10), GETDATE(), 101), '/', '') 

--Create the archive folder
SET @cmd = 'mkdir D:\destination\' + @folderName
EXEC MASTER..xp_cmdshell @cmd

--Move all the files from source to archive folder
SET @destinationpath='D:\destination\'+@folderName 
SET @move ='move d:\source\* '+ @destinationpath
EXEC MASTER.dbo.xp_cmdshell @move 
-------------------------------------------