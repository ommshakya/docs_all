Create View vw_WeekdaysList
AS
------ Create on the fly CTE Table
with CurrentDay as
(
select NameDay=DATENAME(DW,getdate()), WeekDay=DATEPART(dw, getdate())
union all
select NameDay=DATENAME(DW,getdate()+WeekDay),
WeekDay=DATEPART(dw, getdate()+WeekDay)
from CurrentDay
----- set weekday conditions
where WeekDay<7
)

------ Pull Data From CTE Table: CurrentDay
select Top 100 percent
NameDay, WeekDay,
---- Set flag 1 for current day
CurrentDay=IIF(WeekDay=DATEPART(dw, getdate()),1,0) 
from CurrentDay
order by WeekDay