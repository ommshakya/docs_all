﻿with cte
AS
(
	SELECT 1 as seq
	UNION ALL
	SELECT seq + 1 FROM cte where seq < 100
)
--SELECT * FROM cte
SELECT top 2 * FROM cte order by NEWID()

DECLARE @ctr INT = 0
WHILE (@CTR < 100)
BEGIN
	SELECT @CTR = @ctr + 1
	PRINT @ctr
END


DECLARE @STR VARCHAR(20) = 'OMPRAKASH'
SELECT REPLACE(@STR, 'A', '')
SELECT LEN(REPLACE(@STR, 'A', ''))
SELECT LEN(@STR) - LEN(REPLACE(@STR, 'A', ''))

SELECT * FROM
(
	SELECT 1 AS A
	UNION ALL
	SELECT 2 AS B
) AS M

SELECT SUM(A) FROM
(
	SELECT 1 AS A
	UNION ALL
	SELECT NULL AS B
) AS M

SELECT 5 / 2
SELECT 5 / CAST(2 AS FLOAT)

DECLARE  @TBL1 TABLE
(
	NAME VARCHAR(10)
)
DECLARE  @TBL2 TABLE
(
	NAME VARCHAR(10)
)
INSERT INTO @TBL1 VALUES ('OM'), ('')
INSERT INTO @TBL2 VALUES ('')
SELECT * FROM @TBL1 A INNER JOIN @TBL2 B ON A.NAME = B.NAME

DECLARE @VAL INT = 10
SELECT CASE WHEN 10/2 = 5 THEN 'IT IS 1' 
			WHEN 10*2/4 = 5 THEN 'IT IS 2'
		END AS NAME


CREATE TABLE tblCity
(
cityid int identity(1,1)
,cityname varchar(50)
)

insert into tblCity (cityname) values ('gurgaon')
go 999990
insert into tblCity (cityname) values ('new york')
go 10

select top 10 * from tblcity where cityname = 'gurgaon'


select top 10 * from tblcity where cityname = 'new york'


SELECT name, description  
FROM fn_helpcollations(); 

select 5 + null
select select 'om'

SELECT COUNT(*) FROM tblCity

if (null = null)
print 'true'
else
print 'false'

declare @val nvarchar(20)
set @val = N'राजनीतिक'
select @val



DECLARE  @TBL1 TABLE
(
	id int
)
INSERT INTO @TBL1 VALUES (1), (2), (3), (4), (5)
select * from @TBL1
update @tbl1 set id = id + (select max(id) from @TBL1)
select count(select id from @TBL1)




select 0/9

select 1 where null = null

