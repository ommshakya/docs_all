
/* 
Declare filter variables
*/

DECLARE @start_week INT = NULL;
DECLARE @end_week INT = NULL;
DECLARE @loc_trait_id INT = NULL;

/*
WORKING ON TO THESE VARIABLES
*/

DECLARE @pre_christ_wk VARCHAR(200) = '201440,201540,201641'
DECLARE @christ_wk VARCHAR(200) = '201441,201541,201642'
DECLARE @post_christ_wk VARCHAR(200) = '201442,201542,201643'
DECLARE @pre_Easter_wk VARCHAR(200) = '201503,201602,201705'
DECLARE @Easter_wk VARCHAR(200) = '201504,201603,201706'
DECLARE @post_Easter_wk VARCHAR(200) = '201505,201604,201707'

/*
Initialize the variables
*/

SET @start_week = 201509;
SET @end_week = 201708;
SET @loc_trait_id = 6101;

/*------------------------------------Part 1 & 2 Starts--------------------------------------*/

/*
Read the data of Ph2 from stagging and convert column data types
*/
IF OBJECT_ID('TempDB.dbo.#tmpOriginalPh2') IS NOT NULL
	DROP TABLE #tmpOriginalPh2

SELECT CAST([store_no] AS INT) AS [store_id]
      ,CAST([section_id] AS INT) AS [section_id]
	  ,CAST([floorplan_version] AS INT) AS [fp_version]
      ,CAST([SKU_Number] AS INT) AS [SKU_Number]
      ,[FP_message]
      ,CONVERT(DATE, [date_from],106) AS [date_from]
INTO #tmpOriginalPh2
FROM [CommercialPIR].[dbo].[TB_STG_JDA_PHASE2]

PRINT '#tmpOriginalPh2'

/*Check the table #tmpOriginalPh2 */
--SELECT * FROM #tmpOriginalPh2

/*
Read the data of Ph1 from stagging and convert columns data types
*/
IF OBJECT_ID('TempDB.dbo.#tmpOriginalPh1') IS NOT NULL
	DROP TABLE #tmpOriginalPh1

SELECT CAST([Store_Num] AS INT) AS [store_id]
      ,CAST([Section_Num] AS INT) AS [section_id]
      ,CAST([FP_Version] AS INT) AS [fp_version]
	  ,CAST([FP_Status] AS INT) AS [FP_Status]
      ,[Store_Name]
      ,CONVERT(DATE, SUBSTRING([Date_From],0,8),106) AS [date_from]
      ,[POG_Name]
      ,[Section_Name]
      ,CAST([Section_Width] AS FLOAT) AS [Section_Width]
      ,CAST([NumberOfProductsAllocated] AS INT) AS [NumberOfProductsAllocated]
      ,CONVERT(DATE, SUBSTRING([date1],0,8), 10) AS [date1]
      ,CONVERT(DATE, SUBSTRING([DBDateEffectiveFrom],0,8), 10) AS [DBDateEffectiveFrom]
      ,CONVERT(VARCHAR, CONVERT(DATE, SUBSTRING([date1],0,8),106),106) AS [POG_Live]
      ,[POG_Change_Type]
      ,CAST([POG_Width] AS FLOAT) AS [POG_Width]
      ,[Position]
      ,CAST([x] AS FLOAT) AS [x]
      ,CAST([y] AS FLOAT) AS [y]
      ,[FP_Depth]
      ,[FP_Width]
INTO #tmpOriginalPh1
FROM [CommercialPIR].[dbo].[TB_STG_JDA_PHASE1]
WHERE [FP_Status] IN (1,4)

PRINT '#tmpOriginalPh1'

/*Check the table #tmpOriginalPh1 */  
--SELECT * FROM #tmpOriginalPh1

/*
Apply the checks on Ph2 data forming final Ph2 data keep the maximum date_from and max fp_version
*/
IF OBJECT_ID('TempDB.dbo.#tmpPH2') IS NOT NULL
	DROP TABLE #tmpPH2

SELECT A.store_id
	  ,A.section_id
	  ,fp_version
	  ,SKU_Number
	  ,date_from
	  ,Maxfloorplan_version
	  ,MaxDateFromPh2
INTO #tmpPH2
FROM #tmpOriginalPh2 AS A
INNER JOIN 
(
	--Apply check : Max(FP - floorplan_version) on PH2  (CHECK-3)
	SELECT store_id
		  ,MaxDateFromPh2
		  ,Max([fp_version]) AS Maxfloorplan_version
	FROM
	(
		--Apply check : Max(Date From) on PH2 (CHECK-2)
		SELECT [store_id]
			  ,[fp_version]
			  ,Max([date_from]) AS MaxDateFromPh2
		FROM #tmpOriginalPh2
		GROUP BY [store_id]
				,[fp_version]

	) AS qPh2
	GROUP BY [store_id]
			,MaxDateFromPh2
) AS B
ON A.[store_id] = B.[store_id] 
AND A.[fp_version] = B.Maxfloorplan_version
AND A.[date_from] = B.MaxDateFromPh2


PRINT '#tmpPH2'
--SELECT * FROM #tmpPH2

/*
Apply the checks on Ph1 data forming final Ph1 data
*/
IF OBJECT_ID('TempDB.dbo.#tmpPH1') IS NOT NULL
	DROP TABLE #tmpPH1

SELECT q1.store_id
	  ,BB.section_id
	  ,q1.Max_FP_Version AS fp_version
	  ,q1.MaxDateFromPh1
	  ,BB.date_from
	  ,BB.date1
	  ,BB.x
	  ,BB.y
	  ,BB.Section_Width
	  ,BB.[POG_Name]
	  ,BB.[POG_Width]
	  ,BB.[POG_Change_Type]
	  ,BB.[NumberOfProductsAllocated] 
	  ,BB.FP_Status
INTO #tmpPH1
FROM
(
	SELECT * FROM
	(
		--Apply check : Max(date1) on PH1 (CHECK-4)
		SELECT store_id
				,MAX([FP_Version]) AS Max_FP_Version
				,MaxDateFromPh1
		FROM
		(
			--Apply check : Max(Date From) on PH1 (CHECK-2)
			SELECT store_id
				,[FP_Version]
				,Max([Date_From])  AS MaxDateFromPh1
			FROM #tmpOriginalPh1
			group by store_id, [FP_Version]
		) AS q
		GROUP BY store_id, MaxDateFromPh1
	) AS AA
) AS q1
INNER JOIN
	#tmpOriginalPh1 AS BB
ON q1.store_id = BB.store_id
AND q1.Max_FP_Version = BB.fp_version
AND q1.MaxDateFromPh1 = BB.date_from


PRINT '#tmpPH1'
--SELECT * FROM #tmpPH1


/*
Join PH2 & PH1 Data, Get the X,Y coordinates
*/
IF OBJECT_ID('TempDB.dbo.#tmpPh1Ph2XY') IS NOT NULL
	DROP TABLE #tmpPh1Ph2XY

SELECT DISTINCT ph2.store_id
	  ,ph2.section_id
	  ,ph2.fp_version
	  ,ph2.MaxDateFromPh2
	  ,x
	  ,y
INTO #tmpPh1Ph2XY
FROM #tmpPH2 AS ph2
INNER JOIN #tmpPH1 AS ph1
ON  ph2.store_id = ph1.store_id
AND ph2.section_id = ph1.section_id
AND ph2.fp_version = ph1.fp_version

PRINT '#tmpPh1Ph2XY'
--SELECT * FROM #tmpPh1Ph2XY

/*
Calculate xcount and ycount of floor values
*/

IF OBJECT_ID('TempDB.dbo.#tmpXcount') IS NOT NULL
	DROP TABLE #tmpXcount

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,COUNT(FLOOR(x)) AS xcount
	  ,FLOOR(x) AS xfloor
INTO #tmpXcount
FROM #tmpPh1Ph2XY
GROUP BY store_id, section_id, fp_version, FLOOR(x)

PRINT '#tmpXcount'
--SELECT * FROM #tmpXcount

IF OBJECT_ID('TempDB.dbo.#tmpYcount') IS NOT NULL
	DROP TABLE #tmpYcount

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,COUNT(FLOOR(y)) AS ycount
	  ,FLOOR(y) AS yfloor
INTO #tmpYcount
FROM #tmpPh1Ph2XY
GROUP BY store_id,section_id, fp_version , FLOOR(y)

PRINT '#tmpYcount'
--SELECT * FROM #tmpYcount

/*
Get MaxXcount, MaxYcount and combine them, display them
*/
IF OBJECT_ID('TempDB.dbo.#tmpXYcounts') IS NOT NULL
	DROP TABLE #tmpXYcounts

SELECT xcnt.store_id
	  ,xcnt.section_id
	  ,xcnt.fp_version
	  ,xcnt.MaxXCount
	  ,ycnt.MaxYCount
INTO #tmpXYcounts
FROM
(
	SELECT store_id, section_id, fp_version,  Max(xcount) AS MaxXCount
	FROM #tmpXcount
	GROUP BY store_id, section_id, fp_version
) AS xcnt
INNER JOIN 
(
	SELECT store_id, section_id, fp_version,  Max(ycount) AS MaxYCount
	FROM #tmpYcount
	GROUP BY store_id, section_id, fp_version
) AS ycnt
ON xcnt.store_id = ycnt.store_id
AND xcnt.section_id = ycnt.section_id
AND xcnt.fp_version = ycnt.fp_version


PRINT '#tmpXYcounts'
--SELECT * FROM #tmpXYcounts

/*
Calculate MeanOfX, ModeOfX
NOTE: THE LOGIC FOR MEAN AND MODE NEED TO BE VERIFIED, display them
*/


--SELECT * FROM #tmpXcount

IF OBJECT_ID('TempDB.dbo.#tmpMeanX') IS NOT NULL
	DROP TABLE #tmpMeanX

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version
	  --,AVG(xfloor) OVER ( PARTITION BY store_id, section_id, fp_version  ORDER BY store_id, section_id, fp_version) AS MeanX
	  ,Percentile_Cont(0.50) WITHIN GROUP(Order By xfloor) OVER(PARTITION BY store_id, section_id, fp_version ) As MeanX --ORDER BY store_id, section_id, fp_version
INTO #tmpMeanX
FROM #tmpXcount


PRINT '#tmpMeanX'

IF OBJECT_ID('TempDB.dbo.#tmpModeX') IS NOT NULL
	DROP TABLE #tmpModeX


SELECT a.store_id, a.section_id, a.fp_version, MIN(a.xfloor) AS ModeX  
INTO #tmpModeX
FROM #tmpXcount AS a
INNER JOIN 
(
	SELECT store_id, section_id, fp_version,  MAX(xcount) AS MaxX
	FROM #tmpXcount
	GROUP BY store_id, section_id, fp_version
) AS b
ON a.store_id =b.store_id
AND a.section_id = b.section_id
AND a.fp_version = b.fp_version
WHERE b.MaxX = a.xcount
GROUP BY a.store_id, a.section_id, a.fp_version

PRINT '#tmpModeX'
--SELECT * FROM #tmpModeX

IF OBJECT_ID('TempDB.dbo.#tmpMeanModeX') IS NOT NULL
	DROP TABLE #tmpMeanModeX

SELECT A.store_id
	  ,A.section_id
	  ,A.fp_version
	  ,A.MeanX
	  ,B.ModeX
INTO #tmpMeanModeX
FROM #tmpMeanX AS A
INNER JOIN  #tmpModeX AS B
ON A.store_id = B.store_id
AND A.section_id = B.section_id
AND A.fp_version = B.fp_version

PRINT '#tmpMeanModeX'
--SELECT * FROM #tmpMeanModeX

/*
Calculate MeanOfY, ModeOfY
NOTE: THE LOGIC FOR MEAN AND MODE NEED TO BE VERIFIED, display them
*/

IF OBJECT_ID('TempDB.dbo.#tmpMeanY') IS NOT NULL
	DROP TABLE #tmpMeanY

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version 
	  --,AVG(yfloor) OVER ( PARTITION BY store_id, section_id, fp_version  ORDER BY store_id, section_id, fp_version) AS MeanY
	  ,Percentile_Cont(0.50) WITHIN GROUP(Order By yfloor) OVER(PARTITION BY store_id, section_id, fp_version ) As MeanY -- ORDER BY store_id, section_id, fp_version
INTO #tmpMeanY
FROM #tmpYcount

PRINT '#tmpMeanY'

IF OBJECT_ID('TempDB.dbo.#tmpModeY') IS NOT NULL
	DROP TABLE #tmpModeY

SELECT DISTINCT a.store_id, a.section_id, a.fp_version, MIN(a.yfloor) AS ModeY  
INTO #tmpModeY
FROM #tmpYcount a
INNER JOIN 
(
	SELECT store_id, section_id, fp_version,  MAX(ycount) AS MaxY
	FROM #tmpYcount 
	GROUP BY store_id, section_id, fp_version
) AS b
ON a.store_id =b.store_id
AND a.section_id = b.section_id
AND a.fp_version = b.fp_version
WHERE b.MaxY = a.ycount 
GROUP BY a.store_id, a.section_id, a.fp_version


PRINT '#tmpModeY'
--SELECT * FROM #tmpModeY


IF OBJECT_ID('TempDB.dbo.#tmpMeanModeY') IS NOT NULL
	DROP TABLE #tmpMeanModeY

SELECT A.store_id
	  ,A.section_id
	  ,A.fp_version
	  ,A.MeanY
	  ,B.ModeY
INTO #tmpMeanModeY
FROM #tmpMeanY AS A
INNER JOIN  #tmpModeY AS B
ON A.store_id = B.store_id
AND A.section_id = B.section_id
AND A.fp_version = B.fp_version

PRINT '#tmpMeanModeY'
--SELECT * FROM #tmpMeanModeY

/*
Combine Mean and Mode of X and y
*/

IF OBJECT_ID('TempDB.dbo.#tmpMeanModeXY') IS NOT NULL
	DROP TABLE #tmpMeanModeXY

SELECT A.store_id
	  ,A.section_id
	  ,A.fp_version
	  ,A.MeanX
	  ,A.ModeX
	  ,B.MeanY
	  ,B.ModeY
INTO #tmpMeanModeXY
FROM #tmpMeanModeX AS A
INNER JOIN  #tmpMeanModeY AS B
ON A.store_id = B.store_id
AND A.section_id = B.section_id
AND A.fp_version = B.fp_version

PRINT '#tmpMeanModeXY'
--SELECT * FROM #tmpMeanModeXY

/*
Combine Mean and Mode of X and y and Max of x, Max of y
*/

IF OBJECT_ID('TempDB.dbo.#tmpMaxXYMeanModeXY') IS NOT NULL
	DROP TABLE #tmpMaxXYMeanModeXY

SELECT A.store_id
	  ,A.section_id
	  ,A.fp_version
	  ,A.MeanX
	  ,A.ModeX
	  ,A.MeanY
	  ,A.ModeY
	  ,B.MaxXCount
	  ,B.MaxYCount
INTO #tmpMaxXYMeanModeXY
FROM #tmpMeanModeXY AS A
INNER JOIN  #tmpXYcounts AS B
ON A.store_id = B.store_id
AND A.section_id = B.section_id
AND A.fp_version = B.fp_version

PRINT '#tmpMaxXYMeanModeXY'
--SELECT * FROM #tmpMaxXYMeanModeXY

/*
Apply the case of maxX gt maxY or any other
Then this will be the final data having calculated x and y
NOTE: CASE NEED TO BE APPLIED
*/
IF OBJECT_ID('TempDB.dbo.#tmpFinallyCalculatedXY') IS NOT NULL
	DROP TABLE #tmpFinallyCalculatedXY

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version
	  , CASE WHEN MaxXCount > MaxYCount THEN ModeX ELSE MeanX END AS X
	  , CASE WHEN MaxYCount > MaxXCount THEN ModeY ELSE MeanY END AS Y
INTO #tmpFinallyCalculatedXY
FROM #tmpMaxXYMeanModeXY

PRINT '#tmpFinallyCalculatedXY'
--SELECT * FROM #tmpFinallyCalculatedXY


/*
Take the Section_Width from Ph1 checked data for distinct store, section, fp_version
*/
IF OBJECT_ID('TempDB.dbo.#tmpSectionWidth') IS NOT NULL
	DROP TABLE #tmpSectionWidth

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version
	  ,MIN(Section_Width) AS Section_Width
INTO #tmpSectionWidth
FROM #tmpPH1
GROUP BY store_id, section_id, fp_version

PRINT '#tmpSectionWidth'
--SELECT * FROM #tmpSectionWidth


/*
Calculate the count of SKUs from Ph2 checked data
*/
IF OBJECT_ID('TempDB.dbo.#tmpCountOfSkus') IS NOT NULL
	DROP TABLE #tmpCountOfSkus

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,COUNT(DISTINCT SKU_Number) AS CountSkus
INTO #tmpCountOfSkus
FROM #tmpPH2
GROUP BY store_id, section_id, fp_version

PRINT '#tmpCountOfSkus'
--SELECT * FROM #tmpCountOfSkus
/**/
/*
Now combine #tmpFinallyCalculatedXY, #tmpSectionWidth, #tmpCountOfSkus, #tmpPH1
*/

IF OBJECT_ID('TempDB.dbo.#tmpCombinedOutput') IS NOT NULL
	DROP TABLE #tmpCombinedOutput

SELECT DISTINCT Ph2.store_id
	  ,Ph2.section_id
	  ,Ph2.SKU_Number AS sku
	  ,CONVERT(VARCHAR, Ph2.MaxDateFromPh2,106) AS date_from
	  ,Ph2.fp_version
	  ,Ph1.FP_Status as fp_status
	  ,Ph1.date1
	  ,CAST(WEEK_NO AS INT) AS week_no
INTO #tmpCombinedOutput
FROM #tmpPH2 AS Ph2
INNER JOIN #tmpPH1 AS Ph1 ON  Ph2.store_id = Ph1.store_id AND Ph2.section_id = Ph1.section_id AND Ph2.fp_version = Ph1.fp_version
INNER JOIN [dbo].[TB_STG_DATE_MAP_DIM] AS DimDate ON CAST(CALENDAR_DATE AS DATE) = Ph2.date_from


PRINT '#tmpCombinedOutput'
--SELECT * FROM #tmpCombinedOutput 


/*
Take Max(fp_version) based on store, section and week_no
Create Final Output
*/

IF OBJECT_ID('TempDB.dbo.#FinalOutput_New') IS NOT NULL
	DROP TABLE #FinalOutput_New

select a.*
INTO #FinalOutput_New
from #tmpCombinedOutput AS a
inner join 
(
	SELECT store_id,section_id, MAX(fp_version) as fp_version, week_no
	FROM #tmpCombinedOutput
	GROUP BY store_id,section_id,week_no
) as b
ON a.store_id = b.store_id AND a.section_id = b.section_id AND a.fp_version = b.fp_version and a.week_no = b.week_no


PRINT '#FinalOutput_New'
--SELECT store_id, section_id,fp_version
--FROM #FinalOutput_New


--Load the data into TB_TGT_MASTER table from temporary table "#FinalOutput_New"

IF OBJECT_ID('TB_TGT_MASTER') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_MASTER
	SELECT DISTINCT * 
	FROM #FinalOutput_New
	PRINT 'Inserted records into existing table (TB_TGT_MASTER).'
END
ELSE
BEGIN
	SELECT DISTINCT * 
	INTO TB_TGT_MASTER
	FROM #FinalOutput_New
	PRINT 'Created the table (TB_TGT_MASTER) and inserted the records.'
END

PRINT 'TB_TGT_MASTER was populated'

IF OBJECT_ID('TempDB.dbo.#FinalOutput_New') IS NOT NULL
	DROP TABLE #FinalOutput_New


/*Sql script to create the TB_CONTINUOUS_JDA of Part 2*/

/*
Get distinct records for store_id, section_id, fp_version and week_no
*/
IF OBJECT_ID('TempDB.dbo.#DistinctItems') IS NOT NULL
	DROP TABLE #DistinctItems

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version
	  ,week_no
INTO #DistinctItems 
FROM TB_TGT_MASTER
ORDER BY store_id,section_id,fp_version,week_no

PRINT '#DistinctItems'
--SELECT * FROM #DistinctItems

/*
Get lead_week for distinct records
*/

IF OBJECT_ID('TempDB.dbo.#DataWithLeadWeeks') IS NOT NULL
	DROP TABLE #DataWithLeadWeeks

SELECT DISTINCT store_id
	   ,section_id
	   ,fp_version
	   ,week_no
	   ,LEAD(week_no) OVER (Partition By store_id, section_id ORDER BY  store_id, section_id, week_no) AS lead_week
INTO #DataWithLeadWeeks
FROM #DistinctItems

PRINT '#DataWithLeadWeeks'

--SELECT * FROM #DataWithLeadWeeks

/*
Handle NULL lead_week in #DataWithLeadWeeks
Take the Max(week_no) from Sales Data for store,section
Fill the NULL lead_week with Max(week_no) of Sales Data
*/

IF OBJECT_ID('TempDB.dbo.#DataWithLeadWeeksNullManaged') IS NOT NULL
	DROP TABLE #DataWithLeadWeeksNullManaged

SELECT DISTINCT aa.store_id
	  ,aa.section_id
	  ,aa.fp_version
	  ,aa.week_no
	  ,CASE WHEN aa.lead_week IS NULL THEN @end_week ELSE aa.lead_week END AS lead_week
INTO #DataWithLeadWeeksNullManaged
FROM #DataWithLeadWeeks AS aa
--INNER JOIN 
--(
--	/*First join the SALES DATA with MASTER table to get the section_id 
--	and then get the Max(TB_STG_SALES_DATA.WEEK_NO) for store_id, section_id*/

--	SELECT DISTINCT b.location AS store_id, a.section_id, MAX(b.WEEK_NO)as max_week_no
--	FROM TB_TGT_MASTER AS a
--	INNER JOIN [dbo].[TB_STG_SALES_DATA] AS b
--	ON a.store_id = b.location AND a.sku = b.sku and a.week_no = b.week_no
--	GROUP BY b.location, a.section_id
--) AS bb
--ON aa.store_id = bb.store_id AND aa.section_id = bb.section_id

PRINT '#DataWithLeadWeeksNullManaged'
--SELECT * FROM #DataWithLeadWeeksNullManaged

/*
Cross join data with DateMap on week_no to make the data countinuous till lead week
*/

IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks

SELECT DISTINCT q1.store_id
	  ,q1.section_id
	  ,q1.fp_version
	  ,q1.week_no
	  ,q1.lead_week
	  ,dm.WEEK_NO as datemap_week
INTO #DataForContinuousWeeks
FROM #DataWithLeadWeeksNullManaged AS q1
CROSS JOIN (SELECT DISTINCT WEEK_NO, PRV_WEEK_NO FROM dbo.TB_STG_DATE_MAP_DIM) AS dm
WHERE dm.WEEK_NO >= q1.week_no AND dm.WEEK_NO <= q1.lead_week

PRINT '#DataForContinuousWeeks'
--SELECT * FROM #DataForContinuousWeeks

IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks_STG_1') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks_STG_1


SELECT t1.store_id, t1.section_id, t1.fp_version, t1.week_no, t1.lead_week, t1.datemap_week
INTO #DataForContinuousWeeks_STG_1
FROM #DataForContinuousWeeks AS t1
INNER JOIN
(
	SELECT store_id, section_id, MAX(fp_version) AS max_fp_version
	FROM #DataForContinuousWeeks
	GROUP BY store_id, section_id
) AS t2
ON t1.store_id = t2.store_id AND t1.section_id = t2.section_id AND t1.fp_version = t2.max_fp_version

PRINT '#DataForContinuousWeeks_STG_1'
--SELECT * FROM #DataForContinuousWeeks_STG_1


IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks_ReCreated') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks_ReCreated

SELECT *
INTO #DataForContinuousWeeks_ReCreated
FROM
(
	SELECT * FROM #DataForContinuousWeeks
	WHERE datemap_week <> lead_week
	UNION
	SELECT * FROM #DataForContinuousWeeks_STG_1
) AS a

PRINT '#DataForContinuousWeeks_ReCreated'
--SELECT * FROM #DataForContinuousWeeks_ReCreated


/*
Now combine other variables from Master Data
*/

IF OBJECT_ID('TempDB.dbo.#TB_CONTINUOUS_JDA_BASE') IS NOT NULL
	DROP TABLE #TB_CONTINUOUS_JDA_BASE

--SELECT a.store_id
--	  ,a.section_id
--	  ,a.fp_version
--	  ,a.datemap_week AS week_no
--	  ,b.X
--	  ,b.Y
--	  ,b.bay_count
--	  ,b.prod_allocated
--INTO #TB_CONTINUOUS_JDA_BASE
--FROM #DataForContinuousWeeks AS a
--INNER JOIN (SELECT DISTINCT store_id, section_id, fp_version, week_no, x,y,bay_count, prod_allocated FROM TB_TGT_MASTER) AS b
--ON a.store_id = b.store_id AND a.section_id = b.section_id AND a.fp_version = b.fp_version

SELECT DISTINCT a.store_id
	  ,a.section_id
	  ,a.fp_version
	  ,a.week_no AS week_no_jda
	  ,a.lead_week
	  ,a.datemap_week AS week_no
	  ,b.sku
	  ,xy.X
	  ,xy.Y
	  ,sw.Section_Width AS section_width
	  ,cntsku.CountSkus as prod_allocated
	  ,Ph1.FP_Status
	  ,Ph1.date1
	  ,b.date_from
	  ,Ph1.[POG_Width]
	  ,Ph1.[POG_Name]
	  ,Ph1.[POG_Change_Type]
	  ,Ph1.[NumberOfProductsAllocated]
	  ,CAST(tw.[Bay Width] AS FLOAT) AS true_width
	  ,CASE WHEN ph1.Section_Width / (CAST(tw.[Bay Width] AS FLOAT) * 100) <= 0.7 
		THEN 0.5
	   ELSE 
		CASE WHEN ph1.Section_Width / (CAST(tw.[Bay Width] AS FLOAT) * 100) > 0.7 
				  AND ph1.Section_Width / (CAST(tw.[Bay Width] AS FLOAT) * 100) <= 1.0 
			THEN 1 
		ELSE ROUND(ph1.Section_Width / (CAST(tw.[Bay Width] AS FLOAT) * 100), 0.5) END 
		END AS bay_count
INTO #TB_CONTINUOUS_JDA_BASE
FROM (SELECT DISTINCT store_id, section_id, fp_version, week_no, sku, date_from  FROM TB_TGT_MASTER) AS b 
INNER JOIN #DataForContinuousWeeks_ReCreated AS a
ON a.store_id = b.store_id AND a.section_id = b.section_id AND a.fp_version = b.fp_version
INNER JOIN #tmpFinallyCalculatedXY AS xy ON  xy.store_id = a.store_id AND xy.section_id = a.section_id AND xy.fp_version = a.fp_version
INNER JOIN #tmpSectionWidth AS sw ON sw.store_id = a.store_id AND sw.section_id = a.section_id AND sw.fp_version = a.fp_version
INNER JOIN #tmpCountOfSkus AS cntsku ON a.store_id = cntsku.store_id AND a.section_id = cntsku.section_id AND a.fp_version = cntsku.fp_version
INNER JOIN #tmpPH1 AS Ph1 ON  a.store_id = Ph1.store_id AND a.section_id = Ph1.section_id AND a.fp_version = Ph1.fp_version
INNER JOIN [dbo].[TB_STG_TRUE_WIDTH] AS tw ON a.section_id = tw.section_id

--SELECT * FROM #DataForContinuousWeeks_ReCreated


PRINT '#TB_CONTINUOUS_JDA_BASE'
--SELECT * FROM #TB_CONTINUOUS_JDA_BASE



/* Create 2 more calculated variables
1. store_fp Max(fp) on store
2. store_sec_fp Max(fp) on store, section
Bring the records that have store_fp > store_sec_fp
Above is equivalent to removing the records where store_sec_fp < store_fp
*/

/*
Get the Max(fp_version) on store_id
Base table is #TB_CONTINUOUS_JDA
*/

IF OBJECT_ID('TempDB.dbo.#Max_fp_on_store') IS NOT NULL
	DROP TABLE #Max_fp_on_store

--SELECT store_id, MAX(fp_version) AS store_fp
--INTO #Max_fp_on_store
--FROM #TB_CONTINUOUS_JDA_BASE
--GROUP BY store_id

--CHANGE ABVO TO BELOW

SELECT store_id, week_no, MAX(fp_version) AS store_fp
INTO #Max_fp_on_store
FROM #TB_CONTINUOUS_JDA_BASE
GROUP BY store_id, week_no

PRINT '#Max_fp_on_store'
--SELECT * FROM #Max_fp_on_store


/*
Get the Max(fp_version) on store_id
Base table is #TB_CONTINUOUS_JDA
*/

IF OBJECT_ID('TempDB.dbo.#Max_fp_on_store_section') IS NOT NULL
	DROP TABLE #Max_fp_on_store_section

--SELECT store_id,section_id, MAX(fp_version) AS store_sec_fp
--INTO #Max_fp_on_store_section
--FROM #TB_CONTINUOUS_JDA_BASE
--GROUP BY store_id,section_id

--CHANGE ABVO TO BELOW
SELECT store_id,section_id, week_no, MAX(fp_version) AS store_sec_fp
INTO #Max_fp_on_store_section
FROM #TB_CONTINUOUS_JDA_BASE
GROUP BY store_id,section_id, week_no


PRINT '#Max_fp_on_store_section'
--SELECT * FROM #Max_fp_on_store_section


/*
Join #TB_CONTINUOUS_JDA with #Max_fp_on_store to get the store_fp on store_id and week_no
*/

IF OBJECT_ID('TempDB.dbo.#DataWithStoreFp') IS NOT NULL
	DROP TABLE #DataWithStoreFp

SELECT a.* , b.store_fp
INTO #DataWithStoreFp
FROM #TB_CONTINUOUS_JDA_BASE AS a
INNER JOIN #Max_fp_on_store AS b
ON a.store_id = b.store_id
and a.week_no = b.week_no

PRINT '#DataWithStoreFp'
--SELECT * FROM #DataWithStoreFp

/*
Join #DataWithStoreFp with #Max_fp_on_store_section to get the store_sec_fp on store_id, section_id
*/

IF OBJECT_ID('TempDB.dbo.#DataWithStoreFpAndStoreSecFp') IS NOT NULL
	DROP TABLE #DataWithStoreFpAndStoreSecFp

SELECT aa.*, bb.store_sec_fp
INTO #DataWithStoreFpAndStoreSecFp
FROM #DataWithStoreFp AS aa
INNER JOIN #Max_fp_on_store_section AS bb
ON aa.store_id = bb.store_id AND aa.section_id = bb.section_id and aa.week_no = bb.week_no


PRINT '#DataWithStoreFpAndStoreSecFp'
--SELECT * FROM #DataWithStoreFpAndStoreSecFp


/*
Finally, create the #TB_CONTINUOUS_JDA after applying the condition WHERE store_fp > store_sec_fp
Above condition is equivalent of if removing the records that have store_sec_fp < store_fp
*/

IF OBJECT_ID('TempDB.dbo.#TB_CONTINUOUS_JDA') IS NOT NULL
	DROP TABLE #TB_CONTINUOUS_JDA

SELECT * 
INTO #TB_CONTINUOUS_JDA
FROM #DataWithStoreFpAndStoreSecFp
WHERE store_fp = store_sec_fp

PRINT '#TB_CONTINUOUS_JDA'
--SELECT * FROM #TB_CONTINUOUS_JDA

/*
Finally drop the temporary tables, except last temporary table
*/
--IF OBJECT_ID('TempDB.dbo.#TB_CONTINUOUS_JDA') IS NOT NULL
--	DROP TABLE #TB_CONTINUOUS_JDA

IF OBJECT_ID('TempDB.dbo.#DataWithStoreFpAndStoreSecFp') IS NOT NULL
	DROP TABLE #DataWithStoreFpAndStoreSecFp

IF OBJECT_ID('TempDB.dbo.#DataWithStoreFp') IS NOT NULL
	DROP TABLE #DataWithStoreFp

IF OBJECT_ID('TempDB.dbo.#Max_fp_on_store_section') IS NOT NULL
	DROP TABLE #Max_fp_on_store_section

IF OBJECT_ID('TempDB.dbo.#Max_fp_on_store') IS NOT NULL
	DROP TABLE #Max_fp_on_store

IF OBJECT_ID('TempDB.dbo.#TB_CONTINUOUS_JDA_BASE') IS NOT NULL
	DROP TABLE #TB_CONTINUOUS_JDA_BASE

IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks_ReCreated') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks_ReCreated

IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks_STG_1') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks_STG_1

IF OBJECT_ID('TempDB.dbo.#DataForContinuousWeeks') IS NOT NULL
	DROP TABLE #DataForContinuousWeeks

IF OBJECT_ID('TempDB.dbo.#DataWithLeadWeeksNullManaged') IS NOT NULL
	DROP TABLE #DataWithLeadWeeksNullManaged

IF OBJECT_ID('TempDB.dbo.#DataWithLeadWeeks') IS NOT NULL
	DROP TABLE #DataWithLeadWeeks

IF OBJECT_ID('TempDB.dbo.#DistinctItems') IS NOT NULL
	DROP TABLE #DistinctItems

IF OBJECT_ID('TempDB.dbo.#FinalOutput_New') IS NOT NULL
	DROP TABLE #FinalOutput_New

IF OBJECT_ID('TempDB.dbo.#tmpCombinedOutput') IS NOT NULL
	DROP TABLE #tmpCombinedOutput

IF OBJECT_ID('TempDB.dbo.#tmpCountOfSkus') IS NOT NULL
	DROP TABLE #tmpCountOfSkus

IF OBJECT_ID('TempDB.dbo.#tmpSectionWidth') IS NOT NULL
	DROP TABLE #tmpSectionWidth

IF OBJECT_ID('TempDB.dbo.#tmpFinallyCalculatedXY') IS NOT NULL
	DROP TABLE #tmpFinallyCalculatedXY

IF OBJECT_ID('TempDB.dbo.#tmpMaxXYMeanModeXY') IS NOT NULL
	DROP TABLE #tmpMaxXYMeanModeXY

IF OBJECT_ID('TempDB.dbo.#tmpMeanModeXY') IS NOT NULL
	DROP TABLE #tmpMeanModeXY

IF OBJECT_ID('TempDB.dbo.#tmpMeanModeY') IS NOT NULL
	DROP TABLE #tmpMeanModeY

IF OBJECT_ID('TempDB.dbo.#tmpModeY') IS NOT NULL
	DROP TABLE #tmpModeY

IF OBJECT_ID('TempDB.dbo.#tmpMeanY') IS NOT NULL
	DROP TABLE #tmpMeanY

IF OBJECT_ID('TempDB.dbo.#tmpMeanModeX') IS NOT NULL
	DROP TABLE #tmpMeanModeX

IF OBJECT_ID('TempDB.dbo.#tmpModeX') IS NOT NULL
	DROP TABLE #tmpModeX

IF OBJECT_ID('TempDB.dbo.#tmpMeanX') IS NOT NULL
	DROP TABLE #tmpMeanX

IF OBJECT_ID('TempDB.dbo.#tmpXYcounts') IS NOT NULL
	DROP TABLE #tmpXYcounts

IF OBJECT_ID('TempDB.dbo.#tmpYcount') IS NOT NULL
	DROP TABLE #tmpYcount

IF OBJECT_ID('TempDB.dbo.#tmpXcount') IS NOT NULL
	DROP TABLE #tmpXcount

IF OBJECT_ID('TempDB.dbo.#tmpPh1Ph2XY') IS NOT NULL
	DROP TABLE #tmpPh1Ph2XY

IF OBJECT_ID('TempDB.dbo.#tmpPH1') IS NOT NULL
	DROP TABLE #tmpPH1

IF OBJECT_ID('TempDB.dbo.#tmpPH2') IS NOT NULL
	DROP TABLE #tmpPH2

IF OBJECT_ID('TempDB.dbo.#tmpOriginalPh1') IS NOT NULL
	DROP TABLE #tmpOriginalPh1

IF OBJECT_ID('TempDB.dbo.#tmpOriginalPh2') IS NOT NULL
	DROP TABLE #tmpOriginalPh2


/*After loading data into target or stagging, drop the last temporary table also.*/

--Load the data into table from temporary table "#TB_CONTINUOUS_JDA"

IF OBJECT_ID('TB_TGT_CONTINUOUS_JDA') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_CONTINUOUS_JDA
	SELECT DISTINCT * 
	FROM #TB_CONTINUOUS_JDA
	PRINT 'Inserted records into existing table (TB_TGT_CONTINUOUS_JDA).'
END
ELSE
BEGIN
	SELECT DISTINCT * 
	INTO TB_TGT_CONTINUOUS_JDA
	FROM #TB_CONTINUOUS_JDA
	PRINT 'Created the table (TB_TGT_CONTINUOUS_JDA) and inserted the records.'
END

--Drop the temporary table "#TB_CONTINUOUS_JDA"

IF OBJECT_ID('TempDB.dbo.#TB_CONTINUOUS_JDA') IS NOT NULL
	DROP TABLE #TB_CONTINUOUS_JDA

--Read data from permanent table

--SELECT * FROM TB_TGT_CONTINUOUS_JDA



--DROP TABLE TB_TGT_CONTINUOUS_JDA

--SELECT * FROM [dbo].TB_TGT_CONTINUOUS_JDA


--Targered tables
--TB_TGT_MASTER
--TB_TGT_CONTINUOUS_JDA

--SELECT * FROM  TB_TGT_MASTER
--SELECT * FROM  TB_TGT_CONTINUOUS_JDA

--DROP TABLE TB_TGT_MASTER
--DROP TABLE TB_TGT_CONTINUOUS_JDA

/*------------------------------------Part 1 & 2 End----------------------------------------*/


/*------------------------------------Part 3.1 Starts----------------------------------------*/
/*
Now join the above (CONTINUOUS JDA + MASTER) with SALES Data on store_id, sku and week_no
This is the CONTINUOUS_SKU_JDA
*/
IF OBJECT_ID('TempDB.dbo.#TB_SALES_SKU_DATA') IS NOT NULL
	DROP TABLE #TB_SALES_SKU_DATA

SELECT CAST(s.LOCATION AS INT) AS LOCATION
	  ,CAST(s.sku AS INT) AS sku
	  ,CAST(s.WEEK_NO AS INT) AS WEEK_NO
	  ,CAST(s.SALES AS FLOAT) AS SALES
	  ,CAST(s.VOL AS FLOAT) AS VOL
	  ,CAST(s.PPA AS FLOAT) AS PPA
	  ,CAST(s.WASTE_COST AS FLOAT) AS WASTE_COST
	  ,CAST(s.SHRINKAGE_COST AS FLOAT) AS SHRINKAGE_COST
	  ,CAST(s.WASTE_RETAIL AS FLOAT) AS WASTE_RETAIL
	  ,CAST(s.SHRINKAGE_RETAIL AS FLOAT) AS SHRINKAGE_RETAIL
	  ,CAST(s.LOCATION_TRAIT_ID AS INT) AS LOCATION_TRAIT_ID
	  ,sj.section_id
	  ,sj.fp_version
	  ,tb2.Zone_id
INTO #TB_SALES_SKU_DATA
FROM dbo.TB_STG_SALES_DATA AS s
INNER JOIN TB_TGT_CONTINUOUS_JDA sj
ON CAST(s.LOCATION AS INT) = sj.store_id
AND CAST(s.sku AS INT) = sj.sku
AND CAST(s.WEEK_NO AS INT) = CAST(sj.week_no AS INT)

LEFT JOIN [dbo].[TB_STG_LOCATION_ZONE_MAP] AS tb2
ON s.LOCATION = CAST(tb2.LOCATION AS INT)
WHERE tb2.[Zone_id] IS NOT NULL

--SELECT * FROM #TB_SALES_SKU_DATA


/*
After loading data into target or stagging, drop the last temporary table also.*/

--Load the data into TB_TGT_SALES_SKU_DATA table from temporary table "#TB_SALES_SKU_DATA"

IF OBJECT_ID('TB_TGT_SALES_SKU_DATA') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_SALES_SKU_DATA
	SELECT * 
	FROM #TB_SALES_SKU_DATA
	PRINT 'Inserted records into existing table (TB_TGT_SALES_SKU_DATA).'
END
ELSE
BEGIN
	SELECT * 
	INTO TB_TGT_SALES_SKU_DATA
	FROM #TB_SALES_SKU_DATA
	PRINT 'Created the table (TB_TGT_SALES_SKU_DATA) and inserted the records.'
END

--Drop the temporary table "#TB_CONTINUOUS_JDA"

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SKU_DATA') IS NOT NULL
	DROP TABLE #TB_SALES_SKU_DATA

--Read data from permanent table

--Targeted tables
--TB_TGT_SALES_SKU_DATA

--SELECT COUNT(*) AS cnt_rows FROM TB_TGT_SALES_SKU_DATA
--DROP TABLE TB_TGT_SALES_SKU_DATA


/*------------------------------------Part 3.1 End----------------------------------------*/

/*------------------------------------Part 3.2 Starts----------------------------------------*/

/* Check TB_TGT_SALES_SKU_DATA */
--SELECT * FROM TB_TGT_SALES_SKU_DATA

/* Join  TB_TGT_SALES_SKU_DATA with TB_TGT_CONTINUOUS_JDA and roll up the data */

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA

SELECT DISTINCT a.LOCATION AS LOCATION
	  ,a.section_id AS SECTION_ID
	  ,a.fp_version
	  ,a.WEEK_NO AS WEEK_NO
	  ,b.X
	  ,b.Y
	  ,b.section_width
	  ,b.prod_allocated
	  ,a.Zone_id
	  ,a.LOCATION_TRAIT_ID
	  ,b.bay_count
	  ,SUM(a.PPA) AS Total_PPA
	  ,SUM(a.SALES) AS Total_SALES
	  ,SUM(a.VOL) AS Total_VOL
	  ,SUM(a.WASTE_COST) AS Total_WASTE_COST
	  ,SUM(a.SHRINKAGE_COST) AS  Total_SHRINKAGE_COST
	  ,SUM(a.WASTE_RETAIL) AS Total_WASTE_RETAIL
	  ,SUM(a.SHRINKAGE_RETAIL) AS Total_SHRINKAGE_RETAIL
INTO #TB_SALES_SECTION_DATA
FROM (SELECT DISTINCT LOCATION, section_id,fp_version,WEEK_NO,Zone_id,LOCATION_TRAIT_ID
	  ,PPA  ,SALES ,VOL  ,WASTE_COST ,SHRINKAGE_COST ,WASTE_RETAIL ,SHRINKAGE_RETAIL 
	  FROM dbo.TB_TGT_SALES_SKU_DATA)a
INNER JOIN (select distinct store_id, section_id, week_no, X, Y, section_width, prod_allocated , bay_count 
from dbo.TB_TGT_CONTINUOUS_JDA)b
ON a.LOCATION = b.store_id 
AND a.section_id = b.section_id 
AND a.week_no = b.week_no
WHERE ((@start_week IS NULL AND @end_week IS NULL) OR a.WEEK_NO BETWEEN @start_week AND @end_week)
	  AND ((@loc_trait_id IS NULL) OR LOCATION_TRAIT_ID = @loc_trait_id)
GROUP BY a.LOCATION
		,a.section_id
		,a.fp_version
		,a.WEEK_NO
		,X
		,Y
		,section_width
		,prod_allocated
		,Zone_id
		,LOCATION_TRAIT_ID
		,bay_count

/* Check #TB_SALES_SECTION_DATA */
--SELECT * FROM #TB_SALES_SECTION_DATA

/* Join #TB_SALES_SECTION_DATA 
with 
TB_STG_HOLIDAY_DATA
TB_STG_WEATHER_DATA
TB_STG_SECTION_SUBCAT_SKU_MAP
TB_STG_CLUSTER_REGION
TB_STG_CLUSTER_SMKT
TB_STG_CLUSTER_CONV
TB_STG_STORE_AREA
TB_STG_ACTIVE 
and create indicator columns & include these
*/

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_1') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_1


SELECT tb1.LOCATION
	  ,tb1.SECTION_ID
	  ,tb1.fp_version
	  ,tb1.WEEK_NO
	  ,tb1.X
	  ,tb1.Y
	  ,tb1.section_width
	  ,tb1.prod_allocated
	  ,tb1.[Zone_id]
	  ,tb1.LOCATION_TRAIT_ID
	  ,tb1.Total_SALES
	  ,tb1.Total_VOL
	  ,tb1.Total_PPA
	  ,tb1.Total_WASTE_COST
	  ,tb1.Total_SHRINKAGE_COST
	  ,tb1.Total_WASTE_RETAIL
	  ,tb1.Total_SHRINKAGE_RETAIL
	  ,CAST(tb2.Sports_IND AS BIT) AS Sports_IND, CAST(tb2.Religion_IND AS BIT) AS Religion_IND
	  ,CAST(tb2.Bank_IND AS BIT) AS Bank_IND, CAST(tb2.Special_IND AS BIT) AS Special_IND
	  ,CAST(tb2.Sponsorship_IND AS BIT) AS Sponsorship_IND
	  ,CAST(tb3.REGION AS INT) AS REGION
	  ,CAST(tb3.MAX_CELSIUS_high AS FLOAT) AS MAX_CELSIUS_high
	  ,CAST(tb3.MAX_CELSIUS_low AS FLOAT) AS MAX_CELSIUS_low
	  ,CAST(tb3.MAX_CELSIUS_avg AS FLOAT) AS MAX_CELSIUS_avg
	  ,CAST(tb3.MIN_CELSIUS_high AS FLOAT) AS MIN_CELSIUS_high
	  ,CAST(tb3.MIN_CELSIUS_low AS FLOAT) AS MIN_CELSIUS_low
	  ,CAST(tb3.MIN_CELSIUS_avg AS FLOAT) AS MIN_CELSIUS_avg
	  ,CAST(tb3.SUN_HOURS_high AS FLOAT) AS SUN_HOURS_high
	  ,CAST(tb3.SUN_HOURS_low AS FLOAT) AS SUN_HOURS_low
	  ,CAST(tb3.SUN_HOURS_avg AS FLOAT) AS SUN_HOURS_avg
	  ,CAST(tb3.RAIN_MM_high AS FLOAT) AS RAIN_MM_high
	  ,CAST(tb3.RAIN_MM_low AS FLOAT) AS RAIN_MM_low
	  ,CAST(tb3.RAIN_MM_avg AS FLOAT) AS RAIN_MM_avg
	  ,tb4.SUB_CATEGORY_CNT
	  ,Cluster.[REGION] AS Region_EDW
	  ,Cluster.[REGION_NAME] AS Region_Name_EDW
	  ,Cluster.Trait_Store_Type
	  ,Cluster.[ZONE_NO]
	  ,Cluster.[ZONE_NAME]
	  ,ISNULL(cls.OW_CLUSTERS, 0) AS cluster
	  ,CAST(IIF(tb8.[F_store_size] IS NULL OR tb8.[F_store_size] = '', NULL, tb8.[F_store_size]) AS INT) AS F_store_size
	  ,CAST(IIF(tb8.[NS_Store_Size] IS NULL OR tb8.[NS_Store_Size] = '', NULL, tb8.[NS_Store_Size]) AS INT) AS NS_Store_Size
	  ,CAST(IIF(tb8.[T_Store_size] IS NULL OR tb8.[T_Store_size] = '', NULL, tb8.[T_Store_size]) AS INT) AS T_Store_size
	  ,ISNULL(CAST(tb10.[ACTIVE_DAYS] AS INT), 7) AS ACTIVE_DAYS
	  ,7 - ISNULL(CAST(tb10.[ACTIVE_DAYS] AS INT), 7) AS CLOSURE_DAYS
	  ,CASE WHEN @pre_christ_wk	LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS pre_christmas_ind
	  ,CASE WHEN @christ_wk		LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS christmas_ind
	  ,CASE WHEN @post_christ_wk	LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS post_christmas_ind
	  ,CASE WHEN @pre_Easter_wk	LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS pre_easter_ind
	  ,CASE WHEN @Easter_wk		LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS easter_ind
	  ,CASE WHEN @post_Easter_wk	LIKE '%' + CAST(tb1.WEEK_NO AS VARCHAR(6)) + '%'  THEN 1 ELSE 0 END AS post_easter_ind
	  ,CASE WHEN CAST(tb2.Bank_IND AS BIT) = 1 OR CAST(tb2.Religion_IND AS BIT) = 1 OR CAST(tb2.Special_IND AS BIT) = 1 THEN 1 ELSE 0 END AS holiday_ind
	  ,CASE WHEN CAST(tb2.Sponsorship_IND AS BIT) = 1 OR CAST(tb2.Sports_IND AS BIT) = 1 THEN 1 ELSE 0 END AS event_ind
INTO #TB_SALES_SECTION_DATA_STG_1
FROM #TB_SALES_SECTION_DATA AS tb1
LEFT JOIN dbo.TB_STG_HOLIDAY_DATA AS tb2
ON  tb1.WEEK_NO = CAST(tb2.[Financial_week] AS INT)
LEFT JOIN [dbo].[TB_STG_WEATHER_DATA] AS tb3
ON tb1.LOCATION = CAST(tb3.LOCATION AS INT) AND tb1.WEEK_NO = CAST(tb3.WEEK_NO AS INT)
LEFT JOIN 
(
	SELECT CAST(Section_num AS INT) AS Section_num
		  ,COUNT(DISTINCT CAST([SUB_CATEGORY] AS INT)) AS SUB_CATEGORY_CNT
	FROM [dbo].[TB_STG_SECTION_SUBCAT_SKU_MAP]
	GROUP BY CAST(Section_num AS INT)
) AS tb4
ON tb1.SECTION_ID = Section_num
LEFT JOIN 
(select distinct STORE,REGION, REGION_NAME, ZONE_NO, ZONE_NAME, Trait_Store_Type  
from dbo.[TB_STG_CLUSTER_REGION])Cluster
ON tb1.LOCATION = CAST(Cluster.STORE AS INT)
LEFT JOIN dbo.Vw_Clusters cls
ON tb1.LOCATION = CAST(cls.STORE_NO AS INT)
LEFT JOIN (select distinct store_no, week_no, [F_store_size], [NS_Store_Size], [T_Store_size] from dbo.[TB_STG_STORE_AREA]) AS tb8
ON tb1.LOCATION = CAST(tb8.store_no AS INT) AND tb1.WEEK_NO = CAST(tb8.[week_no] AS INT)
LEFT JOIN [dbo].[TB_STG_ACTIVE] AS tb10
ON tb1.LOCATION = CAST(tb10.[STORE_ID] AS INT) AND tb1.WEEK_NO = CAST(tb10.[FIN_WEEK_ID] AS INT)


/* Check #TB_SALES_SECTION_DATA_STG_1 */
--SELECT * FROM #TB_SALES_SECTION_DATA_STG_1

/* Join  #TB_SALES_SECTION_DATA_STG_1
with
[TB_STG_COMPETITOR]
[TB_STG_INVESTMENT]
and create and include the columns
*/
PRINT '#TB_SALES_SECTION_DATA_STG_2'

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_2') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_2

SELECT tb1.LOCATION
	  ,tb1.SECTION_ID
	  ,tb1.fp_version
	  ,tb1.WEEK_NO
	  ,tb1.X
	  ,tb1.Y
	  ,tb1.section_width
	  ,tb1.prod_allocated
	  ,tb1.[Zone_id]
	  ,tb1.LOCATION_TRAIT_ID
	  ,tb1.Total_SALES
	  ,tb1.Total_VOL
	  ,tb1.Total_PPA
	  ,tb1.Total_WASTE_COST
	  ,tb1.Total_SHRINKAGE_COST
	  ,tb1.Total_WASTE_RETAIL
	  ,tb1.Total_SHRINKAGE_RETAIL
	  ,tb1.REGION
	  ,tb1.MAX_CELSIUS_high
	  ,tb1.MAX_CELSIUS_low
	  ,tb1.MAX_CELSIUS_avg
	  ,tb1.MIN_CELSIUS_high
	  ,tb1.MIN_CELSIUS_low
	  ,tb1.MIN_CELSIUS_avg
	  ,tb1.SUN_HOURS_high
	  ,tb1.SUN_HOURS_low
	  ,tb1.SUN_HOURS_avg
	  ,tb1.RAIN_MM_high
	  ,tb1.RAIN_MM_low
	  ,tb1.RAIN_MM_avg
	  ,tb1.SUB_CATEGORY_CNT
	  ,tb1.Region_EDW
	  ,tb1.Region_Name_EDW
	  ,tb1.Trait_Store_Type
	  ,tb1.[ZONE_NO]
	  ,tb1.[ZONE_NAME]
	  ,tb1.cluster
	  ,tb1.[F_store_size]
	  ,tb1.[NS_Store_Size]
	  ,tb1.[T_Store_size]
	  ,tb1.ACTIVE_DAYS
	  ,CASE WHEN tb1.ACTIVE_DAYS = 0 THEN 1 ELSE 0 END AS Act_days_0
	  ,CASE WHEN tb1.ACTIVE_DAYS = 1 THEN 1 ELSE 0 END AS Act_days_1
	  ,CASE WHEN tb1.ACTIVE_DAYS = 2 THEN 1 ELSE 0 END AS Act_days_2
	  ,CASE WHEN tb1.ACTIVE_DAYS = 3 THEN 1 ELSE 0 END AS Act_days_3
	  ,CASE WHEN tb1.ACTIVE_DAYS = 4 THEN 1 ELSE 0 END AS Act_days_4
	  ,CASE WHEN tb1.ACTIVE_DAYS = 5 THEN 1 ELSE 0 END AS Act_days_5
	  ,CASE WHEN tb1.ACTIVE_DAYS = 6 THEN 1 ELSE 0 END AS Act_days_6
	  ,CASE WHEN tb1.ACTIVE_DAYS = 7 THEN 1 ELSE 0 END AS Act_days_7
	  ,tb1.CLOSURE_DAYS
	  ,tb1.pre_christmas_ind
	  ,tb1.christmas_ind
	  ,tb1.post_christmas_ind
	  ,tb1.pre_easter_ind
	  ,tb1.easter_ind
	  ,tb1.post_easter_ind
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE holiday_ind END AS holiday_ind
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE event_ind END AS event_ind
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE Bank_IND END AS Bank_IND
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE Religion_IND END AS Religion_IND
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE Special_IND END AS Special_IND
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE Sponsorship_IND END AS Sponsorship_IND
	  ,CASE WHEN pre_christmas_ind = 1 OR christmas_ind =1 OR post_christmas_ind = 1 OR pre_easter_ind = 1
		OR easter_ind = 1 OR post_easter_ind = 1 THEN 0 ELSE Sports_IND END AS Sports_IND
	  ,comp_0_1
	  ,comp_1_2
	  ,comp_2_n
	  ,CAST(tb2.week_no AS INT) AS c_week_no
	  ,CASE WHEN CAST(tb2.Flag AS BIT) IS NULL AND tb1.WEEK_NO >= CAST(tb2.week_no AS INT) THEN 1 ELSE 0 END AS concession_flag
	  ,CASE WHEN CAST(tb2.Concession_Size AS INT) IS NULL AND tb1.WEEK_NO >= CAST(tb2.week_no AS INT) THEN CAST(tb2.Concession_Size AS INT) ELSE 0 END AS concession_size
	  ,CASE WHEN CAST(tb2.Concession_Size AS INT) IS NULL AND tb1.WEEK_NO >= CAST(tb2.week_no AS INT) THEN CAST(tb2.Concession_Size AS INT) ELSE 0 END / T_Store_size AS argos_ts_ratio
	  ,CASE WHEN CAST(tb2.Concession_Size AS INT) IS NULL AND tb1.WEEK_NO >= CAST(tb2.week_no AS INT) THEN CAST(tb2.Concession_Size AS INT) ELSE 0 END / NS_Store_Size AS argos_ns_ratio
	  ,tb3.StartOnSite_Week_No
	  ,tb3.ReLaunch_Week_No
	  ,CASE WHEN tb1.WEEK_NO >= tb3.StartOnSite_Week_No AND tb1.WEEK_NO <= tb3.ReLaunch_Week_No THEN 1 ELSE 0 END AS invest_flag
	  ,CASE WHEN tb1.WEEK_NO >= tb3.StartOnSite_Week_No AND tb1.WEEK_NO <= tb3.ReLaunch_Week_No 
		AND tb3.Investment_Type = 'new' THEN 1 ELSE 0 END AS invest_new_flag
	  ,CASE WHEN tb1.WEEK_NO >= tb3.StartOnSite_Week_No AND tb1.WEEK_NO <= tb3.ReLaunch_Week_No 
		AND tb3.Investment_Type = 'refurbi' THEN 1 ELSE 0 END AS invest_refurbi_flag
	  ,CASE WHEN tb1.WEEK_NO >= tb3.StartOnSite_Week_No AND tb1.WEEK_NO <= tb3.ReLaunch_Week_No 
		AND tb3.Investment_Type NOT IN ('new', 'refurbi') THEN 1 ELSE 0 END AS invest_other_flag
INTO #TB_SALES_SECTION_DATA_STG_2
FROM #TB_SALES_SECTION_DATA_STG_1 AS tb1
LEFT JOIN  
(
	SELECT CAST(JS_Branch AS INT) JS_Branch
		  ,COUNT(DISTINCT JS_Branch) AS comp_0_1
	FROM [dbo].[TB_STG_COMPETITOR] 
	WHERE CAST(Distance_Miles AS FLOAT) <= 1.0
	GROUP BY JS_Branch
) AS c_0_1
ON tb1.LOCATION = c_0_1.JS_Branch
LEFT JOIN  
(
	SELECT CAST(JS_Branch AS INT) JS_Branch
		  ,COUNT(DISTINCT JS_Branch) AS comp_1_2
	FROM [dbo].[TB_STG_COMPETITOR] 
	WHERE CAST(Distance_Miles AS FLOAT) > 1.0 
		  AND CAST(Distance_Miles AS FLOAT) <= 2.0
	GROUP BY JS_Branch
) AS c_1_2
ON tb1.LOCATION = c_1_2.JS_Branch
LEFT JOIN  
(
	SELECT CAST(JS_Branch AS INT) JS_Branch
		  ,COUNT(DISTINCT JS_Branch) AS comp_2_n
	FROM [dbo].[TB_STG_COMPETITOR] 
	WHERE CAST(Distance_Miles AS FLOAT) > 2.0
	GROUP BY JS_Branch
) AS c_2_n
ON tb1.LOCATION = c_2_n.JS_Branch
LEFT JOIN [dbo].[TB_STG_ARGOS] AS tb2
ON tb1.LOCATION = CAST(tb2.Location AS INT)
LEFT JOIN 
(
	SELECT CAST([JS_Branch] AS INT) AS JS_Branch
		  ,CAST([StartOnSite_Week_No] AS INT) AS StartOnSite_Week_No
		  ,CAST([ReLaunch_Week_No] AS INT) AS ReLaunch_Week_No
		  ,LTRIM(RTRIM(LOWER([Investment_Type]))) AS Investment_Type
	FROM [dbo].[TB_STG_INVESTMENT]
	WHERE ((@start_week IS NULL) OR CAST([ReLaunch_Week_No] AS INT) >= @start_week)
	AND LTRIM(RTRIM(LOWER([Investment_Type]))) <> 'closure' 
) AS tb3
ON tb1.LOCATION = tb3.JS_Branch
ORDER BY tb1.LOCATION, tb1.SECTION_ID, tb1.WEEK_NO


/* Check #TB_SALES_SECTION_DATA_STG_2 */
--SELECT * FROM #TB_SALES_SECTION_DATA_STG_2

/* Join #TB_SALES_SECTION_DATA_STG_2 
with
[TB_STG_WEATHER_DATA]
[TB_STG_STORE_AREA]
and modify the column values*/


IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_3') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_3

SELECT tb1.LOCATION
	  ,tb1.SECTION_ID
	  ,tb1.fp_version
	  ,tb1.WEEK_NO
	  ,tb1.X
	  ,tb1.Y
	  ,tb1.section_width
	  ,tb1.prod_allocated
	  ,tb1.Zone_id
	  ,tb1.LOCATION_TRAIT_ID
	  ,tb1.Total_SALES
	  ,tb1.Total_VOL
	  ,tb1.Total_PPA
	  ,tb1.Total_WASTE_COST
	  ,tb1.Total_SHRINKAGE_COST
	  ,tb1.Total_WASTE_RETAIL
	  ,tb1.Total_SHRINKAGE_RETAIL
	  ,tb1.REGION
	  ,ISNULL(tb1.MAX_CELSIUS_high, tb2.avg_MAX_CELSIUS_high) AS MAX_CELSIUS_high
	  ,ISNULL(tb1.MAX_CELSIUS_low,  tb2.avg_MAX_CELSIUS_low) AS MAX_CELSIUS_low
	  ,ISNULL(tb1.MAX_CELSIUS_avg,  tb2.avg_MAX_CELSIUS_avg) AS MAX_CELSIUS_avg
	  ,ISNULL(tb1.MIN_CELSIUS_high, tb2.avg_MIN_CELSIUS_high) AS MIN_CELSIUS_high
	  ,ISNULL(tb1.MIN_CELSIUS_low,  tb2.avg_MIN_CELSIUS_low) AS MIN_CELSIUS_low
	  ,ISNULL(tb1.MIN_CELSIUS_avg,  tb2.avg_MIN_CELSIUS_avg) AS MIN_CELSIUS_avg
	  ,ISNULL(tb1.SUN_HOURS_high,   tb2.avg_SUN_HOURS_high) AS SUN_HOURS_high
	  ,ISNULL(tb1.SUN_HOURS_low,    tb2.avg_SUN_HOURS_low) AS SUN_HOURS_low
	  ,ISNULL(tb1.SUN_HOURS_avg,    tb2.avg_SUN_HOURS_avg) AS SUN_HOURS_avg
	  ,ISNULL(tb1.RAIN_MM_high,     tb2.avg_RAIN_MM_high) AS RAIN_MM_high
	  ,ISNULL(tb1.RAIN_MM_low,      tb2.avg_RAIN_MM_low) AS RAIN_MM_low
	  ,ISNULL(tb1.RAIN_MM_avg,      tb2.avg_RAIN_MM_avg) AS RAIN_MM_avg
	  ,tb1.SUB_CATEGORY_CNT
	  ,tb1.Region_EDW
	  ,tb1.Region_Name_EDW
	  ,tb1.Trait_Store_Type
	  ,tb1.[ZONE_NO]
	  ,tb1.[ZONE_NAME]
	  ,tb1.cluster
	  ,COALESCE(tb1.[F_store_size], tb3.F_store_size_at_maxwk) AS F_store_size
	  ,COALESCE(tb1.[NS_Store_Size], tb3.NS_Store_Size_at_maxwk) AS NS_Store_Size
	  ,COALESCE(tb1.[T_Store_size], tb3.T_Store_size_at_maxwk) AS T_Store_size
	  ,tb1.ACTIVE_DAYS
	  ,tb1.Act_days_0
	  ,tb1.Act_days_1
	  ,tb1.Act_days_2
	  ,tb1.Act_days_3
	  ,tb1.Act_days_4
	  ,tb1.Act_days_5
	  ,tb1.Act_days_6
	  ,tb1.Act_days_7
	  ,tb1.CLOSURE_DAYS
	  ,tb1.pre_christmas_ind
	  ,tb1.christmas_ind
	  ,tb1.post_christmas_ind
	  ,tb1.pre_easter_ind
	  ,tb1.easter_ind
	  ,tb1.post_easter_ind
	  ,tb1.holiday_ind
	  ,tb1.event_ind
	  ,tb1.Bank_IND
	  ,tb1.Religion_IND
	  ,tb1.Special_IND
	  ,tb1.Sponsorship_IND
	  ,tb1.Sports_IND
	  ,tb1.comp_0_1
	  ,tb1.comp_1_2
	  ,tb1.comp_2_n
	  ,tb1.c_week_no
	  ,tb1.concession_flag
	  ,tb1.concession_size
	  ,tb1.argos_ts_ratio
	  ,tb1.argos_ns_ratio
	  ,tb1.StartOnSite_Week_No
	  ,tb1.ReLaunch_Week_No
	  ,tb1.invest_flag
	  ,tb1.invest_new_flag
	  ,tb1.invest_refurbi_flag
	  ,tb1.invest_other_flag
	  ,IIF(tb1.CLOSURE_DAYS = 1, 1 * tb1.invest_flag, 0) AS invest_close_1
	  ,IIF(tb1.CLOSURE_DAYS = 2, 1 * tb1.invest_flag, 0) AS invest_close_2
	  ,IIF(tb1.CLOSURE_DAYS = 3, 1 * tb1.invest_flag, 0) AS invest_close_3
	  ,IIF(tb1.CLOSURE_DAYS = 4, 1 * tb1.invest_flag, 0) AS invest_close_4
	  ,IIF(tb1.CLOSURE_DAYS = 5, 1 * tb1.invest_flag, 0) AS invest_close_5
	  ,IIF(tb1.CLOSURE_DAYS = 6, 1 * tb1.invest_flag, 0) AS invest_close_6
	  ,IIF(tb1.CLOSURE_DAYS = 7, 1 * tb1.invest_flag, 0) AS invest_close_7
	  ,tb1.CLOSURE_DAYS * tb1.invest_flag AS invest_close 
INTO #TB_SALES_SECTION_DATA_STG_3
FROM #TB_SALES_SECTION_DATA_STG_2 AS tb1
LEFT JOIN 
(
	SELECT CAST(REGION AS INT) AS REGION
		  ,CAST(WEEK_NO AS INT) AS WEEK_NO
		  ,AVG(CAST(MAX_CELSIUS_high AS FLOAT)) AS avg_MAX_CELSIUS_high
		  ,AVG(CAST(MAX_CELSIUS_low AS FLOAT)) AS avg_MAX_CELSIUS_low
		  ,AVG(CAST(MAX_CELSIUS_avg AS FLOAT)) AS avg_MAX_CELSIUS_avg
		  ,AVG(CAST(MIN_CELSIUS_high AS FLOAT)) AS avg_MIN_CELSIUS_high
		  ,AVG(CAST(MIN_CELSIUS_low AS FLOAT)) AS avg_MIN_CELSIUS_low
		  ,AVG(CAST(MIN_CELSIUS_avg AS FLOAT)) AS avg_MIN_CELSIUS_avg
		  ,AVG(CAST(SUN_HOURS_high AS FLOAT)) AS avg_SUN_HOURS_high
		  ,AVG(CAST(SUN_HOURS_low AS FLOAT)) AS avg_SUN_HOURS_low
		  ,AVG(CAST(SUN_HOURS_avg AS FLOAT)) AS avg_SUN_HOURS_avg
		  ,AVG(CAST(RAIN_MM_high AS FLOAT)) AS avg_RAIN_MM_high
		  ,AVG(CAST(RAIN_MM_low AS FLOAT)) AS avg_RAIN_MM_low
		  ,AVG(CAST(RAIN_MM_avg AS FLOAT)) AS avg_RAIN_MM_avg
	FROM dbo.[TB_STG_WEATHER_DATA]
	GROUP BY CAST(REGION AS INT)
			,CAST(WEEK_NO AS INT)
) AS tb2
ON tb1.REGION = tb2.REGION AND tb1.WEEK_NO = tb2.WEEK_NO
LEFT JOIN
(
	SELECT t2.store_no
		  ,t2.max_week_no
		  ,CAST(IIF(T_Store_size IS NULL OR T_Store_size = '', NULL, T_Store_size) AS INT) AS T_Store_size_at_maxwk
		  ,CAST(IIF(NS_Store_Size IS NULL OR NS_Store_Size = '', NULL, NS_Store_Size) AS INT) AS NS_Store_Size_at_maxwk
		  ,CAST(IIF(F_store_size IS NULL OR F_store_size = '', NULL, F_store_size) AS INT) AS F_store_size_at_maxwk
	FROM [dbo].[TB_STG_STORE_AREA] AS t1
	INNER JOIN 
	(
		SELECT CAST(store_no AS INT) AS store_no, MAX(CAST(week_no AS INT)) AS max_week_no
		FROM [dbo].[TB_STG_STORE_AREA]
		GROUP BY CAST(store_no AS INT)
	) AS t2
	ON t1.store_no = t2.store_no AND t1.week_no = t2.max_week_no
) AS tb3
ON tb1.LOCATION = tb3.store_no


/* Check #TB_SALES_SECTION_DATA_STG_3 */
--SELECT * FROM #TB_SALES_SECTION_DATA_STG_3


/* Join TB_TGT_CONTINUOUS_JDA with TB_STG_REFERENCE_SECTION_STATIC
   to make the base dataset for creating the flags */

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG

SELECT DISTINCT t1.store_id
	  ,t1.section_id
	  ,t1.fp_version
	  ,t1.week_no
	  ,t1.bay_count
	  ,t1.X
	  ,t1.Y
	  ,t1.prod_allocated
	  ,CAST(t2.x AS FLOAT) AS reference_sec_x
	  ,CAST(t2.y AS FLOAT) AS reference_sec_y
	  ,week_no_jda
INTO #CONITNUOUS_JDA_STG
FROM [dbo].TB_TGT_CONTINUOUS_JDA AS t1
LEFT JOIN [dbo].[TB_STG_REFERENCE_SECTION_STATIC] AS t2
ON t1.store_id = CAST(t2.store_num AS INT)
ORDER BY store_id, section_id, week_no

PRINT '#CONITNUOUS_JDA_STG'

/* Check #CONITNUOUS_JDA_STG */
--SELECT * FROM #CONITNUOUS_JDA_STG

/* Create space, range, pos flags based on the lag values */

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_1') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_1

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,week_no
	  ,bay_count
	  ,X
	  ,Y
	  ,prod_allocated
	  ,lag_location
	  ,lag_section_id
	  ,ref_x
	  ,ref_y
	  ,lag_x
	  ,lag_y
	  ,lag_lag_x
	  ,lag_lag_y
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND bay_count <> lag_bay_count, 1,0) AS space_flag
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND prod_allocated <> lag_prod_allocated, 1,0) AS range_flag
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (ABS(x - lag_x) >= 400 OR ABS(y - lag_y) >= 400), 1,0) AS pos_flag
	  ,reference_sec_x
	  ,reference_sec_y
	  ,pos_distance1
	  ,position_distance
	  ,LAG(position_distance) OVER(ORDER BY store_id, section_id, week_no) AS lag_position_distance
	  ,week_no_jda
INTO #CONITNUOUS_JDA_STG_1
FROM
(
	SELECT store_id
		  ,section_id
		  ,fp_version
		  ,week_no
		  ,bay_count
		  ,X
		  ,Y
		  ,prod_allocated
		  ,LAG(X) OVER(ORDER BY store_id, section_id, week_no) AS ref_x
		  ,LAG(Y) OVER(ORDER BY store_id, section_id, week_no) AS ref_y
		  ,LAG(X) OVER(ORDER BY store_id, section_id, week_no) AS lag_x
		  ,LAG(Y) OVER(ORDER BY store_id, section_id, week_no) AS lag_y
		  ,LAG(X,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_x
		  ,LAG(Y,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_y
		  ,LAG(store_id) OVER(ORDER BY store_id, section_id, week_no) AS lag_location
		  ,LAG(section_id) OVER(ORDER BY store_id, section_id, week_no) AS lag_section_id
		  ,LAG(bay_count) OVER(ORDER BY store_id, section_id, week_no) AS lag_bay_count
		  ,LAG(prod_allocated) OVER(ORDER BY store_id, section_id, week_no) AS lag_prod_allocated
		  ,reference_sec_x
		  ,reference_sec_y
		  ,SQRT(SQUARE(X - reference_sec_x) + SQUARE(Y - reference_sec_y)) AS pos_distance1
		  ,SQRT(SQUARE(X) + SQUARE(Y)) AS position_distance
		  ,week_no_jda
	FROM #CONITNUOUS_JDA_STG
) AS t1

print '#CONITNUOUS_JDA_STG_1'
/* Check #CONITNUOUS_JDA_STG_1 */
--SELECT * FROM #CONITNUOUS_JDA_STG_1

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_2') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_2

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,week_no
	  ,bay_count
	  ,X
	  ,Y
	  ,prod_allocated
	  ,lag_location
	  ,lag_section_id
	  ,ref_x
	  ,ref_y
	  ,lag_x
	  ,lag_y
	  ,lag_lag_x
	  ,lag_lag_y
	  ,space_flag
	  ,range_flag
	  ,pos_flag
	  ,LAG(space_flag) OVER(ORDER BY store_id, section_id, week_no) AS lag_space_flag
	  ,LAG(range_flag) OVER(ORDER BY store_id, section_id, week_no) AS lag_range_flag
	  ,LAG(pos_flag) OVER(ORDER BY store_id, section_id, week_no) AS lag_pos_flag
	  ,LAG(space_flag,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_space_flag
	  ,LAG(range_flag,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_range_flag
	  ,LAG(pos_flag,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_pos_flag
	  ,LAG(space_flag,3) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_lag_space_flag
	  ,LAG(range_flag,3) OVER(ORDER BY store_id, section_id, week_no) AS Lag_lag_lag_range_flag
	  ,LAG(pos_flag,3) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_lag_pos_flag
	  ,reference_sec_x
	  ,reference_sec_y
	  ,pos_distance1
	  ,position_distance
	  ,lag_position_distance
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND position_distance <> lag_position_distance, 1,0) AS position_flag
	  ,week_no_jda
INTO #CONITNUOUS_JDA_STG_2	
FROM #CONITNUOUS_JDA_STG_1


/* Check #CONITNUOUS_JDA_STG_2 */
--SELECT * FROM #CONITNUOUS_JDA_STG_2


IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_3') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_3

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,week_no
	  ,bay_count
	  ,X
	  ,Y
	  ,prod_allocated
	  ,lag_location
	  ,lag_section_id
	  ,ref_x
	  ,ref_y
	  ,lag_x
	  ,lag_y
	  ,lag_lag_x
	  ,lag_lag_y
	  ,space_flag
	  ,range_flag
	  ,pos_flag
	  ,lag_space_flag
	  ,lag_range_flag
	  ,lag_pos_flag
	  ,lag_lag_space_flag
	  ,lag_lag_range_flag
	  ,lag_lag_pos_flag
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND lag_space_flag = 1, 1,0) AS space_disruption_1wk 
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND lag_range_flag = 1, 1,0) AS range_disruption_1wk
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND lag_pos_flag = 1, 1,0) AS position_disp_1wk
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_space_flag = 1 OR lag_lag_space_flag = 1), 1,0) AS space_disruption_2wk 
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_range_flag = 1 OR lag_lag_range_flag = 1), 1,0) AS range_disruption_2wk
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_pos_flag = 1 OR lag_lag_pos_flag = 1), 1,0) AS position_disp_2wk
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_space_flag = 1 OR lag_lag_space_flag = 1 OR lag_lag_lag_space_flag = 1), 1,0) AS space_disruption_3wk 
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_range_flag = 1 OR lag_lag_range_flag = 1 OR lag_lag_lag_range_flag = 1), 1,0) AS range_disruption_3wk
	  ,IIF(store_id = lag_location AND section_id = lag_section_id AND (lag_pos_flag = 1 OR lag_lag_pos_flag = 1 OR lag_lag_lag_pos_flag = 1), 1,0) AS position_disp_3wk
	  ,reference_sec_x
	  ,reference_sec_y
	  ,pos_distance1
	  ,position_distance
	  ,lag_position_distance
	  ,position_flag
	  ,LAG(position_flag) OVER(ORDER BY store_id, section_id, week_no) AS lag_position_flag
	  ,LAG(position_flag,2) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_position_flag
	  ,LAG(position_flag,3) OVER(ORDER BY store_id, section_id, week_no) AS lag_lag_lag_position_flag
	  ,week_no_jda
INTO #CONITNUOUS_JDA_STG_3
FROM #CONITNUOUS_JDA_STG_2

print '#CONITNUOUS_JDA_STG_3'
/* Check #CONITNUOUS_JDA_STG_3 */
--SELECT * FROM #CONITNUOUS_JDA_STG_3


/*Select distinct variables from TB_TGT_SALES_SKU_DATA and calculate asp*/

IF OBJECT_ID('TempDB.dbo.#SKU_ASP') IS NOT NULL
	DROP TABLE #SKU_ASP

SELECT DISTINCT LOCATION
	  ,Zone_id
	  ,section_id
	  ,WEEK_NO
	  ,sku
	  ,SALES
	  ,VOL
	  ,CASE WHEN VOL <= 0 THEN 0 ELSE SALES / VOL END AS asp
INTO #SKU_ASP
FROM TB_TGT_SALES_SKU_DATA

print ' #SKU_ASP' 

/*Check #SKU_ASP*/
--SELECT * FROM #SKU_ASP

/* Select distinct store, section,fp, sku, week_no_jda from TB_TGT_CONTINUOUS_JDA 
	and create a base table TB_SKU_CHURNED_PRICE */

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE

SELECT DISTINCT store_id
	  ,section_id
	  ,fp_version
	  ,sku
	  ,week_no_jda
INTO #TB_SKU_CHURNED_PRICE
FROM [dbo].TB_TGT_CONTINUOUS_JDA

print '#TB_SKU_CHURNED_PRICE'
/*Check #TB_SKU_CHURNED_PRICE*/
--SELECT * FROM #TB_SKU_CHURNED_PRICE

/* Join #TB_SKU_CHURNED_PRICE 
with [dbo].[TB_STG_SKU_CHURN_FINAL_ADD] 
[dbo].[TB_STG_SKU_CHURN_FINAL_REM]
and include the columns Added_SKU and Removed_SKU*/

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Add_Rem_SKUs') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,sku
	  ,week_no_jda
	  ,CAST(A.Added_SKU AS INT) AS Added_SKU
	  ,CAST(R.Removed_SKU AS INT) AS Removed_SKU
INTO #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs
FROM #TB_SKU_CHURNED_PRICE AS t1
LEFT JOIN [dbo].[TB_STG_SKU_CHURN_FINAL_ADD] AS A
ON t1.store_id = CAST(A.Store AS INT) 
	AND t1.section_id = CAST(A.Section AS INT) 
	AND t1.fp_version = CAST(A.FloorPlan AS INT) 
	AND t1.week_no_jda = CAST(A.week_no AS INT)
	AND t1.sku = CAST(A.Added_SKU AS INT)
LEFT JOIN [dbo].[TB_STG_SKU_CHURN_FINAL_REM] AS R
ON t1.store_id = CAST(R.Store AS INT) 
	AND t1.section_id = CAST(R.Section AS INT) 
	AND t1.fp_version = CAST(R.FloorPlan AS INT) 
	AND t1.week_no_jda = CAST(R.week_no AS INT)
	AND t1.sku = CAST(R.Removed_SKU AS INT)

print ' #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs'
/* Check #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs*/
--SELECT * FROM #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs

/* Join #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs with #SKU_ASP twice to get the 
	added_sales, added_vol, added_asp and removed_sales,removed_vol, removed_asp */


IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp

SELECT t1.store_id
	  ,t1.section_id
	  ,t1.fp_version
	  ,t1.sku
	  ,t1.week_no_jda
	  ,t1.Added_SKU
	  ,t1.Removed_SKU
	  ,ISNULL(t2.SALES, 0) AS added_sales
	  ,ISNULL(t2.VOL, 0) AS added_vol
	  ,ISNULL(t2.asp, 0) AS added_asp
	  ,ISNULL(t3.SALES, 0) AS removed_sales
	  ,ISNULL(t3.VOL, 0) AS removed_vol
	  ,ISNULL(t3.asp, 0) AS removed_asp
	  ,ISNULL(t4.total_vol, 0) AS total_vol
INTO #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp
FROM #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs AS t1
LEFT JOIN  #SKU_ASP AS t2
ON t1.store_id = t2.LOCATION AND t1.section_id = t2.section_id AND t1.Added_SKU = t2.sku AND t1.week_no_jda = t2.WEEK_NO
LEFT JOIN  #SKU_ASP AS t3
ON t1.store_id = t3.LOCATION AND t1.section_id = t3.section_id AND t1.Removed_SKU = t3.sku AND t1.week_no_jda = t3.WEEK_NO
LEFT JOIN
(
	SELECT DISTINCT LOCATION
		  ,section_id
		  ,WEEK_NO
		  ,SUM(VOL) AS total_vol
	FROM #SKU_ASP
	GROUP BY LOCATION,section_id,WEEK_NO
) AS t4
ON t1.store_id = t4.LOCATION AND t1.section_id = t4.section_id AND t1.week_no_jda = t4.WEEK_NO

print ' #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp'

/* Check #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp*/
--SELECT * FROM #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp

/* Derive the variables wt_asp_add, wt_asp_rem, wt_price_diff1 
	from #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp*/

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Plus_DerivedVars') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Plus_DerivedVars

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,sku
	  ,week_no_jda
	  ,Added_SKU
	  ,Removed_SKU
	  ,added_sales
	  ,added_vol
	  ,added_asp
	  ,removed_sales
	  ,removed_vol
	  ,removed_asp
	  ,total_vol
	  ,CASE WHEN total_vol = 0 THEN 0 ELSE (added_vol / total_vol) * added_asp END AS wt_asp_add 
	  ,CASE WHEN total_vol = 0 THEN 0 ELSE (removed_vol / total_vol) * removed_asp END AS wt_asp_rem
	  ,CASE WHEN total_vol = 0 THEN 0 ELSE ((added_vol / total_vol) * added_asp) - (removed_vol / total_vol) * removed_asp END AS wt_price_diff1
INTO #TB_SKU_CHURNED_PRICE_Plus_DerivedVars
FROM #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp

print ' #TB_SKU_CHURNED_PRICE_Plus_DerivedVars'

/* Check #TB_SKU_CHURNED_PRICE_Plus_DerivedVars*/
--SELECT * FROM #TB_SKU_CHURNED_PRICE_Plus_DerivedVars

/* Roll up the wt_price_diff1 on store_id, section_id, week_no_jda
	in #TB_SKU_CHURNED_PRICE_Plus_DerivedVars*/

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp

SELECT store_id
	  ,section_id
	  ,week_no_jda
	  ,SUM(ISNULL(wt_price_diff1,0)) AS wt_price_diff1
INTO #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp
FROM #TB_SKU_CHURNED_PRICE_Plus_DerivedVars
GROUP BY store_id, section_id, week_no_jda

print ' #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp'

/* Check #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp*/
--SELECT * FROM #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp



/*                      PROMOTION STARTS                             */
/*                                                                   */

/*Select distinct records from TB_STG_PROMO_INFO_V9 */



IF OBJECT_ID('TempDB.dbo.#PROMO_INFO_V9_UNQ') IS NOT NULL
	DROP TABLE #PROMO_INFO_V9_UNQ

SELECT CAST(zone_id AS INT) AS zone_id
	  ,CAST(sku AS INT) AS sku
	  ,CAST(prom_week_no AS INT) AS prom_week_no
INTO #PROMO_INFO_V9_UNQ
FROM
(
	SELECT DISTINCT zone_id,sku,prom_week_no
	FROM dbo.TB_STG_PROMO_INFO_V9
	WHERE prom_week_no IS NOT NULL OR prom_week_no <> ''
	 AND base_price IS NOT NULL OR base_price <> ''
) AS t1

print ' #PROMO_INFO_V9_UNQ'

--SELECT * FROM #PROMO_INFO_V9_UNQ

/* Pull the records from TB_STG_PROMOTION_DATA */

IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA') IS NOT NULL
	DROP TABLE #PROMOTION_DATA

SELECT CAST(ISNULL(PRICE_ZONE,0) AS INT) AS PRICE_ZONE
	  ,CAST(ISNULL(SKU,0) AS INT) AS SKU
	  ,CAST(ISNULL(PROM_WEEK_NO,0) AS INT) AS PROM_WEEK_NO
	  ,CAST(ISNULL(SUB_CATEGORY,0) AS INT) AS SUB_CATEGORY
	  ,SUB_CATEGORY_NAME
	  ,PromoSKU
	  ,CAST(ISNULL(IIF(PromoWeekNo = 'NULL' OR PromoWeekNo = '' OR PromoWeekNo IS NULL, 0, PromoWeekNo), 0) AS INT) AS PromoWeekNo
	  ,CAST(ISNULL(BASE_PRICE,0) AS FLOAT) AS BASE_PRICE
	  ,CAST(ISNULL(PROMOTION_KEY,0) AS BIGINT) AS PROMOTION_KEY
	  ,SECT_NAME
INTO #PROMOTION_DATA
FROM
(
	SELECT * FROM
	(
		SELECT *
			,ROW_NUMBER() OVER(PARTITION BY PRICE_ZONE, SKU,PROM_WEEK_NO,BASE_PRICE ORDER BY PRICE_ZONE, SKU,PROM_WEEK_NO,BASE_PRICE, PROMOTION_KEY) AS row_num 
		FROM dbo.TB_STG_PROMOTION_DATA 
	) AS a
	WHERE  row_num = 1
) AS t1


print ' #PROMOTION_DATA'

--SELECT * FROM #PROMOTION_DATA

/*Select the records from #PROMOTION_DATA having sku those are not in #PROMO_INFO_V9_UNQ */

IF OBJECT_ID('TempDB.dbo.#PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA') IS NOT NULL
	DROP TABLE #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA

--------SELECT zone_id
--------	  ,sku
--------	  ,prom_week_no
--------	  ,1 AS total_promotion
--------INTO #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA
--------FROM #PROMO_INFO_V9_UNQ
--------WHERE SKU NOT IN (SELECT DISTINCT SKU FROM  #PROMOTION_DATA)
--NOTE:\\ ABOVE LOGIC IS CONVERTED INTO THE BELOW LOGIC

SELECT zone_id
		,promov9.sku
		,prom_week_no
		,1 AS total_promotion
INTO #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA
FROM #PROMO_INFO_V9_UNQ promov9
LEFT JOIN (SELECT DISTINCT SKU FROM  #PROMOTION_DATA) distsku
ON promov9.sku = distsku.SKU
WHERE promov9.sku <> ISNULL(distsku.SKU, 0)


print ' #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA'

--SELECT * FROM #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA

IF OBJECT_ID('TempDB.dbo.#TABLE1') IS NOT NULL
	DROP TABLE #TABLE1

SELECT *
INTO #TABLE1
FROM #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA

print ' #TABLE1'

--SELECT * FROM #TABLE1


/* Roll up the sales and volume of #SKU_ASP on Zone_id,sku,WEEK_NO */

IF OBJECT_ID('TempDB.dbo.#TABLE2') IS NOT NULL
	DROP TABLE #TABLE2

SELECT DISTINCT Zone_id
	  ,sku 
	  ,WEEK_NO
	  ,SUM(SALES) AS zone_sales
	  ,SUM(VOL) AS zone_vol
INTO #TABLE2
FROM #SKU_ASP
GROUP BY Zone_id,sku,WEEK_NO

print ' #TABLE2'

--SELECT * FROM #TABLE2

/*Merge the #TABLE2 and #TABLE1, include the variable total_promotion AS promotions*/

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2

SELECT t1.Zone_id AS price_zone
	  ,t1.sku
	  ,t1.WEEK_NO AS prom_week_no
	  ,t1.zone_sales
	  ,t1.zone_vol
	  ,ISNULL(t2.total_promotion,0) AS promotion_key
	  ,t1.zone_sales / t1.zone_vol AS asp
	  ,CAST(CONCAT(t1.Zone_id, t1.sku) AS BIGINT) AS pz_sku
INTO #MERGED_TBL1_TBL2
FROM #TABLE2 AS t1
LEFT JOIN #TABLE1 AS t2
ON t1.Zone_id = t2.zone_id AND t1.sku = t2.sku AND t1.WEEK_NO = t2.prom_week_no
WHERE t1.zone_sales <> 0 AND t1.zone_vol <> 0

print ' #MERGED_TBL1_TBL2'

--SELECT * FROM #MERGED_TBL1_TBL2

/* Base price logic start */

/* STEP 1(B): LOAD BASE PRICE MERGING WITH SALES PROMO CONSOLIDATION INTO TEMP TABLE #LOADBP */
IF OBJECT_ID('TempDB.dbo.#LOADBP') IS NOT NULL
	DROP TABLE #LOADBP

SELECT PZ_SKU
	  ,[PROM_WEEK_NO]
	  ,[PROMOTIONS]
	  ,[SALES_CASH]
	  ,[ITEM_QUANTITY0]
	  ,AVERAGE_SP
	  ,BASE_PRICE_OLD
	  ,BASE_PRICE
	  ,IS_PROMOTED=CASE WHEN PROMOTIONS > 0 THEN 1 ELSE 0 END
	  ,MAX_DISCOUNT_PCT
INTO #LOADBP
FROM
(
	SELECT PZ_SKU = CONCAT(ZONE_ID, SKU)
		  ,[PROM_WEEK_NO] = WEEK_NO
		  ,[PROMOTIONS]
		  ,[SALES_CASH] = SALES
		  ,[ITEM_QUANTITY0] = VOL
		  ,AVERAGE_SP = SALES / NULLIF(VOL,0)
		  ,[BASE_PRICE_OLD] = 0
		  ,[BASE_PRICE] = 0
		  ,MAX_DISCOUNT_PCT = 0
	from
	(
		SELECT DISTINCT S.SKU
			  ,S.WEEK_NO
			  ,S.ZONE_ID
			  ,S.zone_sales AS SALES
			  ,S.zone_vol AS VOL
			  ,[PROMOTIONS] = IIF(P.PROMOTION_KEY > 0, 1, 0)
		FROM
		(
			SELECT DISTINCT * FROM #TABLE2    --[DBO].[TB_TGT_SALES_SKU_DATA] replaced by #TABLE2
			WHERE Zone_id IS NOT NULL 
		) AS S 
		LEFT JOIN #MERGED_TBL1_TBL2 P		  ---- REPLACED BY #MERGED_TBL1_TBL2
		ON S.SKU = P.SKU 
			AND S.WEEK_NO = P.PROM_WEEK_NO 
			AND S.ZONE_ID = P.PRICE_ZONE
		where  S.zone_vol <> 0 
	)x                          
)XYZ

print '#LOADBP'

/* CREATE INDEX ON THE #LOADBP */
CREATE NONCLUSTERED INDEX IND_BASEPRICE_SKU ON #LOADBP ([PZ_SKU],[PROM_WEEK_NO])
INCLUDE ([AVERAGE_SP],[BASE_PRICE_OLD],[BASE_PRICE])

PRINT 'STEP 1(B): LOAD BASE PRICE MERGING WITH SALES PROMO CONSOLIDATION INTO TEMP TABLE '  + CONVERT(VARCHAR, GETDATE(), 121)

/* STEP 1(C): LOAD PRIOR OR LAG PRICE INTO TEMP TABLE #PRIORBP */
IF OBJECT_ID('TempDB.dbo.#PRIORBP') IS NOT NULL
	DROP TABLE #PRIORBP

SELECT PSP.PZ_SKU
	  ,PSP.PROM_WEEK_NO
	  ,PSP.PROMOTIONS
	  ,PRIORWEEK = ISNULL((CASE WHEN PSP.PROMOTIONS = 0 THEN PSP.PROM_WEEK_NO 
								WHEN PSP.PROMOTIONS > 0 AND MAX(PSP1.PROM_WEEK_NO) IS NOT NULL THEN  MAX(PSP1.PROM_WEEK_NO)
								WHEN PSP.PROMOTIONS > 0 AND MAX(PSP1.PROM_WEEK_NO) IS NULL THEN MIN(PSP2.PROM_WEEK_NO) 
							END ), PSP.PROM_WEEK_NO)
	  ,IS_PROMOTED = ISNULL((CASE WHEN PSP.PROMOTIONS = 0 THEN PSP.IS_PROMOTED 
								WHEN PSP.PROMOTIONS > 0 AND MAX(PSP1.PROM_WEEK_NO) IS NOT NULL THEN  MAX(PSP1.IS_PROMOTED)
								WHEN PSP.PROMOTIONS > 0 AND MAX(PSP1.PROM_WEEK_NO) IS NULL THEN MIN(PSP2.IS_PROMOTED) 
							END ), PSP.IS_PROMOTED)
INTO #PRIORBP
FROM #LOADBP PSP LEFT JOIN
(
	SELECT PZ_SKU, PROM_WEEK_NO, IS_PROMOTED = 0, [SALES_CASH] 
	FROM #LOADBP 
	WHERE PROMOTIONS = 0 
)PSP1 
ON PSP1.PROM_WEEK_NO < PSP.PROM_WEEK_NO 
AND PSP1.PZ_SKU = PSP.PZ_SKU 
LEFT JOIN
(
	SELECT PZ_SKU
		  ,PROM_WEEK_NO = MIN(PROM_WEEK_NO) 
		  ,IS_PROMOTED = 1
	FROM #LOADBP 
	WHERE PROMOTIONS <> 0 
	GROUP BY PZ_SKU, PROMOTIONS
)PSP2
ON  PSP2.PROM_WEEK_NO < PSP.PROM_WEEK_NO 
AND PSP2.PZ_SKU = PSP.PZ_SKU
GROUP BY PSP.PZ_SKU
		,PSP.PROM_WEEK_NO
		,PSP.PROMOTIONS
		,PSP.IS_PROMOTED 

/* CREATE INDEX ON THE #PRIORBP */
CREATE NONCLUSTERED INDEX IND_PBPRICE_SKU ON #PRIORBP ([PZ_SKU],[PROM_WEEK_NO])
INCLUDE (PRIORWEEK,PROMOTIONS)

PRINT 'STEP 1(C): LOAD PRIOR OR LAG PRICE INTO TEMP TABLE '  + CONVERT(VARCHAR, GETDATE(), 121)

/* STEP 1(D): CALCULATE ACTUAL BASE PRICE FOR EACH SKU INTO TEMP TABLE #FINALBP */
IF OBJECT_ID('TempDB.dbo.#FINALBP') IS NOT NULL
	DROP TABLE #FINALBP

SELECT DISTINCT TOP 100 PERCENT 
	   [PZ_SKU]
	  ,[PROM_WEEK_NO]
	  ,[PROMOTIONS]
	  ,[SALES_CASH]
	  ,[ITEM_QUANTITY0]
	  ,[AVERAGE_SP]
	  ,OLD_BP=BASE_PRICE
      ,BASE_PRICE = CASE WHEN [AVERAGE_SP] > BASE_PRICE THEN [AVERAGE_SP] ELSE BASE_PRICE END
      ,DISCOUNT = CAST(((CASE WHEN [AVERAGE_SP] > BASE_PRICE THEN [AVERAGE_SP] ELSE BASE_PRICE END) - [AVERAGE_SP]) AS NUMERIC(18,8))/CASE WHEN (CASE WHEN [AVERAGE_SP] > BASE_PRICE THEN [AVERAGE_SP] ELSE BASE_PRICE END) = 0 THEN 1 ELSE (CASE WHEN [AVERAGE_SP] > BASE_PRICE THEN [AVERAGE_SP] ELSE BASE_PRICE END) END
      ,MAX_DISCOUNT_PCT
INTO #FINALBP
FROM
( 
    SELECT ROWID    
		  ,[PZ_SKU]    
		  ,[PROM_WEEK_NO]    
		  ,[PROMOTIONS] 
		  ,[SALES_CASH]   
		  ,[PRIORWEEK]
		  ,[AVERAGE_SP]             
		  ,PROIRQTY          
		  ,CURQTY
          ,[ITEM_QUANTITY0] = CURQTY 
		  ,BASE_PRICE_PRIOR
		  ,BASE_PRICE_OLD,IS_PROMOTED
		  ,BASE_PRICE = ISNULL(CASE WHEN BASE_PRICE_OLD = BASE_PRICE_PRIOR 
                                    AND BASE_PRICE < [AVERAGE_SP] 
                                    AND ISNULL(MAX_DISCOUNT_PCT,0) > 0 
                                    THEN [AVERAGE_SP] /(CASE WHEN (1-MAX_DISCOUNT_PCT) = 0 THEN 1 ELSE (1 - MAX_DISCOUNT_PCT) END)  END, BASE_PRICE),
                                    MAX_DISCOUNT_PCT
    FROM
    (
		SELECT ROWID    
		      ,[PZ_SKU]    
		      ,[PROM_WEEK_NO]    
			  ,[PROMOTIONS]
			  ,[SALES_CASH]    
			  ,[PRIORWEEK]    
			  ,[AVERAGE_SP]                
			  ,PROIRQTY                 
			  ,CURQTY
			  ,[ITEM_QUANTITY0]= CURQTY 
			  ,BASE_PRICE_PRIOR, BASE_PRICE_OLD, IS_PROMOTED
			  ,BASE_PRICE = CASE  WHEN [PROMOTIONS] = 0 AND ROWID =1 THEN [AVERAGE_SP]
								  WHEN [PROMOTIONS] = 0 AND ROWID >1 THEN [AVERAGE_SP]
								  WHEN [PROMOTIONS] > 0 AND ROWID =1 THEN BASE_PRICE_OLD
								  WHEN [PROMOTIONS] > 0 AND ROWID >1 AND IS_PROMOTED = 0 THEN [PROIR_AVERAGE_SP]
								  WHEN [PROMOTIONS] > 0 AND ROWID >1 AND IS_PROMOTED > 0 THEN BASE_PRICE_PRIOR 
							END
				,MAX_DISCOUNT_PCT
				FROM 
				(
					SELECT ROWID = ROW_NUMBER() OVER (PARTITION BY PBP.[PZ_SKU] ORDER BY PBP.[PZ_SKU], PBP.[PROM_WEEK_NO])
							,PBP.[PZ_SKU]    
							,PBP.[PROM_WEEK_NO]    
							,PBP.[PROMOTIONS]    
							,PBP.[PRIORWEEK]
							,BP.[SALES_CASH]
							,BP.[AVERAGE_SP] PROIR_AVERAGE_SP           
							,BPC.[AVERAGE_SP]       
							,BP.[ITEM_QUANTITY0] PROIRQTY
							,BPC.[ITEM_QUANTITY0] CURQTY
							,BP.BASE_PRICE BASE_PRICE_PRIOR
							,BP.BASE_PRICE_OLD
							,IS_PROMOTED = ISNULL(PBP.IS_PROMOTED, (CASE WHEN BPC.[PROMOTIONS] > 0 THEN 1 ELSE 0 END))
							,BPC.MAX_DISCOUNT_PCT
							,BPC.BASE_PRICE
					FROM #PRIORBP PBP
					INNER JOIN #LOADBP BP 
					ON BP.[PZ_SKU] = PBP.[PZ_SKU] AND PBP.[PRIORWEEK] = BP.[PROM_WEEK_NO]
					INNER JOIN #LOADBP BPC 
					ON BPC.[PZ_SKU] = PBP.[PZ_SKU] AND PBP.[PROM_WEEK_NO] = BPC.[PROM_WEEK_NO]  
				)MERGE_ROW
	)RECALC_BP
) FINAL_CAL_BASE_PRICE
ORDER BY [PZ_SKU]
		,[PROM_WEEK_NO]

print '#FINALBP'
--SELECT * FROM #FINALBP 



/* Base price logic ends */

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2_BASE_PRICE') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2_BASE_PRICE

SELECT t1.price_zone
	  ,t1.sku
	  ,t1.prom_week_no
	  ,t1.zone_sales
	  ,t1.zone_vol
	  ,t1.promotion_key
	  ,t1.asp
	  ,t1.pz_sku
	  ,ROUND(t2.BASE_PRICE, 3) AS BASE_PRICE
INTO #MERGED_TBL1_TBL2_BASE_PRICE
FROM #MERGED_TBL1_TBL2 AS t1
LEFT JOIN (SELECT DISTINCT PZ_SKU, PROM_WEEK_NO,BASE_PRICE FROM #FINALBP) AS t2
ON CAST(t1.pz_sku AS BIGINT) = CAST(t2.PZ_SKU AS BIGINT) AND CAST(t1.prom_week_no AS BIGINT) = CAST(t2.PROM_WEEK_NO AS BIGINT)

print '#MERGED_TBL1_TBL2_BASE_PRICE'

--SELECT * FROM #MERGED_TBL1_TBL2_BASE_PRICE

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2_CLEANED') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2_CLEANED

SELECT price_zone
	  ,sku
	  ,prom_week_no
	  ,99999 AS Sub_Category
	  ,'v9_temp' AS Sub_Category_Name
	  ,CAST(sku AS VARCHAR(20)) AS PromoSKU
	  ,prom_week_no AS PromoWeekNo
	  ,BASE_PRICE -- DUMMY VALUE -- LOGIC TO BE PUT HERE (NEED HELP OF EITHER MUKESH SIR OR NISHANT SIR)
	  ,CAST(promotion_key AS BIGINT) AS PROMOTION_KEY
	  ,'NULL' AS SECT_NAME
	  --,zone_sales -- Extra column -- WHY? we created.
	  --,zone_vol -- Extra column -- WHY? we created.
	  --,asp -- Extra column -- WHY? we created.
	  --,pz_sku -- Extra column -- WHY? we created.
INTO #MERGED_TBL1_TBL2_CLEANED
FROM #MERGED_TBL1_TBL2_BASE_PRICE

print '#MERGED_TBL1_TBL2_CLEANED'

--SELECT * FROM #MERGED_TBL1_TBL2_CLEANED

--Combine #PROMOTION_DATA with #MERGED_TBL1_TBL2_CLEANED that is derived from V9 file


IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA_FINAL_V9') IS NOT NULL
	DROP TABLE #PROMOTION_DATA_FINAL_V9

SELECT DISTINCT * -- IT is removing duplicate records from the result of union (union also does but to make sure after merging)
INTO #PROMOTION_DATA_FINAL_V9
FROM
(
	SELECT * FROM #PROMOTION_DATA
	UNION
	SELECT * FROM #MERGED_TBL1_TBL2_CLEANED
) AS a

print '#PROMOTION_DATA_FINAL_V9  Union of cleaned ith base price and prmotion data'
--SELECT * FROM #PROMOTION_DATA_FINAL_V9

--INSERT INTO TARGET TB_TGT_PROMOTION_DATA_FINAL_V9

IF OBJECT_ID('TB_TGT_PROMOTION_DATA_FINAL_V9') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_PROMOTION_DATA_FINAL_V9
	SELECT DISTINCT * 
	FROM #PROMOTION_DATA_FINAL_V9
	PRINT 'Inserted records into existing table (TB_TGT_PROMOTION_DATA_FINAL_V9).'
END
ELSE
BEGIN
	SELECT DISTINCT * 
	INTO TB_TGT_PROMOTION_DATA_FINAL_V9
	FROM #PROMOTION_DATA_FINAL_V9
	PRINT 'Created the table (TB_TGT_PROMOTION_DATA_FINAL_V9) and inserted the records.'
END

print 'TB_TGT_PROMOTION_DATA_FINAL_V9 was populated'

--SELECT * FROM TB_TGT_PROMOTION_DATA_FINAL_V9
--TRUNCATE TABLE TB_TGT_PROMOTION_DATA_FINAL_V9


IF OBJECT_ID('TempDB.dbo.#TB_STG_PRICE_V10_FINAL') IS NOT NULL
	DROP TABLE #TB_STG_PRICE_V10_FINAL

SELECT 0 AS ZONE
      ,CAST(LOC_IDNT AS INT) AS LOCATION
	  ,CAST(ITEM_IDNT AS INT) AS SKU
	  ,CONVERT(DATE, price_change_date,106) AS price_change_date
	  ,CAST(calc_base_price AS FLOAT) AS calc_base_price
INTO #TB_STG_PRICE_V10_FINAL
FROM [dbo].[TB_STG_PRICE_V10_FINAL] 
WHERE CAST(LOC_IDNT AS INT) IN (2,3) ---- LOC_IDNT TO BE REMOVED
	AND (calc_base_price <> '' OR calc_base_price <> ' ' OR calc_base_price <> 'NULL')

print '#TB_STG_PRICE_V10_FINAL'

--SELECT * FROM #TB_STG_PRICE_V10_FINAL

IF OBJECT_ID('TempDB.dbo.#TB_STG_PRICE_V10_ZONE_FINAL') IS NOT NULL
	DROP TABLE #TB_STG_PRICE_V10_ZONE_FINAL

SELECT  DISTINCT 1 AS ZONE
	  ,CAST(ITEM_IDNT AS INT) AS SKU 
	  ,CONVERT(DATE, price_change_date,106) AS price_change_date
	  ,CAST(calc_base_price AS FLOAT) AS calc_base_price
INTO #TB_STG_PRICE_V10_ZONE_FINAL
FROM [dbo].[TB_STG_PRICE_V10_ZONE_FINAL] 
WHERE calc_base_price <> '' OR calc_base_price <> ' ' OR calc_base_price <> 'NULL'

print '#TB_STG_PRICE_V10_ZONE_FINAL'

--SELECT * FROM #TB_STG_PRICE_V10_ZONE_FINAL

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA

SELECT *  
INTO #TB_COMBINED_V10_DATA
FROM
(
	SELECT * FROM #TB_STG_PRICE_V10_FINAL

	UNION

	SELECT DISTINCT ZONE
		  ,LOCATION
		  ,SKU
		  ,price_change_date
		  ,calc_base_price
	FROM #TB_STG_PRICE_V10_ZONE_FINAL AS t1
	CROSS JOIN 
	(
		SELECT DISTINCT LOCATION
		FROM #SKU_ASP 
	) AS t2
) AS a

print '#TB_COMBINED_V10_DATA'

--SELECT * FROM #TB_COMBINED_V10_DATA
--SELECT ZONE,LOCATION, SKU, price_change_date, calc_base_price, COUNT(*)
--FROM #TB_COMBINED_V10_DATA
--GROUP BY ZONE,LOCATION, SKU, price_change_date, calc_base_price
--HAVING COUNT(*) > 1


IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ

SELECT LOCATION
	  ,SKU
	  ,price_change_date 
	  ,calc_base_price
INTO #TB_COMBINED_V10_DATA_UNQ
FROM
(
	SELECT *
		   ,ROW_NUMBER() OVER(PARTITION BY LOCATION, SKU,price_change_date ORDER BY LOCATION, SKU,price_change_date, zone) AS row_num 
	FROM #TB_COMBINED_V10_DATA
) AS A
WHERE row_num = 1

print '#TB_COMBINED_V10_DATA_UNQ'
--SELECT * FROM #TB_COMBINED_V10_DATA_UNQ


IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK

SELECT LOCATION
	  ,SKU
	  ,price_change_date 
	  ,calc_base_price
	  ,CAST(dm.WEEK_NO AS INT) AS datemap_week
INTO #TB_COMBINED_V10_DATA_UNQ_WEEK
FROM #TB_COMBINED_V10_DATA_UNQ AS t1
LEFT JOIN 
(
	SELECT DISTINCT WEEK_NO, CALENDAR_DATE FROM dbo.TB_STG_DATE_MAP_DIM
) AS dm
ON t1.price_change_date = dm.CALENDAR_DATE
ORDER BY LOCATION, SKU,CAST(dm.WEEK_NO AS INT), price_change_date DESC

print '#TB_COMBINED_V10_DATA_UNQ_WEEK'

--SELECT * FROM #TB_COMBINED_V10_DATA_UNQ_WEEK

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ

SELECT LOCATION
	  ,SKU
	  ,price_change_date 
	  ,calc_base_price
	  ,datemap_week
INTO #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ
FROM
(
	SELECT * 
		   ,ROW_NUMBER() OVER(PARTITION BY LOCATION, SKU,datemap_week ORDER BY LOCATION, SKU,datemap_week) AS row_num
	FROM #TB_COMBINED_V10_DATA_UNQ_WEEK
) AS A
WHERE row_num = 1
print '#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ'

--SELECT * FROM #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK

SELECT DISTINCT q1.LOCATION
	  ,q1.SKU
	  ,q1.datemap_week
	  ,q1.calc_base_price
	  ,ISNULL(LEAD(q1.datemap_week) OVER 
				(Partition By q1.LOCATION, q1.SKU ORDER BY  q1.LOCATION, q1.SKU, q1.datemap_week), q2.MAX_WEEK_NO) AS lead_week
INTO #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK
FROM #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ AS q1
LEFT JOIN 
(
	SELECT DISTINCT LOCATION, SKU, MAX(WEEK_NO) AS MAX_WEEK_NO
	FROM #SKU_ASP
	GROUP BY LOCATION, SKU
) AS q2
ON q1.LOCATION = q2.LOCATION AND q1.SKU = q2.sku

print '#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK'

--SELECT * FROM #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK


IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_CONTINUOUS') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_CONTINUOUS

SELECT LOCATION
      ,SKU
	  ,datemap_week
	  ,lead_week
	  ,calc_base_price
	  ,dm.WEEK_NO as WEEK_NO
INTO #TB_COMBINED_V10_CONTINUOUS
FROM #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK AS q1
CROSS JOIN (SELECT DISTINCT WEEK_NO, PRV_WEEK_NO FROM dbo.TB_STG_DATE_MAP_DIM WHERE WEEK_NO <= @end_week) AS dm
WHERE dm.WEEK_NO >= q1.datemap_week AND dm.WEEK_NO <= q1.lead_week 

print '#TB_COMBINED_V10_CONTINUOUS'
--SELECT * FROM #TB_COMBINED_V10_CONTINUOUS



IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_CONTINUOUS_STG_1') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_CONTINUOUS_STG_1


SELECT t1.LOCATION, t1.SKU, t1.datemap_week, t1.lead_week, t1.WEEK_NO,t1.calc_base_price
INTO #TB_COMBINED_V10_CONTINUOUS_STG_1
FROM #TB_COMBINED_V10_CONTINUOUS AS t1
INNER JOIN
(
	SELECT LOCATION, SKU, MAX(datemap_week) AS max_WEEK_NO
	FROM #TB_COMBINED_V10_CONTINUOUS
	GROUP BY LOCATION, SKU
) AS t2
ON t1.LOCATION = t2.LOCATION AND t1.SKU = t2.SKU AND t1.datemap_week = t2.max_WEEK_NO

print '#TB_COMBINED_V10_CONTINUOUS_STG_1'
--SELECT * FROM #TB_COMBINED_V10_CONTINUOUS_STG_1


IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL

SELECT *
INTO #TB_PRICE_V10_FINAL
FROM
(
	SELECT * FROM #TB_COMBINED_V10_CONTINUOUS
	WHERE datemap_week <> lead_week
	UNION
	SELECT * FROM #TB_COMBINED_V10_CONTINUOUS_STG_1
) AS a

print '#TB_PRICE_V10_FINAL'

--SELECT * FROM #TB_PRICE_V10_FINAL


IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_REFINED') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_REFINED

SELECT t1.Zone_id
      ,t1.LOCATION
	  ,t1.section_id
	  ,t1.sku
	  ,t1.WEEK_NO
	  ,t1.SALES
	  ,t1.VOL
	  ,ISNULL(t1.asp, 0 ) AS asp
	  ,ISNULL(COALESCE(t2.base_price, t3.calc_base_price, t1.asp),0) AS Base_Price
	  ,ISNULL(t4.section_volume,0) AS section_volume
INTO #TB_PRICE_V10_FINAL_REFINED
FROM #SKU_ASP AS t1
LEFT JOIN 
(SELECT DISTINCT * FROM #PROMOTION_DATA_FINAL_V9 WHERE PROMOTION_KEY <> NULL) AS t2
ON t2.PRICE_ZONE = t1.Zone_id AND t2.SKU = t1.sku AND t2.PROM_WEEK_NO = t1.WEEK_NO
LEFT JOIN (SELECT LOCATION,SKU,WEEK_NO,calc_base_price FROM #TB_PRICE_V10_FINAL) AS t3
ON t3.LOCATION = t1.LOCATION AND t3.SKU = t1.sku AND t3.WEEK_NO = t1.WEEK_NO
LEFT JOIN
(
	 SELECT DISTINCT LOCATION, section_id, WEEK_NO, SUM(Vol) AS section_volume 
	 FROM #SKU_ASP
	 GROUP BY LOCATION, section_id, WEEK_NO
) AS t4
ON t1.LOCATION = t4.LOCATION AND t1.section_id = t4.section_id AND t1.WEEK_NO = t4.WEEK_NO

print '#TB_PRICE_V10_FINAL_REFINED'
--SELECT * FROM #TB_PRICE_V10_FINAL_REFINED

IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_REFINED_PLUS_VARS') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS

SELECT Zone_id
      ,LOCATION
	  ,section_id
	  ,sku
	  ,WEEK_NO
	  ,SALES
	  ,VOL
	  ,asp
	  ,Base_Price
	  ,section_volume 
	  ,CASE WHEN section_volume = 0 OR Base_Price = 0 THEN 0 ELSE (VOL / section_volume) * (asp / Base_Price) END AS weighted_di
	  ,CASE WHEN section_volume = 0 THEN 0 ELSE (VOL / section_volume) * asp END AS weighted_asp
	  ,CASE WHEN section_volume = 0 THEN 0 ELSE (VOL / section_volume) * Base_Price END AS weighted_bp
INTO #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS
FROM #TB_PRICE_V10_FINAL_REFINED

print '#TB_PRICE_V10_FINAL_REFINED_PLUS_VARS'
--SELECT * FROM #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS


IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA_FINAL_10') IS NOT NULL
	DROP TABLE #PROMOTION_DATA_FINAL_V10

SELECT DISTINCT * -- IT is removing duplicate records from the result of union (union also does but to make sure after merging)
INTO #PROMOTION_DATA_FINAL_V10
FROM #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS

--PRINT '#PROMOTION_DATA_FINAL_V10'


--INSERT INTO TARGET TB_TGT_PROMOTION_DATA_FINAL_V10

IF OBJECT_ID('TB_TGT_PROMOTION_DATA_FINAL_V10') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_PROMOTION_DATA_FINAL_V10
	SELECT DISTINCT * 
	FROM #PROMOTION_DATA_FINAL_V10
	PRINT 'Inserted records into existing table (TB_TGT_PROMOTION_DATA_FINAL_V10).'
END
ELSE
BEGIN
	SELECT DISTINCT * 
	INTO TB_TGT_PROMOTION_DATA_FINAL_V10
	FROM #PROMOTION_DATA_FINAL_V10
	PRINT 'Created the table (TB_TGT_PROMOTION_DATA_FINAL_V10) and inserted the records.'
END

print 'PROMOTION_DATA_FINAL_V10 was populated'


IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_WGT_DI_ASP') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_WGT_DI_ASP

SELECT LOCATION
	  ,section_id
	  ,WEEK_NO
	  ,SUM(weighted_di) AS section_di
	  ,SUM(weighted_asp) AS wgt_section_asp
	  ,SUM(weighted_bp) AS weighted_bp
	  ,1 - SUM(weighted_di) AS di
INTO #TB_PRICE_V10_FINAL_WGT_DI_ASP
FROM #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS
GROUP BY LOCATION
	  ,section_id
	  ,WEEK_NO

print '#TB_PRICE_V10_FINAL_WGT_DI_ASP'
--SELECT * FROM #TB_PRICE_V10_FINAL_WGT_DI_ASP


IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO


SELECT CAST(SKU_Number AS INT) AS SKU
	 ,CAST(LOC_IDNT AS INT) AS LOCATION
	 ,CAST(start_wk AS INT) AS START_WEEK
	 ,CAST(end_wk AS INT) AS END_WEEK
INTO #V10_PROMO_INFO
FROM dbo.TB_STG_V10_PROMO_INFO WHERE CAST(LOC_IDNT AS INT) IN (2,3) -- LOC_IDNT TO BE REMOVED
AND ( CAST(END_WK AS INT) <> 0 
OR CAST(END_WK AS INT) <> '' 
OR CAST(END_WK AS INT) IS NOT NULL)

print '#V10_PROMO_INFO'
--SELECT * FROM #V10_PROMO_INFO

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS

SELECT SKU
	 ,LOCATION
	 ,START_WEEK
	 ,END_WEEK 
	 ,dm.WEEK_NO AS WEEK_NO
INTO #V10_PROMO_INFO_CONTINUOUS
FROM #V10_PROMO_INFO AS q1
CROSS JOIN (SELECT DISTINCT WEEK_NO, PRV_WEEK_NO FROM dbo.TB_STG_DATE_MAP_DIM) AS dm
WHERE dm.WEEK_NO >= q1.START_WEEK AND dm.WEEK_NO <= q1.END_WEEK 

print '#V10_PROMO_INFO_CONTINUOUS'
--SELECT * FROM #V10_PROMO_INFO_CONTINUOUS

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU

SELECT t1.LOCATION
	  ,t1.section_id	
	  ,t1.SKU
	  ,t1.WEEK_NO
	  ,COALESCE(t2.SKU, t3.SKU) AS promo_sku
INTO #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU
FROM #SKU_ASP AS t1
LEFT JOIN 
(
	SELECT DISTINCT * FROM #PROMOTION_DATA_FINAL_V9 WHERE PROMOTION_KEY <> NULL OR PROMOTION_KEY <> 0
) AS t2
ON t1.Zone_id = t2.PRICE_ZONE AND t1.sku = t2.SKU AND t1.WEEK_NO = t2.PROM_WEEK_NO
LEFT JOIN #V10_PROMO_INFO_CONTINUOUS AS t3
ON t1.LOCATION = t3.LOCATION AND t1.sku		= t3.SKU AND t1.WEEK_NO = t3.WEEK_NO

print '#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU'
--SELECT * FROM #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU


IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT

SELECT LOCATION
	  ,section_id
	  ,WEEK_NO
	  ,COUNT(DISTINCT promo_sku)  AS promo_count
INTO #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT
FROM #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU
GROUP BY LOCATION
	  ,section_id
	  ,WEEK_NO

print '#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT'
--SELECT * FROM #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT

/*                      PROMOTION ENDS                             */




/* Create variables based on space, range and positions like disruptions etc
   also join #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp to include wt_price_diff1 variables */

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS

SELECT t1.store_id
	  ,t1.section_id
	  ,t1.fp_version
	  ,t1.week_no
	  ,bay_count
	  ,X
	  ,Y
	  ,prod_allocated
	  ,space_flag
	  ,range_flag
	  ,pos_flag
	  ,space_disruption_1wk 
	  ,range_disruption_1wk
	  ,position_disp_1wk
	  ,space_disruption_2wk 
	  ,range_disruption_2wk
	  ,position_disp_2wk
	  ,space_disruption_3wk 
	  ,range_disruption_3wk
	  ,position_disp_3wk
	  ,SQRT(SQUARE(X - lag_x) + SQUARE(Y - lag_y)) AS gradient_distance
	  ,pos_flag + position_disp_3wk AS position_disp_4wk
	  ,(SQRT(SQUARE(X - lag_x) + SQUARE(Y - lag_y))) * (pos_flag + position_disp_3wk) AS gradient_disp_4wk
	  ,ISNULL(CAST(t2.sku_churned AS INT), 0) AS cnt_sku_churned
	  ,reference_sec_x
	  ,reference_sec_y
	  ,pos_distance1
	  ,position_distance
	  ,lag_position_distance
	  ,position_flag
	  ,lag_position_flag
	  ,lag_lag_position_flag
	  ,lag_lag_lag_position_flag
	  ,IIF(t1.store_id = lag_location AND t1.section_id = lag_section_id AND lag_position_flag = 1, 1,0) AS position_disruption_1wk
	  ,IIF(t1.store_id = lag_location AND t1.section_id = lag_section_id AND (lag_position_flag = 1 OR lag_lag_position_flag = 1), 1,0) AS position_disruption_2wk
	  ,IIF(t1.store_id = lag_location AND t1.section_id = lag_section_id AND (lag_position_flag = 1 OR lag_lag_position_flag = 1 OR lag_lag_lag_position_flag = 1), 1,0) AS position_disruption_3wk
	  ,t1.week_no_jda
	  ,t3.wt_price_diff1
	  ,t4.wgt_section_asp
	  ,t4.weighted_bp
	  ,t4.di
	  ,t5.promo_count
INTO #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS
FROM #CONITNUOUS_JDA_STG_3 AS t1
LEFT JOIN [dbo].[TB_STG_SKU_CHURN] AS t2 
ON t1.store_id = CAST(t2.store AS INT) 
	AND t1.section_id = CAST(t2.section AS INT) 
	AND t1.week_no_jda = CAST(t2.week_no AS INT)
LEFT JOIN #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp AS t3
ON t1.store_id = t3.store_id 
	AND t1.section_id = t3.section_id 
	AND t1.week_no_jda = t3.week_no_jda
LEFT JOIN #TB_PRICE_V10_FINAL_WGT_DI_ASP AS t4
ON t1.store_id = t4.LOCATION 
	AND t1.section_id = t4.section_id 
	AND t1.week_no = t4.WEEK_NO
LEFT JOIN #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT AS t5
ON t1.store_id = t5.LOCATION 
	AND t1.section_id = t5.section_id 
	AND t1.week_no = t5.WEEK_NO


print '#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS'

/* Check #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS */
--SELECT * FROM #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS

SELECT store_id
	  ,section_id
	  ,fp_version
	  ,week_no
	  ,bay_count
	  ,X
	  ,Y
	  ,prod_allocated
	  ,space_flag
	  ,range_flag
	  ,pos_flag
	  ,space_disruption_1wk 
	  ,range_disruption_1wk
	  ,position_disp_1wk
	  ,space_disruption_2wk 
	  ,range_disruption_2wk
	  ,position_disp_2wk
	  ,space_disruption_3wk 
	  ,range_disruption_3wk
	  ,position_disp_3wk
	  ,gradient_distance
	  ,position_disp_4wk
	  ,gradient_disp_4wk
	  ,cnt_sku_churned
	  ,reference_sec_x
	  ,reference_sec_y
	  ,pos_distance1
	  ,position_distance
	  ,lag_position_distance
	  ,position_flag
	  ,lag_position_flag
	  ,lag_lag_position_flag
	  ,lag_lag_lag_position_flag
	  ,position_disruption_1wk
	  ,position_disruption_2wk
	  ,position_disruption_3wk
	  ,week_no_jda
	  ,wt_price_diff1
	  ,wgt_section_asp
	  ,weighted_bp
	  ,CASE WHEN promo_count = 0 OR di < 0 THEN 0 WHEN di > 1 THEN 1 ELSE di END AS di
	  ,CASE WHEN promo_count > prod_allocated THEN prod_allocated ELSE promo_count END AS promo_count
	  ,ROUND(((CASE WHEN promo_count > prod_allocated THEN prod_allocated ELSE promo_count END) / prod_allocated), 2) AS pa_ratio
INTO #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS
FROM #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS

print '#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS'
--SELECT * FROM #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS

/* Join #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS with #TB_SALES_SECTION_DATA_STG_3
   and include the variables of space, range and position */

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_4') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_4

SELECT tb1.LOCATION
	  ,tb1.SECTION_ID
	  ,tb1.fp_version
	  ,tb1.WEEK_NO
	  ,tb1.X
	  ,tb1.Y
	  ,tb1.section_width
	  ,tb1.prod_allocated
	  ,tb1.Zone_id
	  ,tb1.LOCATION_TRAIT_ID
	  ,tb1.Total_SALES
	  ,tb1.Total_VOL
	  ,tb1.Total_PPA
	  ,tb1.Total_WASTE_COST
	  ,tb1.Total_SHRINKAGE_COST
	  ,tb1.Total_WASTE_RETAIL
	  ,tb1.Total_SHRINKAGE_RETAIL
	  ,tb1.REGION
	  ,tb1.MAX_CELSIUS_high
	  ,tb1.MAX_CELSIUS_low
	  ,tb1.MAX_CELSIUS_avg
	  ,tb1.MIN_CELSIUS_high
	  ,tb1.MIN_CELSIUS_low
	  ,tb1.MIN_CELSIUS_avg
	  ,tb1.SUN_HOURS_high
	  ,tb1.SUN_HOURS_low
	  ,tb1.SUN_HOURS_avg
	  ,tb1.RAIN_MM_high
	  ,tb1.RAIN_MM_low
	  ,tb1.RAIN_MM_avg
	  ,tb1.SUB_CATEGORY_CNT
	  ,tb1.Region_EDW
	  ,tb1.Region_Name_EDW
	  ,tb1.Trait_Store_Type
	  ,tb1.ZONE_NO
	  ,tb1.ZONE_NAME
	  ,tb1.cluster
	  ,tb1.F_store_size
	  ,tb1.NS_Store_Size
	  ,tb1.T_Store_size
	  ,tb1.ACTIVE_DAYS
	  ,tb1.Act_days_0
	  ,tb1.Act_days_1
	  ,tb1.Act_days_2
	  ,tb1.Act_days_3
	  ,tb1.Act_days_4
	  ,tb1.Act_days_5
	  ,tb1.Act_days_6
	  ,tb1.Act_days_7
	  ,tb1.CLOSURE_DAYS
	  ,tb1.pre_christmas_ind
	  ,tb1.christmas_ind
	  ,tb1.post_christmas_ind
	  ,tb1.pre_easter_ind
	  ,tb1.easter_ind
	  ,tb1.post_easter_ind
	  ,tb1.holiday_ind
	  ,tb1.event_ind
	  ,tb1.Bank_IND
	  ,tb1.Religion_IND
	  ,tb1.Special_IND
	  ,tb1.Sponsorship_IND
	  ,tb1.Sports_IND
	  ,tb1.comp_0_1
	  ,tb1.comp_1_2
	  ,tb1.comp_2_n
	  ,tb1.c_week_no
	  ,tb1.concession_flag
	  ,tb1.concession_size
	  ,ROUND(tb1.argos_ts_ratio, 2) AS argos_ts_ratio
	  ,ROUND(tb1.argos_ns_ratio, 2) AS argos_ns_ratio
	  ,tb1.StartOnSite_Week_No
	  ,tb1.ReLaunch_Week_No
	  ,tb1.invest_flag
	  ,tb1.invest_new_flag
	  ,tb1.invest_refurbi_flag
	  ,tb1.invest_other_flag
	  ,tb1.invest_close_1
	  ,tb1.invest_close_2
	  ,tb1.invest_close_3
	  ,tb1.invest_close_4
	  ,tb1.invest_close_5
	  ,tb1.invest_close_6
	  ,tb1.invest_close_7
	  ,tb1.invest_close
	  ,tb2.space_flag
	  ,tb2.range_flag
	  ,tb2.pos_flag
	  ,tb2.space_disruption_1wk 
	  ,tb2.range_disruption_1wk
	  ,tb2.position_disp_1wk
	  ,tb2.space_disruption_2wk 
	  ,tb2.range_disruption_2wk
	  ,tb2.position_disp_2wk
	  ,tb2.space_disruption_3wk 
	  ,tb2.range_disruption_3wk
	  ,tb2.position_disp_3wk
	  ,tb2.gradient_distance
	  ,tb2.gradient_disp_4wk
	  ,tb2.cnt_sku_churned
	  ,tb2.pos_distance1
	  ,tb2.position_distance
	  ,tb2.position_flag
	  ,tb2.position_disruption_1wk
	  ,tb2.position_disruption_2wk
	  ,tb2.position_disruption_3wk
	  ,tb2.week_no_jda
	  ,tb2.wt_price_diff1
	  ,tb2.wgt_section_asp
	  ,tb2.weighted_bp
	  ,tb2.di
	  ,tb2.promo_count
	  ,tb2.pa_ratio
INTO #TB_SALES_SECTION_DATA_STG_4
FROM #TB_SALES_SECTION_DATA_STG_3 AS tb1
LEFT JOIN #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS AS tb2
ON tb1.LOCATION = tb2.store_id AND tb1.SECTION_ID = tb2.section_id AND tb1.WEEK_NO = tb2.week_no

print '#TB_SALES_SECTION_DATA_STG_4'
/* Check #TB_SALES_SECTION_DATA_STG_4 */
--SELECT * FROM #TB_SALES_SECTION_DATA_STG_4


/* Calculate sales, volume and asp from TB_TGT_SALES_SKU_DATA */

IF OBJECT_ID('TempDB.dbo.#Sales_Vol_ASP') IS NOT NULL
	DROP TABLE #Sales_Vol_ASP

SELECT section_id
	  ,sku
	  ,SUM(Sales) AS sales
	  ,SUM(vol) AS volume
	  ,CASE WHEN SUM(vol) = 0 THEN 0 ELSE SUM(Sales)/SUM(vol) END AS asp
INTO #Sales_Vol_ASP
FROM TB_TGT_SALES_SKU_DATA
WHERE ((@start_week IS NULL AND @end_week IS NULL) OR WEEK_NO BETWEEN @start_week AND @end_week)
	  AND ((@loc_trait_id IS NULL) OR LOCATION_TRAIT_ID = @loc_trait_id)
	  AND Zone_id IS NOT NULL
GROUP BY section_id, sku

print '#Sales_Vol_ASP'
--SELECT * FROM #Sales_Vol_ASP


/* Check #Sales_Vol_ASP */
--SELECT * FROM #Sales_Vol_ASP

/* Calculate quartile for volume and asp and derive the LI variable */

IF OBJECT_ID('TempDB.dbo.#Sales_Vol_ASP_Li') IS NOT NULL
	DROP TABLE #Sales_Vol_ASP_Li

SELECT t1.section_id
	  ,t1.sku
	  ,t1.sales
	  ,t1.volume
	  ,t1.asp
	  ,t2.Q25_vol
	  ,t2.Q50_vol
	  ,t2.Q75_vol
	  ,t2.Q25_asp
	  ,t2.Q50_asp
	  ,t2.Q75_asp
	  ,CASE WHEN asp >= Q50_asp AND volume >= Q50_vol THEN 'Luxury_Essential'
			WHEN asp >= Q50_asp AND volume <= Q50_vol THEN 'Luxury_Non_Essential'
			WHEN asp <= Q50_asp AND volume >= Q50_vol THEN 'Basic_Essential'
			WHEN asp <= Q50_asp AND volume <= Q50_vol THEN 'Basic_Non_Essential'
			WHEN asp >= Q25_vol AND asp <= Q75_asp AND volume >= Q25_vol AND volume <= Q75_vol THEN 'Commodity'
	   END AS Li
INTO #Sales_Vol_ASP_Li
FROM #Sales_Vol_ASP AS t1
LEFT JOIN 
(
	SELECT DISTINCT section_id
		  ,Percentile_Cont(0.25) WITHIN GROUP(Order By volume) OVER(PARTITION BY section_id) As Q25_vol
		  ,Percentile_Cont(0.50) WITHIN GROUP(Order By volume) OVER(PARTITION BY section_id) As Q50_vol
		  ,Percentile_Cont(0.75) WITHIN GROUP(Order By volume) OVER(PARTITION BY section_id) As Q75_vol
		  ,Percentile_Cont(0.25) WITHIN GROUP(Order By asp) OVER(PARTITION BY section_id) As Q25_asp
		  ,Percentile_Cont(0.50) WITHIN GROUP(Order By asp) OVER(PARTITION BY section_id) As Q50_asp
		  ,Percentile_Cont(0.75) WITHIN GROUP(Order By asp) OVER(PARTITION BY section_id) As Q75_asp
	FROM #Sales_Vol_ASP
) AS t2
ON t1.section_id = t2.section_id

print '#Sales_Vol_ASP_Li'
/* Check #Sales_Vol_ASP_Li */
--SELECT * FROM #Sales_Vol_ASP_Li 

/* Merge TB_TGT_CONTINUOUS_JDA and  #Sales_Vol_ASP_Li and include the LI variable*/

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI

SELECT DISTINCT t1.store_id
	  ,t1.section_id
	  ,t1.sku
	  ,fp_version
	  ,week_no_jda
	  ,week_no
	  ,t2.Li
INTO #CONT_JDA_PLUS_LI
FROM [dbo].TB_TGT_CONTINUOUS_JDA AS t1
INNER JOIN #Sales_Vol_ASP_Li AS t2
ON t1.section_id = t2.section_id AND t1.sku = t2.sku

print '#CONT_JDA_PLUS_LI'
/* Check #CONT_JDA_PLUS_LI */
--SELECT * FROM #CONT_JDA_PLUS_LI

/* Calculate the Li counts */

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI_COUNTS') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI_COUNTS

SELECT store_id
	  ,section_id
	  ,week_no
	  ,Li
	  ,COUNT(sku) AS count_sku_li 
INTO #CONT_JDA_PLUS_LI_COUNTS
FROM #CONT_JDA_PLUS_LI
GROUP BY store_id,section_id,week_no,Li

print '#CONT_JDA_PLUS_LI_COUNTS'
/* Check #CONT_JDA_PLUS_LI_COUNTS */
--SELECT * FROM #CONT_JDA_PLUS_LI_COUNTS

/* Create the pivot from #CONT_JDA_PLUS_LI_COUNTS to get the counts of LI in columns */

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI_COUNTS_PIVOTED') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI_COUNTS_PIVOTED

SELECT store_id 
	  ,section_id
	  ,week_no
	  ,ISNULL(Luxury_Essential,0) AS Luxury_Essential
	  ,ISNULL(Luxury_Non_Essential,0) AS Luxury_Non_Essential
	  ,ISNULL(Basic_Essential,0) AS Basic_Essential
	  ,ISNULL(Basic_Non_Essential,0) AS Basic_Non_Essential
	  ,ISNULL(Commodity,0) AS Commodity
INTO #CONT_JDA_PLUS_LI_COUNTS_PIVOTED
FROM
(	
	SELECT store_id
			,section_id
			,week_no
			,Li
			,count_sku_li = ISNULL(count_sku_li,0)
	FROM #CONT_JDA_PLUS_LI_COUNTS
) AS SourceTable
PIVOT
(
	 SUM(count_sku_li)
	 FOR Li IN (Luxury_Essential,Luxury_Non_Essential,Basic_Essential,Basic_Non_Essential
	 ,Commodity
	 )
) AS PivotTable;

print '#CONT_JDA_PLUS_LI_COUNTS_PIVOTED'
/* Check #CONT_JDA_PLUS_LI_COUNTS_PIVOTED */
--SELECT * FROM #CONT_JDA_PLUS_LI_COUNTS_PIVOTED

/* Join #TB_SALES_SECTION_DATA_STG_4 
   with #CONT_JDA_PLUS_LI_COUNTS_PIVOTED
   and include the counts of LI*/

/*NOTE: EVENT TABLE IS TO BE JOINED - TODO:// */

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_FINAL') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_FINAL

SELECT tb1.LOCATION
	  ,tb1.SECTION_ID
	  ,tb1.fp_version
	  ,tb1.WEEK_NO
	  ,tb1.X
	  ,tb1.Y
	  ,tb1.section_width
	  ,tb1.prod_allocated
	  ,tb1.Zone_id
	  ,tb1.LOCATION_TRAIT_ID
	  ,tb1.Total_SALES
	  ,tb1.Total_VOL
	  ,tb1.Total_PPA
	  ,tb1.Total_WASTE_COST
	  ,tb1.Total_SHRINKAGE_COST
	  ,tb1.Total_WASTE_RETAIL
	  ,tb1.Total_SHRINKAGE_RETAIL
	  ,tb1.REGION
	  ,tb1.MAX_CELSIUS_high
	  ,tb1.MAX_CELSIUS_low
	  ,tb1.MAX_CELSIUS_avg
	  ,tb1.MIN_CELSIUS_high
	  ,tb1.MIN_CELSIUS_low
	  ,tb1.MIN_CELSIUS_avg
	  ,tb1.SUN_HOURS_high
	  ,tb1.SUN_HOURS_low
	  ,tb1.SUN_HOURS_avg
	  ,tb1.RAIN_MM_high
	  ,tb1.RAIN_MM_low
	  ,tb1.RAIN_MM_avg
	  ,tb1.SUB_CATEGORY_CNT
	  ,tb1.Region_EDW
	  ,tb1.Region_Name_EDW
	  ,tb1.Trait_Store_Type
	  ,tb1.ZONE_NO
	  ,tb1.ZONE_NAME
	  ,tb1.cluster
	  ,tb1.F_store_size
	  ,tb1.NS_Store_Size
	  ,tb1.T_Store_size
	  ,tb1.ACTIVE_DAYS
	  ,tb1.Act_days_0
	  ,tb1.Act_days_1
	  ,tb1.Act_days_2
	  ,tb1.Act_days_3
	  ,tb1.Act_days_4
	  ,tb1.Act_days_5
	  ,tb1.Act_days_6
	  ,tb1.Act_days_7
	  ,tb1.CLOSURE_DAYS
	  ,tb1.pre_christmas_ind
	  ,tb1.christmas_ind
	  ,tb1.post_christmas_ind
	  ,tb1.pre_easter_ind
	  ,tb1.easter_ind
	  ,tb1.post_easter_ind
	  ,tb1.holiday_ind
	  ,tb1.event_ind
	  ,tb1.Bank_IND
	  ,tb1.Religion_IND
	  ,tb1.Special_IND
	  ,tb1.Sponsorship_IND
	  ,tb1.Sports_IND
	  ,tb1.comp_0_1
	  ,tb1.comp_1_2
	  ,tb1.comp_2_n
	  ,tb1.c_week_no
	  ,tb1.concession_flag
	  ,tb1.concession_size
	  ,tb1.argos_ts_ratio
	  ,tb1.argos_ns_ratio
	  ,tb1.StartOnSite_Week_No
	  ,tb1.ReLaunch_Week_No
	  ,tb1.invest_flag
	  ,tb1.invest_new_flag
	  ,tb1.invest_refurbi_flag
	  ,tb1.invest_other_flag
	  ,tb1.invest_close_1
	  ,tb1.invest_close_2
	  ,tb1.invest_close_3
	  ,tb1.invest_close_4
	  ,tb1.invest_close_5
	  ,tb1.invest_close_6
	  ,tb1.invest_close_7
	  ,tb1.invest_close
	  ,tb1.space_flag
	  ,tb1.range_flag
	  ,tb1.pos_flag
	  ,tb1.space_disruption_1wk 
	  ,tb1.range_disruption_1wk
	  ,tb1.position_disp_1wk
	  ,tb1.space_disruption_2wk 
	  ,tb1.range_disruption_2wk
	  ,tb1.position_disp_2wk
	  ,tb1.space_disruption_3wk 
	  ,tb1.range_disruption_3wk
	  ,tb1.position_disp_3wk
	  ,tb1.gradient_distance
	  ,tb1.gradient_disp_4wk
	  ,tb1.cnt_sku_churned
	  ,tb1.pos_distance1
	  ,tb1.position_distance
	  ,tb1.position_flag
	  ,tb1.position_disruption_1wk
	  ,tb1.position_disruption_2wk
	  ,tb1.position_disruption_3wk
	  ,tb2.Luxury_Essential
	  ,tb2.Luxury_Non_Essential
	  ,tb2.Basic_Essential
	  ,tb2.Basic_Non_Essential
	  ,tb2.Commodity
	  ,ISNULL(tb2.Basic_Essential,0) + ISNULL(tb2.Basic_Non_Essential,0) AS 'basic'
	  ,ISNULL(tb2.Luxury_Essential,0) + ISNULL(tb2.Luxury_Non_Essential,0) AS 'luxury'
	  ,tb1.week_no_jda
	  ,tb1.wt_price_diff1
	  ,tb1.wgt_section_asp
	  ,tb1.weighted_bp
	  ,tb1.di
	  ,tb1.promo_count
	  ,tb1.pa_ratio
	  ,tb3.*
INTO #TB_SALES_SECTION_DATA_FINAL
FROM #TB_SALES_SECTION_DATA_STG_4 AS tb1
LEFT JOIN #CONT_JDA_PLUS_LI_COUNTS_PIVOTED AS tb2
ON tb1.LOCATION = tb2.store_id AND tb1.SECTION_ID = tb2.section_id AND tb1.week_no = tb2.week_no
LEFT JOIN [dbo].[TB_STG_EVENT_FINAL] AS tb3
ON tb1.LOCATION = CAST(tb3.location_event AS INT) AND tb1.WEEK_NO = CAST(tb3.week_no_event AS INT)


/* Code to insert the records into target table */

--INSERT INTO TARGET TB_TGT_SALES_SECTION_DATA_FINAL

IF OBJECT_ID('TB_TGT_SALES_SECTION_DATA') IS NOT NULL
BEGIN
	INSERT INTO TB_TGT_SALES_SECTION_DATA
	SELECT DISTINCT * 
	FROM #TB_SALES_SECTION_DATA_FINAL
	PRINT 'Inserted records into existing table.'
END
ELSE
BEGIN
	SELECT DISTINCT * 
	INTO TB_TGT_SALES_SECTION_DATA
	FROM #TB_SALES_SECTION_DATA_FINAL
	PRINT 'Created the table and inserted the records.'
END

print 'TB_TGT_SALES_SECTION_DATA was populated'

/* Drop the temporary table "#TB_SALES_SECTION_DATA_FINAL" */

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_FINAL') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_FINAL


/* Drop the temporary tablescreated */

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI_COUNTS_PIVOTED') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI_COUNTS_PIVOTED

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI_COUNTS') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI_COUNTS

IF OBJECT_ID('TempDB.dbo.#CONT_JDA_PLUS_LI') IS NOT NULL
	DROP TABLE #CONT_JDA_PLUS_LI

IF OBJECT_ID('TempDB.dbo.#Sales_Vol_ASP_Li') IS NOT NULL
	DROP TABLE #Sales_Vol_ASP_Li

IF OBJECT_ID('TempDB.dbo.#Sales_Vol_ASP') IS NOT NULL
	DROP TABLE #Sales_Vol_ASP

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_4') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_4

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS_PA_CHECKS

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_SPACE_RANGE_POS_VARS') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_SPACE_RANGE_POS_VARS

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU_PROMOCOUNT

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS_PROMO_SKU') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS_PROMO_SKU

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO_CONTINUOUS') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO_CONTINUOUS

IF OBJECT_ID('TempDB.dbo.#V10_PROMO_INFO') IS NOT NULL
	DROP TABLE #V10_PROMO_INFO

IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_WGT_DI_ASP') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_WGT_DI_ASP

IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA_FINAL_V10') IS NOT NULL
	DROP TABLE #PROMOTION_DATA_FINAL_V10
	

IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_REFINED_PLUS_VARS') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_REFINED_PLUS_VARS

IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL_REFINED') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL_REFINED

IF OBJECT_ID('TempDB.dbo.#TB_PRICE_V10_FINAL') IS NOT NULL
	DROP TABLE #TB_PRICE_V10_FINAL

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_CONTINUOUS_STG_1') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_CONTINUOUS_STG_1

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_CONTINUOUS') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_CONTINUOUS

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ_LEAD_WK

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK_UNQ

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ_WEEK') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ_WEEK

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA_UNQ') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA_UNQ

IF OBJECT_ID('TempDB.dbo.#TB_COMBINED_V10_DATA') IS NOT NULL
	DROP TABLE #TB_COMBINED_V10_DATA

IF OBJECT_ID('TempDB.dbo.#TB_STG_PRICE_V10_ZONE_FINAL') IS NOT NULL
	DROP TABLE #TB_STG_PRICE_V10_ZONE_FINAL

IF OBJECT_ID('TempDB.dbo.#TB_STG_PRICE_V10_FINAL') IS NOT NULL
	DROP TABLE #TB_STG_PRICE_V10_FINAL

IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA_FINAL_V9') IS NOT NULL
	DROP TABLE #PROMOTION_DATA_FINAL_V9

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2_CLEANED') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2_CLEANED

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2_BASE_PRICE') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2_BASE_PRICE

IF OBJECT_ID('TempDB.dbo.#FINALBP') IS NOT NULL
	DROP TABLE #FINALBP

IF OBJECT_ID('TempDB.dbo.#PRIORBP') IS NOT NULL
	DROP TABLE #PRIORBP

IF OBJECT_ID('TempDB.dbo.#LOADBP') IS NOT NULL
	DROP TABLE #LOADBP

IF OBJECT_ID('TempDB.dbo.#MERGED_TBL1_TBL2') IS NOT NULL
	DROP TABLE #MERGED_TBL1_TBL2

IF OBJECT_ID('TempDB.dbo.#TABLE2') IS NOT NULL
	DROP TABLE #TABLE2

IF OBJECT_ID('TempDB.dbo.#TABLE1') IS NOT NULL
	DROP TABLE #TABLE1

IF OBJECT_ID('TempDB.dbo.#PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA') IS NOT NULL
	DROP TABLE #PROMO_INFO_V9_UNQ_NOT_IN_PROMO_DATA

IF OBJECT_ID('TempDB.dbo.#PROMOTION_DATA') IS NOT NULL
	DROP TABLE #PROMOTION_DATA

IF OBJECT_ID('TempDB.dbo.#PROMO_INFO_V9_UNQ') IS NOT NULL
	DROP TABLE #PROMO_INFO_V9_UNQ

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Plus_DerivedVars_RolledUp

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Plus_DerivedVars') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Plus_DerivedVars

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs_Sales_Vol_Asp

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE_Add_Rem_SKUs') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE_Add_Rem_SKUs

IF OBJECT_ID('TempDB.dbo.#TB_SKU_CHURNED_PRICE') IS NOT NULL
	DROP TABLE #TB_SKU_CHURNED_PRICE

IF OBJECT_ID('TempDB.dbo.#SKU_ASP') IS NOT NULL
	DROP TABLE #SKU_ASP

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_3') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_3

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_2') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_2

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG_1') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG_1

IF OBJECT_ID('TempDB.dbo.#CONITNUOUS_JDA_STG') IS NOT NULL
	DROP TABLE #CONITNUOUS_JDA_STG

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_3') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_3

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_2') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_2

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA_STG_1') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA_STG_1

IF OBJECT_ID('TempDB.dbo.#TB_SALES_SECTION_DATA') IS NOT NULL
	DROP TABLE #TB_SALES_SECTION_DATA



/* To create a fact for OCT_DATA, Derive the OCT_DATA_BASE table from TB_TGT_CONTINUOUS_JDA 
   and calculate the variable and take the lag value */

IF OBJECT_ID('TempDB.dbo.#OTC_DATA_BASE') IS NOT NULL
	DROP TABLE #OTC_DATA_BASE

SELECT store_id
	   ,section_id
	   ,fp_version
	   ,week_no_jda
	   ,section_width
	   ,POG_Width
	   ,section_width_minus_pog_width
	   ,OTC_flag
	   ,LAG(OTC_flag) OVER(ORDER BY store_id, section_id, fp_version) AS lag_OTC_flag
INTO #OTC_DATA_BASE
FROM
(
	SELECT DISTINCT store_id
		   ,section_id
		   ,fp_version
		   ,week_no_jda
		   ,CAST(section_width AS INT) AS section_width
		   ,CAST(POG_Width AS INT) AS POG_Width
		   ,CAST(section_width AS INT) - CAST(POG_Width AS INT) AS section_width_minus_pog_width
		   ,IIF(ABS(CAST(section_width AS INT) - CAST(POG_Width AS INT)) > 125, 1, 0) AS OTC_flag
	FROM [dbo].TB_TGT_CONTINUOUS_JDA
) AS t1

print '#OTC_DATA_BASE'
/* Check #OTC_DATA_BASE*/
--SELECT * FROM #OTC_DATA_BASE

/* Drive movement column and filter the data set on movement to create the final OCT_DATA fact table */

IF OBJECT_ID('TempDB.dbo.#OTC_DATA_FINAL') IS NOT NULL
	DROP TABLE #OTC_DATA_FINAL

SELECT store_id
	   ,section_id
	   ,fp_version
	   ,week_no_jda
	   ,section_width
	   ,POG_Width
	   ,section_width_minus_pog_width
	   ,OTC_flag
	   ,lag_OTC_flag 
	   ,OTC_flag - lag_OTC_flag AS dev_flag
	   ,movement
INTO #OTC_DATA_FINAL
FROM
( 
	SELECT store_id
		   ,section_id
		   ,fp_version
		   ,week_no_jda
		   ,section_width
		   ,POG_Width
		   ,section_width_minus_pog_width
		   ,OTC_flag
		   ,lag_OTC_flag 
		   ,OTC_flag - lag_OTC_flag AS dev_flag
		   ,CASE WHEN OTC_flag - lag_OTC_flag = 1 THEN 'Moved to OTC'
				 WHEN OTC_flag - lag_OTC_flag = -1 THEN 'Moved to normal' 
			END AS movement
	FROM #OTC_DATA_BASE
) AS t1
WHERE movement IN ('Moved to OTC','Moved to normal')

print '#OTC_DATA_FINAL'
/* Check #OTC_DATA_FINAL */
--SELECT * FROM #OTC_DATA_FINAL


/* Load the data into table from temporary table "#TB_CONTINUOUS_JDA" */

IF OBJECT_ID('TB_TGT_OTC_DATA_F') IS NOT NULL
BEGIN
	TRUNCATE TABLE TB_TGT_OTC_DATA_F;

	INSERT INTO TB_TGT_OTC_DATA_F
	SELECT * 
	FROM #OTC_DATA_FINAL
	PRINT 'Inserted records into existing table.'
END
ELSE
BEGIN
	SELECT * 
	INTO TB_TGT_OTC_DATA_F
	FROM #OTC_DATA_FINAL
	PRINT 'Created the table and inserted the records.'
END

print 'TB_TGT_OTC_DATA_F was populated'

/* Drop the temporary table "#TB_CONTINUOUS_JDA" */

IF OBJECT_ID('TempDB.dbo.#OTC_DATA_FINAL') IS NOT NULL
	DROP TABLE #OTC_DATA_FINAL

IF OBJECT_ID('TempDB.dbo.#OTC_DATA_BASE') IS NOT NULL
	DROP TABLE #OTC_DATA_BASE

/* Read data from permanent table */

--SELECT * FROM TB_TGT_OTC_DATA_F
/*

*/


--TARGETED TABES
--TB_TGT_PROMOTION_DATA_FINAL_V9
--TB_TGT_SALES_SECTION_DATA
--TB_TGT_OTC_DATA_F

--SELECT COUNT(*) AS cnt_rows FROM TB_TGT_PROMOTION_DATA_FINAL_V9
--SELECT COUNT(*) AS cnt_rows FROM TB_TGT_SALES_SECTION_DATA
--SELECT COUNT(*) AS cnt_rows FROM TB_TGT_OTC_DATA_F
--SELECT COUNT(*) AS cnt_rows FROM TB_TGT_PROMOTION_DATA_FINAL_V10

--DROP TABLE TB_TGT_PROMOTION_DATA_FINAL_V9
--DROP TABLE TB_TGT_SALES_SECTION_DATA
--DROP TABLE TB_TGT_OTC_DATA_F
--DROP TABLE TB_TGT_PROMOTION_DATA_FINAL_V10

/*------------------------------------Part 3.2 Ends----------------------------------------*/

/*------------------------------------All target tables------------------------------------*/
/*
SELECT COUNT(*) AS cnt_rows FROM TB_TGT_MASTER
SELECT COUNT(*) AS cnt_rows FROM TB_TGT_CONTINUOUS_JDA

SELECT COUNT(*) AS cnt_rows FROM TB_TGT_SALES_SKU_DATA

SELECT COUNT(*) AS cnt_rows FROM TB_TGT_PROMOTION_DATA_FINAL_V9
SELECT COUNT(*) AS cnt_rows FROM TB_TGT_SALES_SECTION_DATA
SELECT COUNT(*) AS cnt_rows FROM TB_TGT_OTC_DATA_F
SELECT COUNT(*) AS cnt_rows FROM TB_TGT_PROMOTION_DATA_FINAL_V10

DROP TABLE TB_TGT_MASTER
DROP TABLE TB_TGT_CONTINUOUS_JDA

DROP TABLE TB_TGT_SALES_SKU_DATA

DROP TABLE TB_TGT_PROMOTION_DATA_FINAL_V9
DROP TABLE TB_TGT_SALES_SECTION_DATA
DROP TABLE TB_TGT_OTC_DATA_F
DROP TABLE TB_TGT_PROMOTION_DATA_FINAL_V10
*/
/*------------------------------------All target tables------------------------------------*/
