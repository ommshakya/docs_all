declare @stdate date=cast('12/13/2017' as date), @eddate date=cast('3/13/2018' as date), @PC Varchar(6)=201714, @PW  Varchar(6)=201740

;with cal as
(
select Calendar_date=@stdate, Prom_Week_No=@PW, Promo_Cycle=@PC, DayNo=1
union all
select Calendar_date=DateAdd(d,1,Calendar_date), Prom_Week_No=cast(IIF(DayNo % 7 =0,Prom_Week_No+1,Prom_Week_No) as varchar(6)), 
Promo_Cycle=cast(IIF(cast(IIF(DayNo % 7 =0,Prom_Week_No+1,Prom_Week_No) as varchar(6)) IN ('201743','201745') AND DayNo % 7 =0,Promo_Cycle+1,
IIF(cast(IIF(DayNo % 7 =0,Prom_Week_No+1,Prom_Week_No) as varchar(6)) IN ('201747','201750') AND DayNo % 7 =0,Promo_Cycle+1, Promo_Cycle)) as varchar(6)), DayNo=DayNo+1
from cal where Calendar_date<@eddate
)

select Calendar_date,Prom_Week_No, Promo_Cycle=concat(left(Promo_Cycle,4),'_',Right(Promo_Cycle,2))  from cal

--SELECT Promo_Cycle, COUNT(Prom_Week_No) AS NOOfWeekInCycle
--FROM cal
--GROUP BY Promo_Cycle