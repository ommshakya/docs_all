create proc testnull
AS
BEGIN
	return null;
END

exec testnull

ALTER proc testtrycatch
AS
BEGIN try
	select 1/0
END try
begin catch
	select ERROR_NUMBER() as ERRORNUMBER
		  ,ERROR_SEVERITY() as ERRORSEVERITY
		  ,ERROR_MESSAGE() as ERRORMESSAGE
		  ,ERROR_LINE() as ERRORLINE
		  ,ERROR_PROCEDURE() as ERRORPROCEDURE
		  ,ERROR_STATE() as ERRORSTATE
end catch

exec testtrycatch


SELECT count(*) + count(*)
select 'name' from [dbo].[child]

select  null + '2'

select sum(null)
select * from [dbo].[LicenseImportSample]
select * from [dbo].[parent]
select * from [dbo].[tblCity]
select * from [dbo].[child]


select stuff((
select  name + ',' from [dbo].[child] for xml path('')
)
,1,1,'') as name


SELECT 
DISTINCT P1.ProjectName, 
(SELECT FirstName +',' FROM EmployeeDetail WHERE EmployeeID = P1.EmployeeDetailID FOR XML PATH(''))
FROM ProjectDetail P1