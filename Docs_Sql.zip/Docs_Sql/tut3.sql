CREATE TABLE GroupColumns
(
	ID INT
	,tag CHAR(1)
	,Val1 CHAR(1)
	,Val2 CHAR(1)	
)
GO 
 
INSERT INTO GroupColumns
VALUES
(1,'A','a','b')
,(2,'A','b','r')
,(3,'M','d','c')
,(4,'A','a','n')
,(5,'M','c','a')
GO


with cte as 
(
select id, val1,tag from GroupColumns where val1 = 'a'
union
select id,val1,tag from GroupColumns where val2 = 'a'
)
select tag, count(tag) as ValCount
from cte group by tag



SELECT
       tag
       ,SUM(CASE val1 WHEN 'a' THEN 1 ELSE 0 END) 
       +SUM(CASE val2 WHEN 'a' THEN 1 ELSE 0 END)       
       ValCount 
FROM GroupColumns
GROUP BY tag