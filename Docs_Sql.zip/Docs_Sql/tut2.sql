CREATE TABLE tbl_strings 
(
	strvalue varchar(5)
	,flag int 
)  
GO
 
INSERT INTO tbl_strings 
VALUES 
('ABC',0)
,('ABC',1)
,('XYZ',0)
,('XYZ',1)
,('PQR',0)
,('PQR',1)
,('PQR',1)
GO


declare @res varchar(250) = ''
select @res=  @res + concat(strvalue,'*',SUM(flag) +1, ' ') 
from tbl_strings group by strvalue
 
select @res AS ConcatString