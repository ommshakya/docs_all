
DECLARE @InputDate DATE = '2020-02-01'
	   ,@FirstDate DATE
       ,@LastDate DATE

SELECT @FirstDate = EOMONTH(@InputDate)
SELECT @LastDate = DATEADD(mm, DATEDIFF(mm, 0, @InputDate), 0)
SELECT DATEDIFF(DAY, @LastDate, @FirstDate) + 1 AS NoOfDaysInMonth

DECLARE @InputDate1 DateTime = '2020-02-01'
SELECT Day(@InputDate1)
SELECT @InputDate1 - Day(@InPutDate1)
SELECT DateAdd(Month,1, @InPutDate1)
SELECT DateAdd(Month,1, @InPutDate1) - Day(@InputDate1)
Select DateDiff(Day, @InputDate1 - Day(@InPutDate1) ,DateAdd(Month,1,@InPutDate1) - Day(@InputDate1)) As NumberOfDays