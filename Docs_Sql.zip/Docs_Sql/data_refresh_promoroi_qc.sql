/*Query to extract the DASHBOAR data for DAs/Team


SELECT * FROM TB_PROMO_ROI_DATA WHERE [PROMO CYCLE] = '2017_05'
SELECT * FROM TB_ACCURACY_COVERAGE_TRACKER WHERE [PROMO_CYCLE] = '2017_05'

*/


/*QC the counts of the records in the corresponding tables
TB_PROMO_ROI_DATA
TB_PROMO_ROI_FACT
TB_PROMOTION_ROI_FACT
in both the databases - PromoROI, PromotionsROI.

Status: The counts of corresponding tables should be equal in both DB.

NOTE: This qc is done after running the first part of the "Load final promotional into azure environment package."
*/
DECLARE @cnt_TB_PROMO_ROI_DATA_promoroi INT
          ,@cnt_TB_PROMO_ROI_DATA_promotionsroi INT
          ,@cnt_TB_PROMO_ROI_FACT_promoroi INT
          ,@cnt_TB_PROMO_ROI_FACT_promotionsroi INT
          ,@cnt_TB_PROMOTION_ROI_FACT_promoroi INT
          ,@cnt_TB_PROMOTION_ROI_FACT_promotionsroi INT

SELECT @cnt_TB_PROMO_ROI_DATA_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMO_ROI_DATA
SELECT @cnt_TB_PROMO_ROI_DATA_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMO_ROI_DATA

SELECT @cnt_TB_PROMO_ROI_FACT_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMO_ROI_FACT
SELECT @cnt_TB_PROMO_ROI_FACT_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMO_ROI_FACT

SELECT @cnt_TB_PROMOTION_ROI_FACT_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMOTION_ROI_FACT
SELECT @cnt_TB_PROMOTION_ROI_FACT_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMOTION_ROI_FACT

IF @cnt_TB_PROMO_ROI_DATA_promoroi = @cnt_TB_PROMO_ROI_DATA_promotionsroi
       PRINT 'TB_PROMO_ROI_DATA is OK : (PromoROI) ' + CAST(@cnt_TB_PROMO_ROI_DATA_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMO_ROI_DATA_promotionsroi AS VARCHAR(10))

IF @cnt_TB_PROMO_ROI_FACT_promoroi = @cnt_TB_PROMO_ROI_FACT_promotionsroi
       PRINT 'TB_PROMO_ROI_FACT is OK : (PromoROI) ' + CAST(@cnt_TB_PROMO_ROI_FACT_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMO_ROI_FACT_promotionsroi AS VARCHAR(10))

IF @cnt_TB_PROMOTION_ROI_FACT_promoroi = @cnt_TB_PROMOTION_ROI_FACT_promotionsroi
       PRINT 'TB_PROMOTION_ROI_FACT is OK : (PromoROI) ' + CAST(@cnt_TB_PROMOTION_ROI_FACT_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMOTION_ROI_FACT_promotionsroi AS VARCHAR(10))


/* After qc - Give the data befor MSTR to the DAs(team) for further qc.
Extract the data from VW_PROMO_ROI_FACT, TB_SKU_DIM &  VW_PRODUCT_DIM
for the current cycle.
NOTE: Without REGION_ID filter, data is for reported and non reported.
Note : for Non reported the REGION_ID is 999
To get the data only for reported apply the filter REGION_ID <> 999
*/

SELECT  c.CM_ID,c.CM_SHORT_DESC,c.BUYER_ID,c.BUYER_DESC,c.SUBCAT,c.SUBCAT_DESC,B.sku,A.* 
FROM VW_PROMO_ROI_FACT A 
JOIN TB_SKU_DIM b ON a.SKU_KEY = b.SKU_KEY
JOIN VW_PRODUCT_DIM C ON b.SKU = c.SKU
WHERE PROMO_WEEK_ID >= 201713  
--    AND a.REGION_ID <> 999
ORDER BY c.CM_ID ASC


/*Just for refernce - no actual use of this query
select * from TB_TGT_WEEKLY_SECONDARY_SPACE where PROM_WEEK_NO in (2017014,201702,201703)

SELECT DISTINCT 
               SS.SKU_ID
              ,SS.SKU_NUM
              ,PRICE_ZONE=SS.PRICING_ZONE
              ,SS.NO_OF_STORES
              ,SECT_NAME=ISNULL(SECT_NAME,'')
              ,DM.PROM_WEEK_NO
                       ,DM.Promo_Cycle
FROM [DBO].[TB_TGT_SECONDARY_SPACE] SS WITH (NOLOCK)
LEFT  JOIN [DBO].[TB_TGT_DATE_MAP] DM  WITH (NOLOCK)
ON CONVERT (DATE ,SS.DAY_DT,105) = CAST (CALENDAR_DATE AS DATE )
where dm.Promo_Cycle='2017_01'
*/

/*ISSUE MAY OCCUR: An important query to debug the issue in the column '[PRIMARY SECONDARY SPACE LOCATION_PZ_PK_PC]'

select *
-- distinct [PRIMARY SECONDARY SPACE LOCATION_PZ_PK_PC]
from TB_PROMOTION_ROI_FACT where NEW_PROMOTIONAL_CYCLE=201705 and PROMOTION_KEY=17170614

select * from [VW_PROMO_ROI_SUMMARY] where PROMOTION_CYCLE='2017_05' and PROMOTION_KEY=17170614

--Related objects are
1. TB_PROMO_ROI_LOAD_FACT
2. VW_PROMO_ROI_SUMMARY
3. TB_PROMOTION_ROI_FACT
4. PROC_LoadPromotionalFactData
*/

