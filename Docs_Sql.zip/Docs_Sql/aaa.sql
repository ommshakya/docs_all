USE master 
GO

-- Creating database
CREATE DATABASE TestDB
GO

USE TestDB
GO

-- Creating table
CREATE TABLE TestTable
(
 ID INT,
 Value INT,
 NewValue INT,
 CONSTRAINT PK_TestTable_ID PRIMARY KEY (ID)
)