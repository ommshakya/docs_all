﻿
1. Have good knowledge in SQL, SSIS as core competencies.
2. Requirement analysis & Database design for OLTP & OLAP databases that includes operational database & warehouses, data marts.
3. Knowledge of deploying & scheduling the T-Sql scripts & SSIS packages.
4. Sql query performance tuning & optimisation.
5. Have knowledge on Data Modelling techniques (Conceptual, Logical & Physical) & Data warehouse schema (Star & Snowflake)
6. Intermediate level programming skills in R & Python. 
7. Object oriented programming concepts with C# to develop the custom ETL libraries & tools.

1. Have knowledge on designing & developing the database applications from scratch & doing initial research as per requirements.
2. Have knowledge on data import/export, data merging & joining from multiple data sets. 
3. Have knowledge on applying the Data Integrity, Data Relationship & other constraints on data.
4. Have knowledge on Data aggregation & Data Abstraction though transact sql view, function & stored procedure objects.
5. Have knowledge on Data Manipulation, Data Retrieval and Data Transformations for ETL (Extract-Transform-Load) operations from any relation & non-relational databases. 
6. Have expert level of skills in designing & developing the ETL applications for live streaming of data from TCP/IP based medical devices to SQL server & MongoDB.
7. Have knowledge on accessing the show stopper restrictions, breaks, unavailability of resources such environment, access & credentials, data.


SUMMARY

Having 5+ years of experience as an SQL/SSIS developer to design & develop the databases, dataware houses and ETL packages in Microsoft SQL Server & Sql Server Integration Services (SSIS) along with R & Python for data manipulation & preparation for Data Analyses.

Requirement analysis & Database design for OLTP & OLAP databases that includes operational database & warehouses, data marts.
Designing, developing, deploying and scheduling the T-Sql scripts & SSIS packages.
Sql query performance tuning & optimisation.
Data Modelling (Conceptual, Logical & Physical) & Data warehouse schema (Star & Snowflake), Dimensions & Fact table design.
Data import/export, data merging & joining from multiple data sets.
Applying the Data Integrity, Data Relationship & other constraints on data.
Data aggregation & Data Abstraction though transact sql view, function & stored procedure objects.
Data Manipulation, Data Retrieval and Data Transformations for ETL (Extract-Transform-Load) operations from any relation & non-relational databases.
Designing & coding the ETL applications for live streaming of data from TCP/IP based medical devices to SQL server & MongoDB.
Identifying the restrictions, breaks, unavailability of resources such environment, access & credentials, data points.
Intermediate level programming skills in R & Python.
Object oriented programming concepts with C# to develop the custom ETL libraries & tools.
Authoring reports & dashboards in Power BI, SSRS and Tableau. 

Initially started my career as a VBA/Macro developer and explored it with .Net for 3.5 years

CERTIFICATIONS/COURSES
•	"Getting & Cleaning Data” from Coursera.
•	"R Programming" from Coursera.
•	"R Programming: Advanced" from Udemy.
•	"R Programming: R For Data Science from Udemy.
•	"Python: Python For Data Science from Udemy.
•	"Data Analysis in Python with Pandas" from Udemy.
•	"Exam 70-461: Querying Microsoft SQL Server 2012/2014" from Microsoft.
•	"C# Intermediate: Classes, Interfaces and OOP" from Udemy.
•	"C# Advanced Topics" from Udemy.


THE SMART CUBE PVT. LTD. | SR. DOMAIN ANALYST | May. 2017 – present | Noida
Responsible for the following activities

	Developing database design and writing T-SQL scripts like complex SQL Queries, Stored procedures, Functions, Views and query optimization.
	Developing ETL packages in SSIS to perform the ETL and data modelling and historical database preparation and SQL Agent Jobs scheduling.
	Sql query performance tuning & optimisation.
	Optimization and troubleshooting of existing SSIS packages.
	Converting R & Python data preparation scripts into T-SQL scripts and writing Python script for ETL & data preparation.

CHETU INDIA PVT. LTD. | SR. SOFTWARE ENGINEER | Sep. 2013 – May. 2017 | Noida

	Worked with project owners and stack holders to implement the database centric business requirements.
	Worked on database, dataware house design using snowflake schema and data modelling.
	Wrote complex & advanced T-SQL scripts (sql queries, functions, views, stored procedures).
	Developed ETL packages in SSIS for performing the Extract, Transform, Load (ETL) operations.
	Worked to write the custom ETL code for live data streaming, rewriting & redesigning the existing SSIS packages.
	Developed reports and dashboards in Power BI, SSRS. Managed Power BI Online portal.

UNIFY CLOUD PVT. LTD. | SOFTWARE ENGINEER | Dec. 2012 – Jul. 2013 | Noida

	Worked on to automate the product monitoring reports in VBA for MS Excel.

DAMCO SOLUTIONS | SOFTWARE ENGINEER | Jul. 2010 – Nov. 2012 | Faridabad

	Developed the application components in VBA/macro for MS Access.

PROJECTS(Z-A)

@THE SMART CUBE 

PROJECT 1 (UK based client)
A second largest e-commerce company in retail domain. The objective of this project is to designing the datawarehouse, implementing the ETL logics, scheduling & refreshing the data for further data analyses.

 
@CHETU INDIA PVT. LTD. 

PROJECT 4 (USA based client)
A cloud based Vetrinary Workflow Optimization System services provider. The objective of this project is to extract the data from the Patient Monitoring System (PMS) devices (e.g. BioNet, Cardell, DigiCare, VetLand), transforming the data and live streaming it to the IPad native application through REST APIs. As well maintaining the historical data for generating the reports and dashboards. 


PROJECT 3 (USA based client)
It is a US based financial product company providing the economic and financial analysis software products to various organizations and institutions in respective fields. The objective of this project is to prepare the databases for historical data storage and maintaining the ETL processes for importing/exporting data from different data sources & creating the T-SQL stored procedures for retrieving the data with complex business logics to provide the data access to the clients through the APIs as per their subscription.



PROJECT 2 (USA based client)
A healthcare services provider. The objective of this project is to collect the data from different OLTP databases and performing the data transformations, aggregations as per their business logic and loading into the OLAP databases. 


PROJECT 1 (USA based clients) 
The operational projects in healthcare, finance & games industries. The objective of these projects are to implement the database centric solutions that requires database designing, writing T-SQL scripts (queries, stored procedures, functions, views), developing SSIS packages for ETL operations.



@UNIFY CLOUD PVT. LTD.

PROJECT 1 (USA based client)

It is a product of the company that controls the Wi-Fi network within a building in collaboration of Aruba Network Server. The objective of the application is to develop the application to analyze products performance and utilization and automate the report generation and publishing to the respective stakeholders/owners.

Environment: MS SQL Server 2008, Excel, VBA

@ DAMCO SOLUTIONS PVT. LTD. (Responsible for VBA/Macro programming)

PROJECT 1 (USA based client) 
A desktop application in MS Access of a financial organization where various reports has to be generated based on some financial data. 


RESPONSIBILITY: Understanding the flow, desiging databases, developing ETL packages in SSIS, writing T-SQL scripts (queries, stored procedures, functions, views), converting R & python data preparations into T-SQL scripts, scheduling, automating the ETL packages/scripts and refreshing the data.
RESPONSIBILITY: Requirement analyses, Database design, developing customized ETL applications in C# to fetch the data from PMS devices and live streaming the data, Creating ETL packages for performing the ETL operations, writing T-SQL scripts (queries, stored procedures, functions, views) for retrieing data, importing/exporting data.
RESPONSIBILITY: Requirement analyses, database design, ETL packages development in SSIS for data import/export, data cleansing & manipulation, data standarizing & refresh, writing T-SQL scripts (queries, stored procedures, functions, views). Scheduling the ETL packages & maintaining the databases.
RESPONSIBILITY: Requirement analyses, writing T-SQL scripts (queries, stored procedures, functions, views), developing the ETL packages in SSIS for manipulating the data as per the business logic. Rewriting the stored procedures with query optimization and redesinging the existing SSIS packages.
RESPONSIBILITY: Requirement analyses, working with team to design the databases, writing queries, stored procedures, functions, views and developing the SSIS packages, deploying & scheduling the packages. Query & SSIS packages optimization.



	Developing database design and writing T-SQL scripts like complex SQL Queries, Stored procedures, Functions, Views and query optimization.
	Developing ETL packages in SSIS to perform the ETL and data modelling and historical database preparation and SQL Agent Jobs scheduling.
	SQL query performance tuning & optimization.
	Optimization and troubleshooting of existing SSIS packages.
	Converting R & Python data preparation scripts into T-SQL scripts and writing Python script for ETL & data preparation.

As a Sr. Domain Analyst, working with project owners and stack holders to implement the database centric solutions for the data analyses and machine learning project. Desiging databases, data warehouses and data modelling using start schema & snowflake schema, writing T-SQL scripts (complex & advanced SQL queries, stored procedure, functions, views) & implementing the ETL operations using SSIS packages, deployment of these packages and data refreshes as well queries performance & SSIS packages optimizations are the main responsibilities.

	Worked with project owners and stack holders to implement the database centric business requirements.
	Worked on database, data ware house design using snowflake schema and data modelling.
	Wrote complex & advanced T-SQL scripts (SQL queries, functions, views, stored procedures).
	Developed ETL packages in SSIS for performing the Extract, Transform, Load (ETL) operations.
	Worked to write the custom ETL code for live data streaming, rewriting & redesigning the existing SSIS packages.
	Developed reports and dashboards in Power BI, SSRS. Managed Power BI Online portal.

As a Sr. Software Engineer, worked on database oriented applications in Microsoft SQL Server environment for data modelling (logical, conceptual & physical) with start & snowflake schemas. Database design, ETL (SSIS packages) development, T-SQL (SQL queries, stored procedure, functions, views) scripting, custom ETL for live data streaming from PMS devices, queries & packages optimizations and authoring reports & dashboards were the key responsibilities.
