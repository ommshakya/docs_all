IF OBJECT_ID('tempdb.dbo.#TBL', 'U') IS NOT NULL
  DROP TABLE #TBL; 
CREATE TABLE #TBL
(
	CYCLE_NO INT,
	NOOFWEEKS INT
)

INSERT INTO #TBL (CYCLE_NO, NOOFWEEKS)
VALUES (1, 3)
      ,(2, 3)
      ,(3, 2)
      ,(4, 3)

SELECT * FROM #TBL

;WITH CTE
AS
(
	SELECT CYCLE_NO,NOOFWEEKS, Getdate() AS RunningDate , Days=7*NOOFWEEKS, Rows=1 ,Totaldays=IIF(CYCLE_NO>1,7*NOOFWEEKS,1)
		FROM #TBL
	UNION ALL
	SELECT CYCLE_NO, NOOFWEEKS,DATEADD(D,Totaldays,Getdate()) AS RunningDate, Days, Rows=Rows+1,  
	Totaldays=Totaldays+1
	
	FROM CTE Where Rows<Days
)
SELECT * FROM CTE --where CYCLE_NO=1
ORDER BY CYCLE_NO,Rows, RunningDate --Desc