/* Create a table */
CREATE TABLE  #tbl_input(
       [id] [int] IDENTITY(1,1) NOT NULL,
       [c1] [int] NOT NULL,
       [c2] [int] NOT NULL,
       [c3] [int] NOT NULL,
       [c4] [int] NOT NULL
)

/* Input sample data into table */
INSERT INTO #tbl_input([c1],[c2],[c3],[c4])
VALUES
(17, 17, 17, 17)
,(11, 10, 11, 9)
,(0, 2, 1, 0)
,(2, 7, 1, 8)

/* Check data in table*/
SELECT * FROM #tbl_input

/* Query : Get the max value over all columns for each row*/
SELECT id, max_over_all_columns = MAX(val)
FROM #tbl_input
UNPIVOT
(
  val
  FOR col IN (C1, C2, C3, C4)
) piv
GROUP BY id

;WITH CTE
AS
(
	SELECT id, val, col --max_over_all_columns = MAX(val)
	FROM #tbl_input
	UNPIVOT
	(
	  val
	  FOR col IN (C1, C2, C3, C4)
	) piv
)
SELECT maxtbl.id, maxtbl.max_over_all_columns, B.col FROM
(
	SELECT id, max_over_all_columns = MAX(val)
	FROM CTE
	GROUP BY id
) AS maxtbl
LEFT JOIN CTE AS B ON maxtbl.id = B.id AND maxtbl.max_over_all_columns = B.val

