# Set the working directory

getwd()
setwd("D:\\Abhishek.R.Training\\ProcureSpend_R\\")
getwd()

#Read the data file
dfRawData = read.csv("RawDataFiles\\Spend_Vis_extract_P10.csv")

#Check the structure of the file, and few records
str(dfRawData)
head(dfRawData)

# ISNULL(PO_NUMBER) || LEN(TRIM(PO_NUMBER)) == 0 || ISNULL(FULL_NAME) || 
# LEN(TRIM(FULL_NAME)) == 0 || ISNULL(PO_ACCOUNT_NUMBER) || LEN(TRIM(PO_ACCOUNT_NUMBER)) == 0 || 
# ISNULL(PO_COST_CENTRE) || LEN(TRIM(PO_COST_CENTRE)) == 0 || ISNULL(SUPPLIER_NUMBER) 
# || LEN(TRIM(SUPPLIER_NUMBER)) == 0
filter = is.na(dfRawData$PO_NUMBER) | dfRawData$FULL_NAME =='' | 
  is.na(dfRawData$PO_ACCOUNT_NUMBER) | dfRawData$PO_COST_CENTRE =='' | dfRawData$SUPPLIER_NUMBER ==''

dfBadRecords = dfRawData[filter,]
str(dfBadRecords)
dfBadRecords[, c("PO_NUMBER", "FULL_NAME", "PO_ACCOUNT_NUMBER", "PO_COST_CENTRE", "SUPPLIER_NUMBER")]

dfGoodRecords = dfRawData[!filter,]
str(dfGoodRecords)
head(dfGoodRecords)

nrow(dfRawData)
nrow(dfBadRecords)
nrow(dfGoodRecords)

dfTargetData = dfGoodRecords

dfDim_Account = unique(dfTargetData[c("PO_ACCOUNT_NUMBER","PO_ACCOUNT_DESCRIPTION")])
#df %>% select(var1, var2) %>% distinct
nrow(dfDim_Account)

dfDim_CostCentre = unique(dfTargetData[c("PO_COST_CENTRE","PO_COST_CENTRE_DESCRIPTION")])
nrow(dfDim_CostCentre)

dfDim_Requestor = unique(dfTargetData[c("FULL_NAME","REQUESTOR_LOCATION")])
nrow(dfDim_Requestor)

library(dplyr) 

# as.Date(as.POSIXct(dist_gbpa_enddate1$dt1, format = "%Y-%m-%d", tz="Asia/Calcutta"), tz="Asia/Calcutta")
# today <- Sys.Date()
# today
# Sys.timezone()

dfDim_GBPA = unique(dfTargetData[c("GBPA_NUMBER","GBPA", "GBPA_LIMIT", "GBPA_END_DATE")])
nrow(dfDim_GBPA)

dfDim_GBPA$GBPA_END_DATE_Modified <- case_when(
  is.na(dfDim_GBPA$GBPA_END_DATE) ~ as.POSIXct(NA),
  is.na(as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%m/%d/%Y")) 
  ~ as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%d-%m-%Y"),
  TRUE ~ as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%m/%d/%Y")
)
dfDim_GBPA$GBPA_END_DATE_Modified <- as.Date(
  as.POSIXct(dfDim_GBPA$GBPA_END_DATE_Modified
             , format = "%Y-%m-%d"
             , tz="Asia/Calcutta")
  , tz="Asia/Calcutta")
#### TO DO:>>> 
#### 1. Remove 'GBPA_END_DATE' column
#### 2. Rename 'GBPA_END_DATE_Modified' to 'GBPA_END_DATE'

#str(dfDim_GBPA)
nrow(dfDim_GBPA)

str(dfTargetData)

dfDim_Supplier = unique(dfTargetData[c("SUPPLIER_NUMBER","VENDOR_NAME", "ADDRESS_LINE1"
                                       , "ADDRESS_LINE2", "ADDRESS_LINE3", "CITY"
                                       ,"ZIP", "COUNTRY", "SUPPLIER_TERMS")])
nrow(dfDim_Supplier)

dfDim_Contract = unique(dfTargetData[c("CONTRACT_NUMBER","CONTRACT", "CONTRACT_LIMIT", "CONTRACT_END_DATE", "LINE_TYPE")])
nrow(dfDim_Contract)


dfDim_Contract$CONTRACT_END_DATE_Modified <- case_when(
  is.na(dfDim_Contract$CONTRACT_END_DATE) ~ as.POSIXct(NA),
  is.na(as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%m/%d/%Y")) 
  ~ as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%d-%m-%Y"),
  TRUE ~ as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%m/%d/%Y")
)
dfDim_Contract$CONTRACT_END_DATE_Modified <- as.Date(
  as.POSIXct(dfDim_Contract$CONTRACT_END_DATE_Modified
             , format = "%Y-%m-%d"
             , tz="Asia/Calcutta")
  , tz="Asia/Calcutta")

nrow(dfDim_Contract)
#unique(dfDim_Contract[c("CONTRACT_END_DATE")])
#### TO DO:>>> 
#### 1. Remove 'GBPA_END_DATE' column
#### 2. Rename 'GBPA_END_DATE_Modified' to 'GBPA_END_DATE'

df_Temp_Items <- dfTargetData[c("VENDOR_PRODUCT_NUM", "CATEGORY_1")]
str(df_Temp_Items)
head(df_Temp_Items)

df_Temp_Items$VENDOR_PRODUCT_NUM <- trimws(df_Temp_Items$VENDOR_PRODUCT_NUM)
df_Temp_Items$CATEGORY_1 <- trimws(df_Temp_Items$CATEGORY_1)

df_Temp_Items$VENDOR_PRODUCT_NUM[is.na(df_Temp_Items$VENDOR_PRODUCT_NUM)] <- ''
df_Temp_Items$CATEGORY_1[is.na(df_Temp_Items$CATEGORY_1)] <- ''

df_Temp_Items$ItemNo <- case_when(
  df_Temp_Items$VENDOR_PRODUCT_NUM == '' & df_Temp_Items$CATEGORY_1 != '' ~ paste(c('NA-',df_Temp_Items$CATEGORY_1), collapse = ''),
  TRUE ~ df_Temp_Items$VENDOR_PRODUCT_NUM
)

dfDim_Items_unq <- unique(df_Temp_Items[c("ItemNo", "CATEGORY_1")])
nrow(dfDim_Items_unq)
tail(dfDim_Items)

ptn <- '^NA-.*?'
ndx <- grep(ptn, df_Temp_Items$ItemNo, perl=T)
df_Temp_Items[ndx,]

df_Temp_Items[df_Temp_Items$VENDOR_PRODUCT_NUM == '']
df_Temp_Items[df_Temp_Items$CATEGORY_1 == '']




