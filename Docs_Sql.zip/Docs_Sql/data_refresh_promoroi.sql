/*PromoROI data refresh*/

/*Server : .9
User: promouser/promouser1
*/

/*
Step 1: Run the following packages to load the input raw data into staging tables
Total no. of raw input files: 11 (These 11 files are loaded in step 1)

1. Load STRAC Raw Data Package 
2. Load Weather Raw Data Package
3. Load VAT Raw Data Package
4. Load Sales Raw Data Package
5. Load promo sales Raw Data Package (Loads 2 files [promo sales, promo])
6. Load PPP Raw Data Package
7. Load Discarded SKU Raw Data Package
8. Load Secondary Space  Raw Data Package (Loads 3 files [day, pc, weekly])

Step 2: 2 files are provided by Ankur Tomar/Divya Maheshwari
Note: Any one or both files may be provided
Note: These are imported using import wizard into the corresponding tables.
1. Loose SKUs list (TB_Loose_SKUs) -- This is flush and load in nature
2. Wrong SKUs List (TB_Wrong_SKU_List) -- This is appened in nature

Step 3: Delete records from Sales stage table where salescash <= 0

DELETE FROM TB_STG_SALES
WHERE SALES_CASH < = 0
AND PROM_WEEK_NO > 201713 -- the minimum week of the refresh cycle

NOTE: DO THE DELETION FOR BOTH STAG AND TARGET SALES TABLE

Step 4: Update hierarchy for products

SELECT A.ManagerId, a.Manager_Resp, b. ManagerId, b.Manager_Resp
FROM TB_STG_SALES a
JOIN PRODUCT_DIM_PC02 b
ON a.SKU = b.SKU
WHERE a.Manager_Id <> b.Manager_Id

UPDATE SET
	a.Manager_Id = b.Manager_Id,
	a.Manager_Resp = b.Manager_Resp
FROM TB_STG_SALES
JOIN TB_PRODUCT_DIM_PC02
ON a.SKU = b.SKU

NOTE: ALSO UPDATE FOR TARGET SALES WHERE PROM_WEEK_NO = CURRENT WEEK

Step 5: Run the following stored procedure

EXEC proc_LoadFialDashboard

Step 6: Run the package to load the supplier input raw data
Load Supplier Raw Data Package


Step 7: Check data in TB_ACCURACY_COVERAGE_TRACKER, how mach have been processed. usually is is between 14 - 21 % with +-5%
Note compare the following current data with previous cycle data

SELECT * 
FROM TB_ACCURACY_COVERAGE_TRACKER
WHERE PROMO_CYCLE = '2017_05'

Compare with previous cycle.

If every thing is fine, DASHBOARD has been generated.

Step 8: Extract data for DASHBOARD and give it to DAs team (Anukur Bhargava, Divyam Ankur Tomer) for their QC

SELECT * FROM TB_PROMO_ROI_DATA WHERE PROMO_CYCLE = '2017_05'
SELECT * FROM TB_ACCURACY_COVERAGE_TRACKER WHERE PROMO_CYCLE = '2017_05'

NOTE: If DAs team sign off the DASHBOARD then proceed with next step.

Step 9: Load the EDW input raw data using the package

Load EDW Raw Data Package

Step 10: Run the following package
Load ALL Dim Fact Data Package


Step 11: Run the following package
NOTE: Run only the first part of this package***

Load Final Promotional into Azure Environment

Step 12: QC the counts of the records in the corresponding tables
TB_PROMO_ROI_DATA
TB_PROMO_ROI_FACT
TB_PROMOTION_ROI_FACT
in both the databases - PromoROI, PromotionsROI.
Status: The counts of corresponding tables should be equal in both DB.
NOTE: This qc is done after running the first part of the "Load final promotional into azure environment package."

DECLARE @cnt_TB_PROMO_ROI_DATA_promoroi INT
          ,@cnt_TB_PROMO_ROI_DATA_promotionsroi INT
          ,@cnt_TB_PROMO_ROI_FACT_promoroi INT
          ,@cnt_TB_PROMO_ROI_FACT_promotionsroi INT
          ,@cnt_TB_PROMOTION_ROI_FACT_promoroi INT
          ,@cnt_TB_PROMOTION_ROI_FACT_promotionsroi INT

SELECT @cnt_TB_PROMO_ROI_DATA_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMO_ROI_DATA
SELECT @cnt_TB_PROMO_ROI_DATA_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMO_ROI_DATA

SELECT @cnt_TB_PROMO_ROI_FACT_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMO_ROI_FACT
SELECT @cnt_TB_PROMO_ROI_FACT_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMO_ROI_FACT

SELECT @cnt_TB_PROMOTION_ROI_FACT_promoroi = COUNT(*) FROM PromoROI.dbo.TB_PROMOTION_ROI_FACT
SELECT @cnt_TB_PROMOTION_ROI_FACT_promotionsroi = COUNT(*) FROM PromotionsROI.dbo.TB_PROMOTION_ROI_FACT

IF @cnt_TB_PROMO_ROI_DATA_promoroi = @cnt_TB_PROMO_ROI_DATA_promotionsroi
       PRINT 'TB_PROMO_ROI_DATA is OK : (PromoROI) ' + CAST(@cnt_TB_PROMO_ROI_DATA_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMO_ROI_DATA_promotionsroi AS VARCHAR(10))

IF @cnt_TB_PROMO_ROI_FACT_promoroi = @cnt_TB_PROMO_ROI_FACT_promotionsroi
       PRINT 'TB_PROMO_ROI_FACT is OK : (PromoROI) ' + CAST(@cnt_TB_PROMO_ROI_FACT_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMO_ROI_FACT_promotionsroi AS VARCHAR(10))

IF @cnt_TB_PROMOTION_ROI_FACT_promoroi = @cnt_TB_PROMOTION_ROI_FACT_promotionsroi
       PRINT 'TB_PROMOTION_ROI_FACT is OK : (PromoROI) ' + CAST(@cnt_TB_PROMOTION_ROI_FACT_promoroi AS VARCHAR(10)) + ' - (PromotionsROI) '  + CAST(@cnt_TB_PROMOTION_ROI_FACT_promotionsroi AS VARCHAR(10))

Step 13: After qc - Give the data BEFORE MSTR to the DAs(team) for further qc.
Extract the data from VW_PROMO_ROI_FACT, TB_SKU_DIM &  VW_PRODUCT_DIM
for the current cycle.
NOTE: Without REGION_ID filter, data is for reported and non reported.
Note : for Non reported the REGION_ID is 999
To get the data only for reported apply the filter REGION_ID <> 999

SELECT  c.CM_ID,c.CM_SHORT_DESC,c.BUYER_ID,c.BUYER_DESC,c.SUBCAT,c.SUBCAT_DESC,B.sku,A.* 
FROM VW_PROMO_ROI_FACT A 
JOIN TB_SKU_DIM b ON a.SKU_KEY = b.SKU_KEY
JOIN VW_PRODUCT_DIM C ON b.SKU = c.SKU
WHERE PROMO_WEEK_ID >= 201713  
--    AND a.REGION_ID <> 999
ORDER BY c.CM_ID ASC


Step 14: Run the following packages after giving the BEFORE MSTR data to team
Load Cat Planner Buyer Data to Azure Package
NOTE: Run only the following parts ***

EST Load Cat Planner
SC-1

TELL THE TEAM THAT WE HAVE RUN THE CAT PLANNER.

--------------------------------------------------------
ISSUE*** MAY OCCUR DURING QC BY TEAM related to [Primary_Secondary_Space_Location_PZ_PK_PC]: Described below


ISSUE*** MAY OCCUR DURING QC BY TEAM related to [Primary_Secondary_Space_Location_PZ_PK_PC]: Described below
NOTE: ISSUE CAN BE FOUND BY TEAM BEFOR PRODUCTION LOAD

Related objects are:
	TB_PROMO_ROI_LOAD_FACT
	VW_PROMO_ROI_SUMMARY
	TB_PROMOTION_ROI_FACT
	PROC_LOADPROMOTIONALFACTDATA

ISSUE related to missing REGION WITH SKU  mapping may also occur.
In this case add a record in the following file
EDW\SKU_KEY_SKU_REGION_ID_MAPPING , it will resolve this issue.

AFTER RESOLVING ANY ISSUE BEFORE PRODUCTION LOAD, Run the following packages in the order

- Laod All Dim Fact Data Package
- Load Final Promotional into Azure Environment
- Load Cat Planner Buyer Data to Azure
--------------------------------------------------------

Step 15: Team will ask for the I2C data (Give data to Ankur Bhargava)
Run the following stored procedure for the current cycle
Exec proc_loadI2Cdata for current cycle


Step 16: Once the DAs team told us that dashboard, before mstr , etc are fine and load/push into the production
run the following packages.

A. Load Final Promotional into Azure Environment Package
NOTE: 
	Disable 1st part Sequence container + previous 2 task
	Enable the 3rd part
	Now run the package

B. Load Cat Planner Buyer Data to Azure Package
NOTE:
	Disable EST Load CatPlanner + SC-1 + SC-2
	Enable SC-3 & Load Cat planner weekly level data from Development to Azure SQL Server test and production
	Now run the package

*/

/*Now also QC the data of production load - on .9 server all queries are saved*/