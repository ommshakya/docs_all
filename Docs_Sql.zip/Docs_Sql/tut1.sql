CREATE TABLE tbl_flags
(
	id INT PRIMARY KEY
	,flag BIT
)
GO
  
INSERT INTO tbl_flags
VALUES
(1,0),(2,0),(3,0)
,(4,1),(5,1),(6,0)
,(7,0),(8,1),(9,1)
,(10,1),(11,1),(12,1)
GO


;WITH CTE AS
(
	SELECT   
		id
		,flag
		,id - ROW_NUMBER() OVER (PARTITION BY flag ORDER BY id) rnk
	FROM tbl_flags
)
SELECT flag,(MAX(id) - MIN(id)) + 1 as ConsecutiveCounts 
FROM CTE 
GROUP BY rnk, flag
ORDER BY rnk,flag