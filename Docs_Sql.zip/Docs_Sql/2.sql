DECLARE @cnt INT, @distinctCnt INT
SELECT @cnt = COUNT(*) FROM [dbo].[TB_STG_PROCURESPEND]
Select @distinctCnt = count(*) from (select distinct * from dbo.TB_STG_PROCURESPEND)xyz
SELECT @cnt AS totalCount, @distinctCnt AS distinctCount, @cnt - @distinctCnt AS duplicateRecordCount
/*CSV File has duplicate records*/



/*Account dim 
Account Number : This column has numeric as well string values. [5 digits]
*/

/*Category dim
Category 1,Category 2, Category 3 : These columns look fine but have blank values also. [Lenth > 0]
*/


/*Contract dim
Contract: This column have blank values also.
Contract Limit: This column have blank values also.
Contract date: This date column have blank values also.
Line type : This column have blank values also.
*/


/*CostCentre dim
CostCentre : In this column (Most values are like 'A0244') but have some different values 
				for example: Computer stationary issue, Wrap.Mats-Checkout

*/

/*GBPA dim
[GBPA Number]: most values are numeric but also have string values like JANITORIAL CONSUMABLES, JSR CONSUMABLES.  [string not null]
[GBPA Limit]: This column have blank values also. [8 digit string not null]
[GBPA End Date]: This date column have blank and string values such as BLANKET. [date not null]
*/


/*Item dim
Item Number: This column have different kind of values such as numeric 4290, 40/000070, HP CF281x [string  null]
*/

/* Requestor dim
Project Number : Most of the values are Numeric but also string for example: New branch uniforms purchases
				also have blank values. [string  null]
*/

/*[dbo].[TB_PROCURESPEND_FACT]

[PO Quantity]: also have string values eg: West port loc A4966, have blank [Not null]
[PO Price]: also have string eg: eggs, milk, world food, have blank [Not null]
[Invoice Date]: slao have some float values, have blanks [Null]
[Invoice Line Num]: Have date values [Null]
[Total Invoice Amount] : Is it float or string, all the values are string eg: GBP only [Null]
[Invoice Currency]: it has only string values eg: UNIFACC instead of currency descriptor [NULL]
[GL Date]: It has only float values [NULL]
*/





SELECT * FROM [dbo].[TB_TGT_PROCURESPEND]


SELECT DISTINCT [PO Account Number]
      ,[PO Account Description]
FROM TB_TGT_PROCURESPEND
WHERE [PO Account Number] IS NOT NULL AND LEN([PO Account Number]) > 0



SELECT DISTINCT [Category 1]
      ,[Category 2]
	  ,[Category 3]
FROM TB_TGT_PROCURESPEND
WHERE   [Category 1] IS NOT NULL AND LEN([Category 1]) > 0


SELECT DISTINCT [Contract]
	  ,CAST([Contract Limit] AS INT) AS[Contract Limit]
	  ,CAST([Contract End Date] AS DATE) AS [Contract End Date]
	  ,[Line Type]
FROM TB_TGT_PROCURESPEND


SELECT DISTINCT [PO Cost Centre]
	  ,[PO Cost Centre Description]
FROM TB_TGT_PROCURESPEND
WHERE   [PO Cost Centre] IS NOT NULL AND LEN([PO Cost Centre]) > 4

INSERT INTO [dbo].[TB_GBPA_DIM]
SELECT DISTINCT [GBPA Number]
                ,GBPA 
                ,[GBPA Limit]
                ,[GBPA End Date]
				
FROM [dbo].[TB_TGT_PROCURESPEND]
WHERE   [GBPA Number] IS NOT NULL AND LEN([GBPA Number]) > 0


SELECT DISTINCT [Item Number]
	  ,[Category 1]
FROM TB_TGT_PROCURESPEND
WHERE   [Item Number] IS NOT NULL AND LEN([Item Number]) > 0


SELECT DISTINCT [Requestor Name]
	  ,[Requestor Location]
	  ,[Project Number]
	  ,[Project Name]
FROM TB_TGT_PROCURESPEND
WHERE   [Requestor Name] IS NOT NULL AND LEN([Item Number]) > 0


SELECT DISTINCT [Supplier Number]
	  ,[Supplier Name]
	  ,[Supp Address Line 1]
	  ,[Supp Address Line 2]
	  ,[Supp Address Line 3]
	  ,[Supp City]
	  ,[Supp Post Code]
	  ,[Supp Country]
	  ,[Supplier Terms]
FROM TB_TGT_PROCURESPEND
WHERE   [Supplier Number] IS NOT NULL AND LEN([Supplier Number]) > 4



SELECT b.[Item_Key],* FROM TB_TGT_ProcureSpend AS a
LEFT JOIN TB_ITEM_DIM as b ON [ItemNo] = [Item Number]
ORDER BY b.[Item_Key]

SELECT [Item_Key] FROM TB_TGT_ProcureSpend