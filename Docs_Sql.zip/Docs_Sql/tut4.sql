Declare @InPutDate DateTime='2017/09/08'
;
WITH CTE
As
(
	Select (Convert(DateTime,Convert(VarChar(4),Year(@InputDate))+'/'+Cast(Monthid As VarChar(2))+'/'+Cast('1' As VarChar(4)))) QuaterDay
	From 
	(
		Select 1 As Monthid
		Union All
		Select 4 As Monthid
		Union All
		Select 7 As Monthid
		Union All
		Select 10 As Monthid
	) A
)

Select  Max(QuaterDay) As QuaterDay 
From CTE Where QuaterDay <= @InputDate