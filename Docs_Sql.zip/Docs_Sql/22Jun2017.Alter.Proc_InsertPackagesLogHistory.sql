USE [CommercialPIR]
GO

/****** Object:  StoredProcedure [dbo].[Proc_InsertPackagesLogHistory]    Script Date: 22-06-2017 12:44:39 ******/
SET ANSI_NULLS ON
GO

SET QUOTED_IDENTIFIER ON
GO




ALTER Procedure [dbo].[Proc_InsertPackagesLogHistory]
(
@inpFullFilePath nvarchar(250),
--@inpFileName Varchar(50), 
@inpTableName varchar(50),
@inpStagingTableName varchar(50),
@inpPackageName Varchar(200)
)
As
Begin


--- decalre local variables
declare @SQL nvarchar(2000), @newRecords int=0;
DECLARE @inpFileName Varchar(50)

--- declare table variable
Declare @GetRecords Table(RecordsCount Int)

---- set the query string
set @SQL='Select count(*) ctr from (select distinct * from '+@inpStagingTableName +')xyz' 

/*Have applied a filter on input raw data on staging table, so exclude those records*/
IF UPPER(@inpStagingTableName) = 'DBO.TB_STG_PRICE_V10_FINAL' OR UPPER(@inpStagingTableName) ='DBO.TB_STG_PRICE_V10_ZONE_FINAL'
	SET @SQL = @SQL + ' WHERE (calc_base_price <> ''''  AND calc_base_price <> ''NULL'' AND calc_base_price <> ''.'' )'

---- get the number of records which are received from the staging table
Insert into @GetRecords exec (@SQL)

---- get the new records
Select @newRecords=RecordsCount from  @GetRecords;

---- get the file name from full path
SELECT @inpFileName = RIGHT(@inpFullFilePath, CHARINDEX('\', REVERSE(@inpFullFilePath))-1)


---- Insert Records into PackagesLogHistory
INSERT INTO [dbo].[TB_PackagesLogHistory]
           ([PackageName]
           ,[FileSourcePath]
           ,[FileName]
           ,[StagingTableName]
           ,[TableName]
           ,[NewRecords]
           ,[ExecutionDateTime])
     VALUES
           (@inpPackageName
           ,@inpFullFilePath
           ,@inpFileName
           ,@inpStagingTableName
           ,@inpTableName
           ,@newRecords
           ,getDate())


End




GO


