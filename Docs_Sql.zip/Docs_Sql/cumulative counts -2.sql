
IF OBJECT_ID('TempDB.dbo.#tbl') IS NOT NULL
	DROP TABLE #tbl

;WITH base 
AS
(
	SELECT id, LOCATION,section_id, WEEK_NO, invest_refurbi_flag
		,ROW_NUMBER() OVER(ORDER BY LOCATION,section_id, WEEK_NO  ASC) AS Row#
				--,[cumulative_cnt_test]
				--,[_fg_12weeks_test]
	FROM
	(

		SELECT id, CAST(LOCATION AS INT) AS LOCATION
				,CAST(section_id AS INT) AS section_id
				,CAST(WEEK_NO AS INT) AS WEEK_NO
				,CAST(invest_refurbi_flag AS BIT) AS invest_refurbi_flag
				--,[cumulative_cnt_test]
				--,[_fg_12weeks_test]
		FROM [dbo].[Flag_Data_Logic]
	) AS a
)


SELECT *
INTO #tbl
FROM base


SELECT * FROM #tbl

;WITH Running AS
(
	SELECT location
		  ,section_id
		  ,WEEK_NO
		  ,NextWeekChange = lead(WEEK_NO) OVER (PARTITION BY location, section_id ORDER BY  WEEK_NO)
	FROM #tbl WHERE invest_refurbi_flag = 1
),
MaxWeek AS
(
	SELECT location
	      ,section_id
		  ,MaxWEEK_NO = MAX(WEEK_NO)
	FROM #tbl GROUP BY location, section_id
),
MergeRunningMaxWeek AS
(
	SELECT R.location
	      ,R.section_id
	      ,R.WEEK_NO
		  ,NextWeekChange = ISNULL(NextWeekChange, MaxWEEK_NO)
	FROM Running R 
	LEFT JOIN MaxWeek M 
	ON R.LOCATION = M.LOCATION AND R.section_id = M.section_id
)

SELECT location,section_id
	  ,WEEK_NO
	  ,invest_refurbi_flag
	  ,cumulative_cnt_test
	  ,invest_refurbi_12weeks
	  ,IIF(cumulative_cnt_test <= 12 AND cumulative_cnt_test <> 0 , 1,0) AS flag
FROM
(
	SELECT location
		  ,section_id
		  ,WEEK_NO
		  ,invest_refurbi_flag
		  ,cumulative_cnt_test = IIF(NextWeekChange IS NULL , 0 ,ROW_NUMBER() OVER (PARTITION BY location, section_id, NextWeekChange ORDER BY WEEK_NO))
		  ,invest_refurbi_12weeks
		  , NextWeekChange
	FROM
	(
		SELECT DISTINCT t.*
			  ,IIF(t.WEEK_NO > R.WEEK_NO AND t.WEEK_NO < ISNULL(NextWeekChange, lead(t.WEEK_NO) OVER (PARTITION BY t.location, t.section_id ORDER BY t.WEEK_NO)) ,1,0) AS invest_refurbi_12weeks
			  ,NextWeekChange = IIF(invest_refurbi_flag = 1 , NULL, NextWeekChange)
		FROM #tbl t LEFT JOIN MergeRunningMaxWeek R
		ON t.LOCATION = r.LOCATION AND t.section_id = R.section_id
		AND t.WEEK_NO BETWEEN r.WEEK_NO AND r.NextWeekChange
	)t
	--ORDER BY t.WEEK_NO
) AS q
ORDER BY WEEK_NO
