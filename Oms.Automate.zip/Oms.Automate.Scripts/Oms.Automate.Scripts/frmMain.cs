﻿using Oms.ClassLibrary;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Timers;
using System.Web.Script.Serialization;
using System.Windows.Forms;

namespace Oms.Automate.Scripts
{
    public partial class Form1 : Form
    {
        private ILogger _logger = new FileLogger();
        private IJobsEngine _jobsEngine = new JobsEngineFiles();

        List<TableLayoutPanel> listScheduleBoxes = new List<TableLayoutPanel>();
        ScheduleEngine _scheduleEngine = new ScheduleEngine();
        

        public Form1()
        {
            InitializeComponent();

            ScheduleBoxesList();
            BindScheduleType();
            btnDeleteJobs.Enabled = false;
            btnRepairSchedule.Enabled = false;
            btnExecuteNow.Enabled = false;

            BindGrids();

            //if (WindowServicesUtility.GetWindowServiceStatus(AppConfigurations.WinApp_WindowService_Name).Equals(ServiceControllerStatus.Stopped))
            //    WindowServicesUtility.StartWindowService(AppConfigurations.WinApp_WindowService_Name);

            StartTimer();
        }

        private void BindGrids()
        {
            BindGridJobs();
            BindGridJobStatusLogs();
            BindGridTriggerLogs();
            BindGridExecutionLogs();
        }

        private void StartTimer()
        {
            System.Timers.Timer timer = new System.Timers.Timer();
            timer.Elapsed += new ElapsedEventHandler(RefreshLogs);
            timer.Interval = 60 * 1000; // 1 minute
            timer.Enabled = true;
            timer.Start();
        }
        private void RefreshLogs(object sender, ElapsedEventArgs e)
        {
            this.Invoke(new MethodInvoker(RefreshLogsGrids));
            
        }
        private void RefreshLogsGrids()
        {
            BindGrids();
            //lblText.Text = "Logs refreshed : " + DateTime.Now.ToString();
        }
        private void ScheduleBoxesList()
        {
            listScheduleBoxes.Add(tblInterval);
            listScheduleBoxes.Add(tblDaily);
            listScheduleBoxes.Add(tblWeekly);
            listScheduleBoxes.Add(tblMonthly);
        }
        private void BindScheduleType()
        {
            comboBoxType.DataSource = Enum.GetValues(typeof(ScheduleTypes));
            comboBoxType.SelectedItem = ScheduleTypes.Select;
            rdoBtnPython.Checked = true;

            comboBoxWeeklyDayOfWeek.DataSource = Enum.GetValues(typeof(DayOfWeek));
            comboBoxWeeklyDayOfWeek.SelectedIndex = 1;
            numMonthlyDayOfMonth.Value = 30;
        }

        private void ClearDataGridViews(DataGridView dataGridView)
        {
            dataGridView.DataSource = null;
            dataGridView.Rows.Clear();
            dataGridView.Columns.Clear();
        }
        private void BindGridJobs()
        {
            ClearDataGridViews(dgvJobs);

            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();
            int i = 1;
            var j = from job in jobs
                    orderby (job.CreatedTime)
                    select new
                    {
                        Num = i++,
                        JobDescription = (job.Description.Length > 20 ? job.Description.Substring(0, 20) : job.Description) + "...(" + job.Id.ToString().Substring(0, 16) + "...)",
                        NextSchedule = job.FirstOrNextSchedule,
                        job.ScriptType,
                        job.Schedule.ScheduleType,
                        Schedule = GetScheduleToShow(job.Schedule.ScheduleType, job.Schedule),
                        job.Interpreter,
                        job.ScriptFilePath,
                        JobId = job.Id,
                        job.Description,
                        job.CreatedTime,
                    };

            dgvJobs.DataSource = j.ToList();


            #region bind control
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "Select";
            checkBoxColumn.Name = "chkBoxSelectJob";
            checkBoxColumn.FlatStyle = FlatStyle.Standard;
            checkBoxColumn.ThreeState = false;
            dgvJobs.Columns.Insert(0, checkBoxColumn);
            #endregion

            this.dgvJobs.Columns[0].Frozen = true;
        }
        private void BindGridJobStatusLogs()
        {
            IEnumerable<LogJobStatus> logs = _jobsEngine.GetJobStatusLogs();
            int i = 1;
            var j = from log in logs
                    select new
                    {
                        //TimeStamp = Convert.ToDateTime(log.TimeStamp).ToString(formatString),
                        JobDescription = (log.Job.Description.Length> 20 ? log.Job.Description.Substring(0, 20) : log.Job.Description) + "...("+ log.JobId.Substring(0, 16) + "...)",
                        //StatusId = log.Status.Split('#')[0].Split('S')[1],
                        log.Status,
                        StartTime = log.StartTime.ToString("u"),
                        EndTime = log.EndTime.ToString("u").Contains("1900") ? string.Empty: log.EndTime.ToString("u"),
                        Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty,
                        log.JobId,
                    };
            
            var list = j.OrderBy(x => x.JobId)
                        .OrderByDescending(x => x.StartTime);

            dgvJobStatusLog.DataSource = list.ToList();
        }
        private void BindGridTriggerLogs()
        {

            //List the scheduled jobs
            IEnumerable<LogTrigger> logs = _jobsEngine.GetTriggerLogs();
            int i = 1;
            var j = from log in logs
                    select new
                    {
                        //Id = i++,
                        TimeStamp = Convert.ToDateTime(log.TimeStamp),
                        Message = log.Content,
                        Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty
                    };

            var list = j.OrderBy(x => x.TimeStamp.Second)
                        .OrderByDescending(x => x.TimeStamp.Minute)
                        .OrderByDescending(x => x.TimeStamp.Hour)
                        .OrderByDescending(x => x.TimeStamp.Day)
                        .OrderByDescending(x => x.TimeStamp.Month)
                        .OrderByDescending(x => x.TimeStamp.Year);

            dgvTriggerLog.DataSource = list.ToList();
        }
        private void BindGridExecutionLogs()
        {
            IEnumerable<LogExecution> logs = _jobsEngine.GetExecutionLogs();

            var j = from log in logs
                    select new
                    {
                        TimeStamp = Convert.ToDateTime(log.TimeStamp),
                        enginetype = log.Result.enginetype.Contains("Python") ? "Python" : "R",
                        log.Result.starttime,
                        log.Result.endtime,
                        log.Result.output,
                        log.Result.error,
                        log.Result.exception
                        //Job = log.Job != null ? GetJobToShow(log.Job) : string.Empty
                    };

            var list = j.OrderBy(x => x.TimeStamp.Second)
                        .OrderByDescending(x => x.TimeStamp.Minute)
                        .OrderByDescending(x => x.TimeStamp.Hour)
                        .OrderByDescending(x => x.TimeStamp.Day)
                        .OrderByDescending(x => x.TimeStamp.Month)
                        .OrderByDescending(x => x.TimeStamp.Year);

            dgvExecutionLog.DataSource = list.ToList();
        }

        private string GetScheduleToShow(ScheduleTypes scheduleTypes, Schedule schedule)
        {
            //https://docs.microsoft.com/en-us/dotnet/standard/base-types/standard-date-and-time-format-strings
            string schedulestring = string.Empty;
            switch (scheduleTypes)
            {
                case ScheduleTypes.Interval:
                    schedulestring += schedule.IntervalInMinutes.ToString() + " minutes ";
                    break;
                case ScheduleTypes.Daily:
                    schedulestring += schedule.DailyHours.ToString() +" : "+ schedule.DailyMinutes.ToString();
                    break;
                case ScheduleTypes.Weekly:
                    schedulestring += ((DayOfWeek)schedule.WeeklyDayOfWeek).ToString() + ", " + 
                                        schedule.WeeklyHours.ToString()+ " : " + 
                                        schedule.WeeklyMinutes.ToString();
                    break;
                case ScheduleTypes.Monthly:
                    int day = Convert.ToInt32(schedule.MonthlyDayOfMonth);
                    string suffix = (day % 10 == 1 && day != 11) ? "st"
                               : (day % 10 == 2 && day != 12) ? "nd"
                               : (day % 10 == 3 && day != 13) ? "rd"
                                  : "th";
                    schedulestring += schedule.MonthlyDayOfMonth.ToString() + 
                                    suffix + " , " + 
                                    schedule.MonthlyHours.ToString() + " : " + 
                                    schedule.MonthlyMinutes.ToString();
                    break;
            }
            return schedulestring;
        }
        private string GetJobToShow(Job job)
        {
            string str = string.Empty;
            str += "{";
            str += " JobId: " + job.Id.ToString();
            str += ", Description: " + job.Description;
            str += ", NextSchedule: " + job.FirstOrNextSchedule.ToString();
            str += ", ScheduleType: " + job.Schedule.ScheduleType;
            str += ", Schedule: " + GetScheduleToShow(job.Schedule.ScheduleType, job.Schedule);
            str += "ScriptType: " + job.ScriptType;
            str += ", Interpreter: " + job.Interpreter;
            str += ", ScriptFilePath: " + job.ScriptFilePath;
            str += ", CreatedTime: " + job.CreatedTime;
            str += " }";

            return str;
        }

        private void ShowBrowsedFile(TextBox textBox, string filter)
        {
            string scriptFile = string.Empty;
            scriptFile = BrowseFile(filter);

            if (!string.IsNullOrEmpty(scriptFile))
            {
                textBox.ReadOnly = false;
                textBox.Text = scriptFile;
                textBox.ReadOnly = true;
            }
            else
            {
                MessageBox.Show("Please browse a valid file.");
            }
        }
        private string BrowseFile(string filter)
        {
            string fileName = string.Empty;
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = filter, ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                }
            }

            return fileName;
        }
        private void ShowResults(Results result)
        {
            lblText.Text += new ResultHelperFiles().FormatResultToShow(result) + "\n";
        }
        private void btnBrowseScriptFile_Click(object sender, EventArgs e)
        {
            bool isScriptTypeSelected = false;
            string filter = string.Empty;

            if (rdoBtnPython.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.PythonFileFilter;
            }
            else if (rdoBtnR.Checked)
            {
                isScriptTypeSelected = true;
                filter = FileFilters.RFileFilter;
            }
            else
                MessageBox.Show("Please choose script type.");

            if (isScriptTypeSelected)
                ShowBrowsedFile(txtScriptFile , filter);
        }
        private void btnChooseInterpreter_Click(object sender, EventArgs e)
        {
            ShowBrowsedFile(txtInterpreter, FileFilters.InterpreterFilter);
        }
        private void btnTestExecution_Click(object sender, EventArgs e)
        {
            //_logger.WriteLog("Admin application has started script.");

            //string fileName = txtScriptFile.Text;// @"D:\python_auto_sample_1.py";
            //string interpreter = txtInterpreter.Text;// @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";

            //lblText.Text = string.Empty;
            //lblText.Text += fileName;
            //lblText.Text += "\n" + interpreter + "\n\n";

            //IExecutionEngine pyengine = new PythonExecutionEngine();
            //Results result = pyengine.ExecuteScript(interpreter, fileName);
            //ShowResults(result);


            //IExecutionEngine rengine = new RExecutionEngine();
            //result = rengine.ExecuteScript(interpreter, fileName);
            //ShowResults(result);

            //_logger.WriteLog("Admin application has completed script.");

        }
        private void btnScheduleJob_Click(object sender, EventArgs e)
        {
            string scriptType = string.Empty;
            string description = string.Empty;
            string interpreter = string.Empty;
            string scriptfilepath = string.Empty;

            scriptType = rdoBtnPython.Checked ? "Python" : "R";
            description = txtScriptDescription.Text.Trim();
            interpreter = txtInterpreter.Text.Trim();
            scriptfilepath = txtScriptFile.Text.Trim();

            string schedulemsg = ValidateSchedule();

            if (!string.IsNullOrEmpty(scriptType) &
                !string.IsNullOrEmpty(description) &
                !string.IsNullOrEmpty(interpreter) &
                !string.IsNullOrEmpty(scriptfilepath) &
                string.IsNullOrEmpty(schedulemsg))
            {

                Job job = new Job();
                job.Id = Guid.NewGuid();
                job.Interpreter = interpreter;
                job.IsActive = true;
                job.Name = "Name_" + DateTime.Now.ToString().Replace(':', '-');
                job.Description = description;
                job.CreatedTime = DateTime.Now;
                job.ModifiedTime = DateTime.Now;
                job.ScriptFilePath = scriptfilepath;
                job.ScriptType = scriptType;

                Schedule schedule = PrepareSchedule();

                DateTime firstSchedule = new ScheduleEngine().GenerateFirstSchedule(schedule);


                job.Schedule = schedule;
                job.FirstOrNextSchedule = firstSchedule;


                if (job != null & schedule != null)
                {
                    string jobId = _jobsEngine.CreateJob(job);
                    if (!string.IsNullOrEmpty(jobId))
                    {
                        lblText.Text = "Job scheduled: " + jobId;
                        lblText.Text += Environment.NewLine + "Next schedule: " + firstSchedule.ToString();
                    }
                    BindGridJobs();

                    job = null;
                    schedule = null;
                    txtScriptDescription.Text = string.Empty;
                    txtInterpreter.Text = string.Empty;
                    txtScriptFile.Text = string.Empty;

                    comboBoxType.SelectedItem = ScheduleTypes.Select;
                    rdoBtnPython.Checked = true;
                    comboBoxWeeklyDayOfWeek.SelectedIndex = 1;
                    numMonthlyDayOfMonth.Value = 30;
                }
            }
            else
            {
                string msg = string.Empty;
                if (!string.IsNullOrEmpty(schedulemsg))
                    msg = schedulemsg;
                if (string.IsNullOrEmpty(scriptfilepath))
                    msg = "Please browse script file.";
                if (string.IsNullOrEmpty(interpreter))
                    msg = "Please choose interpreter.";
                if (string.IsNullOrEmpty(description))
                    msg = "Please enter script description.";
                if (string.IsNullOrEmpty(scriptType))
                    msg = "Please choose script type.";

                MessageBox.Show(msg);
            }

        }
        private string ValidateSchedule()
        {
            string msg = string.Empty;
            Schedule schedule = PrepareSchedule();

            if (schedule.ScheduleType.Equals(ScheduleTypes.Select))
                msg = "Please select schedule type.";

            switch (schedule.ScheduleType)
            {
                case ScheduleTypes.Interval:
                    msg = schedule.IntervalInMinutes == 0 ? "Please enter valid interval in minutes." : "";
                    break;
                case ScheduleTypes.Daily:
                    msg = (schedule.DailyHours == 0 & schedule.DailyMinutes == 0) ? "Please enter valid daily time of day." : "";
                    break;
                case ScheduleTypes.Weekly:
                    msg = (schedule.WeeklyHours == 0 & schedule.WeeklyMinutes == 0) ? "Please enter valid weekly time of day." : "";
                    break;
                case ScheduleTypes.Monthly:
                    msg = (schedule.MonthlyHours == 0 & schedule.MonthlyMinutes == 0) ? "Please enter valid monthly time of day." : "";
                    break;
            }
            return msg;
        }

        private Schedule PrepareSchedule()
        {

            StringBuilder sbr;
            Schedule schedule = new Schedule();
            schedule.Repeat = chkBoxRepeat.Checked;

            ScheduleTypes selectedType = (ScheduleTypes)comboBoxType.SelectedValue;
            schedule.ScheduleType = selectedType;

            if (!selectedType.Equals(ScheduleTypes.Select))
                switch (selectedType)
                {
                    case ScheduleTypes.Interval:
                        schedule.IntervalInMinutes = Convert.ToInt32(numIntervalInMinutes.Value);
                        break;
                    case ScheduleTypes.Daily:
                        schedule.DailyHours = Convert.ToInt32(numDailyHours.Value);
                        schedule.DailyMinutes = Convert.ToInt32(numDailyMinutes.Value);
                        break;
                    case ScheduleTypes.Weekly:
                        schedule.WeeklyDayOfWeek = Convert.ToInt32(comboBoxWeeklyDayOfWeek.SelectedValue);
                        schedule.WeeklyHours = Convert.ToInt32(numWeeklyHours.Value);
                        schedule.WeeklyMinutes = Convert.ToInt32(numWeeklyMinutes.Value);
                        break;
                    case ScheduleTypes.Monthly:
                        schedule.MonthlyDayOfMonth = Convert.ToInt32(numMonthlyDayOfMonth.Value);
                        schedule.MonthlyHours = Convert.ToInt32(numMonthlyHours.Value);
                        schedule.MonthlyMinutes = Convert.ToInt32(numMonthlyMinutes.Value);
                        break;
                }



            DateTime currentTime = DateTime.Parse(DateTime.Now.ToString("dd/MM/yyyy HH:mm"));

            sbr = new StringBuilder();
            sbr.AppendLine(string.Format("CurrentDate] : {0}", DateTime.Now.ToString()));
            sbr.AppendLine(string.Format("Month ] : {0}", DateTime.Now.Month.ToString()));
            sbr.AppendLine(string.Format("dd/MM/yyyy HH:mm] : {0}", currentTime.ToString()));
            sbr.AppendLine(string.Format("[schedule.Repeat] : {0}", schedule.Repeat.ToString()));
            sbr.AppendLine(string.Format("[schedule.ScheduleType] : {0}", schedule.ScheduleType.ToString()));
            sbr.AppendLine(string.Format("[schedule.IntervalInMinutes] : {0}", schedule.IntervalInMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.DailyHours] : {0}", schedule.DailyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.DailyMinutes] : {0}", schedule.DailyMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyDayOfWeek] : {0}", schedule.WeeklyDayOfWeek.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyHours] : {0}", schedule.WeeklyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.WeeklyMinutes] : {0}", schedule.WeeklyMinutes.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyDayOfMonth] : {0}", schedule.MonthlyDayOfMonth.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyHours] : {0}", schedule.MonthlyHours.ToString()));
            sbr.AppendLine(string.Format("[schedule.MonthlyMinutes] : {0}", schedule.MonthlyMinutes.ToString()));
            sbr.AppendLine(string.Format(""));
            return schedule;
        }
        
        private void comboBoxType_SelectedIndexChanged(object sender, EventArgs e)
        {
            ScheduleTypes selectedType = (ScheduleTypes)comboBoxType.SelectedValue;
            switch (selectedType)
            {
                case ScheduleTypes.Select:
                    HideScheduleBoxes();
                    break;
                case ScheduleTypes.Daily:
                    ShowScheduleBox(tblDaily);
                    break;
                case ScheduleTypes.Interval:
                    ShowScheduleBox(tblInterval);
                    break;
                case ScheduleTypes.Monthly:
                    ShowScheduleBox(tblMonthly);
                    break;
                case ScheduleTypes.Weekly:
                    ShowScheduleBox(tblWeekly);
                    break;
            }

        }
        private void HideScheduleBoxes()
        {
            foreach (TableLayoutPanel tblPanel in listScheduleBoxes)
            {
                tblPanel.Visible = false;
                grpBoxJobScheduling.Height = 100;
            }
        }
        private void ShowScheduleBox(TableLayoutPanel tblBox)
        {
            foreach( TableLayoutPanel tblPanel in listScheduleBoxes)
            {
                if (tblPanel.Equals(tblBox))
                {
                    tblPanel.Visible = true;
                    tblPanel.Location = tblInterval.Location;
                    grpBoxJobScheduling.Height = 180;
                }
                else
                {
                    tblPanel.Visible = false;
                }
            }
        }

        private void dgvTriggerLog_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgvTriggerLog.Rows)
            {
                if (row.Cells[1].Value.ToString().Contains("SA100"))
                {
                    row.DefaultCellStyle.BackColor = Color.LightGray;
                }
            }
            dgvTriggerLog.ClearSelection();
            dgvJobs.ClearSelection();

        }

        private void dgvJobs_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgvJobs.Rows)
            {
                string jobId = row.Cells["JobId"].EditedFormattedValue.ToString();
                string description = row.Cells["Description"].EditedFormattedValue.ToString();
                string nextSchedule = row.Cells["NextSchedule"].EditedFormattedValue.ToString();  
                string scheduleType = row.Cells["ScheduleType"].EditedFormattedValue.ToString();
                string schedule = row.Cells["Schedule"].EditedFormattedValue.ToString();
                string scriptType = row.Cells["ScriptType"].EditedFormattedValue.ToString();
                string interpreter = row.Cells["Interpreter"].EditedFormattedValue.ToString();
                string scriptFilePath = row.Cells["ScriptFilePath"].EditedFormattedValue.ToString();

                string tooltiptext = "Job #" + "\n" 
                                    + "JobId : " + jobId + "\n" 
                                    + "Description : " + description + "\n"
                                    + "NextSchedule : " + nextSchedule + "\n"
                                    + "ScheduleType : " + scheduleType + "\n"
                                    + "Schedule : " + schedule + "\n"
                                    + "ScriptType : " + scriptType + "\n"
                                    + "Interpreter : " + interpreter + "\n"
                                    + "ScriptFilePath : " + scriptFilePath + "\n"+ Environment.NewLine;

                row.Cells[0].ToolTipText = tooltiptext;
                row.Cells[1].ToolTipText = tooltiptext;
                row.Cells[2].ToolTipText = tooltiptext;
                row.Cells[3].ToolTipText = tooltiptext;
            }
        }

        private void dgvJobs_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1 && e.ColumnIndex == 0)
            {
                DataGridViewCheckBoxCell checkBox = (dgvJobs.Rows[e.RowIndex].Cells["chkBoxSelectJob"] as DataGridViewCheckBoxCell);
                checkBox.Value = !(bool)checkBox.FormattedValue;
            }
            bool isAnyChecked = false;
            foreach (DataGridViewRow row in dgvJobs.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectJob"] as DataGridViewCheckBoxCell);
                if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(true))
                {
                    isAnyChecked = true;
                    break;
                }
            }
            if(isAnyChecked)
            {
                btnDeleteJobs.Enabled = true;
                btnRepairSchedule.Enabled = true;
                btnExecuteNow.Enabled = true;
            }
            else
            {
                btnDeleteJobs.Enabled = false;
                btnRepairSchedule.Enabled = false;
                btnExecuteNow.Enabled = false;
            }
        }

        private void btnDeleteJobs_Click(object sender, EventArgs e)
        {
            StringBuilder msg = new StringBuilder();
            IEnumerable<Job> selectedJobs = GetSelectedJobs();
            DialogResult result = MessageBox.Show("Do you want to delete the selected jobs?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                msg.AppendLine("The jobs has been deleted successfully.");

                if (selectedJobs != null)
                {
                    foreach (Job job in selectedJobs)
                    {
                        _jobsEngine.DeleteJob(job);
                        msg.AppendLine(job.Id.ToString());
                    }
                }
                MessageBox.Show(msg.ToString());
                BindGridJobs();
            }
        }

        private IEnumerable<Job> GetSelectedJobs()
        {
            IEnumerable<Job> jobs = _jobsEngine.GetAllJobs();

            List<string> jobIds = new List<string>();

            foreach (DataGridViewRow row in dgvJobs.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectJob"] as DataGridViewCheckBoxCell);
                if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(true))
                {
                    string jobId = row.Cells["JobId"].EditedFormattedValue.ToString();
                    jobIds.Add(jobId);
                }
            }

            List<Job> jobsList = new List<Job>();
            foreach (string jobid in jobIds)
            {
                var filteredlist = jobs.Where(x => x.Id.ToString().Equals(jobid));

                foreach(Job job in filteredlist)
                {
                    jobsList.Add(job);
                }

                //if (filteredlist != null && filteredlist.Count() > 1)
                //{
                //    Job job = filteredlist.First();
                //    jobsList.Add(job);
                //}
            }
            return jobsList.AsEnumerable();
        }

        private void btnRepairSchedule_Click(object sender, EventArgs e)
        {
            StringBuilder msg = new StringBuilder();
            IEnumerable<Job> selectedJobs = GetSelectedJobs();

            DialogResult result = MessageBox.Show("Do you want to repair schedule?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                msg.AppendLine("The jobs has been repaired successfully.");

                if (selectedJobs != null)
                {
                    foreach (Job job in selectedJobs)
                    {
                        job.FirstOrNextSchedule = _scheduleEngine.RepairSchedule(job.Schedule, job.FirstOrNextSchedule);
                        job.ModifiedTime = DateTime.Now;
                        _jobsEngine.UpdateJob(job);
                        msg.AppendLine(job.Id.ToString());
                    }
                }
                MessageBox.Show(msg.ToString());
                BindGridJobs();
            }

        }

        private void dgvJobStatusLog_DataBindingComplete(object sender, DataGridViewBindingCompleteEventArgs e)
        {
            foreach (DataGridViewRow row in dgvJobStatusLog.Rows)
            {
                string job = row.Cells["Job"].EditedFormattedValue.ToString();
                job = job.Replace("{", "Job #" + "\n").Replace("}", "").Replace(",", "\n").Replace(":"," :");
                
                string tooltiptext = job;

                row.Cells[0].ToolTipText = tooltiptext;
                row.Cells[1].ToolTipText = tooltiptext;
                row.Cells[2].ToolTipText = tooltiptext;
                row.Cells[3].ToolTipText = tooltiptext;

                string status = row.Cells["Status"].EditedFormattedValue.ToString();
                if (status.Contains("Success"))
                {
                    //row.Cells["Status"].Style.ForeColor = Color.Green;
                    row.DefaultCellStyle.BackColor = Color.Green;
                    row.DefaultCellStyle.ForeColor = Color.White;

                }
                if (status.Contains("Failed"))
                {
                    //row.Cells["Status"].Style.ForeColor = Color.Red;
                    row.DefaultCellStyle.BackColor = Color.Red;
                    row.DefaultCellStyle.ForeColor = Color.White;
                }
            }

        }

        private void btnExecuteNow_Click(object sender, EventArgs e)
        {
            StringBuilder msg = new StringBuilder();
            DialogResult result = MessageBox.Show("Do you want selected jobs to execute now?", "Confirmation", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                msg.AppendLine("The jobs have initiated execution.");
                var jobsToStart = GetSelectedJobs();

                if (jobsToStart != null)
                {
                    foreach (Job job in jobsToStart)
                    {
                        msg.AppendLine(job.Id.ToString());
                    }
                    AutomationServiceEngine automationServiceEngine = new AutomationServiceEngine();
                    automationServiceEngine.StartAutomation(jobsToStart);
                }

                MessageBox.Show(msg.ToString());
                BindGridJobs();
            }
        }

        private void dgvExecutionLog_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1 && e.ColumnIndex == 4)
            {
                string checkBox = dgvExecutionLog.Rows[e.RowIndex].Cells["output"].EditedFormattedValue.ToString();
                //lblOutput.Text = checkBox;
                txtOutput.Text = checkBox;
            }

        }

        private void btnCheckWindowService_Click(object sender, EventArgs e)
        {
            try
            {
                bool isInstalled = WindowServicesUtility.IsWindowServiceInstalled(AppConfigurations.WinApp_WindowService_Name);
                if (isInstalled)
                {
                    lblText.Text = "Service is installed.";

                    if (WindowServicesUtility.GetWindowServiceStatus(AppConfigurations.WinApp_WindowService_Name).Equals(ServiceControllerStatus.Stopped))
                        isInstalled = WindowServicesUtility.StartWindowService(AppConfigurations.WinApp_WindowService_Name);

                    if (isInstalled)
                        lblText.Text = "Service started successfully.";
                    else
                        lblText.Text = "Service can not be started.";
                }
                else
                    lblText.Text = "Service is not intsalled.";
            }
            catch (Exception ex)
            {
                lblText.Text = ex.Message + "\n" + ex.InnerException.Message;
            }
        }
    }
}
