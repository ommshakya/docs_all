﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    
    public static class WindowServicesUtility
    {
        public static bool IsWindowServiceInstalled(string servicename)
        {
            bool isInstalled = false;
            try
            {
                ServiceController[] serviceControllers = ServiceController.GetServices();
                foreach (ServiceController serviceController in serviceControllers)
                    if (serviceController.ServiceName.Equals(servicename))
                        isInstalled = true;
                return isInstalled;
            }
            catch
            {
                throw;
            }
        }
        public static bool StartWindowService(string servicename)
        {
            bool isStarted = false;
            ServiceController serviceController = new ServiceController(servicename);
            try
            {
                if (IsWindowServiceInstalled(servicename))
                {
                    if (!serviceController.Status.Equals(ServiceControllerStatus.Running))
                        serviceController.Start();
                    isStarted = true;
                }
                return isStarted;
            }
            catch
            {
                throw;
            }
            finally
            {
                serviceController.Dispose();
            }
        }
        public static bool StopWindowService(string servicename)
        {
            bool isStopped = false;
            ServiceController serviceController = new ServiceController(servicename);
            try
            {
                if (IsWindowServiceInstalled(servicename))
                {
                    if (!serviceController.Status.Equals(ServiceControllerStatus.Stopped))
                        serviceController.Stop();
                    isStopped = true;
                }
                return isStopped;
            }
            catch
            {
                throw;
            }
            finally
            {
                serviceController.Dispose();
            }
        }
        public static ServiceControllerStatus GetWindowServiceStatus(string servicename)
        {
            ServiceControllerStatus status = ServiceControllerStatus.Paused;
            ServiceController myService = new ServiceController();
            try
            {
                if (IsWindowServiceInstalled(servicename))
                {
                    myService.ServiceName = servicename;
                    status = myService.Status;
                }
                return status;
            }
            catch
            {
                throw;
            }
            finally
            {
                myService.Dispose();
            }
        }
    }
}
