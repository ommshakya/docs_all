﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class ScheduleEngine
    {
        public DateTime GenerateFirstSchedule(Schedule schedule)
        {
            string formatString = "dd/MM/yyyy HH:mm";
            DateTime currentTime = DateTime.Parse(DateTime.Now.ToString(formatString));

            DateTime nextSchedule = currentTime;

            if (!schedule.ScheduleType.Equals(ScheduleTypes.Select))
                switch (schedule.ScheduleType)
                {
                    case ScheduleTypes.Interval:
                        nextSchedule = currentTime.AddMinutes(Convert.ToInt32(schedule.IntervalInMinutes));
                        break;
                    case ScheduleTypes.Daily:
                        nextSchedule = new DateTime(currentTime.Year, currentTime.Month, currentTime.Day,
                                                    Convert.ToInt32(schedule.DailyHours),
                                                    Convert.ToInt32(schedule.DailyMinutes),
                                                    0);
                        
                        if (nextSchedule < currentTime.AddMinutes(1))
                            nextSchedule = nextSchedule.AddDays(1);
                        break;
                    case ScheduleTypes.Weekly:
                        bool a = true;
                        DateTime firstDate = currentTime;
                        while (a)
                        {
                            if ((int)firstDate.DayOfWeek == Convert.ToInt32(schedule.WeeklyDayOfWeek))
                            {
                                nextSchedule = new DateTime(firstDate.Year, firstDate.Month, firstDate.Day,
                                                            Convert.ToInt32(schedule.WeeklyHours),
                                                            Convert.ToInt32(schedule.WeeklyMinutes),
                                                            0);
                                a = false;
                            }
                            firstDate = firstDate.AddDays(1);
                        }
                        if (nextSchedule < currentTime.AddMinutes(1))
                            nextSchedule = nextSchedule.AddDays(7);
                        break;
                    case ScheduleTypes.Monthly:
                        bool b = true;
                        var firstDayMonth = new DateTime(currentTime.Year, currentTime.Month, 1);
                        DateTime lastDayMonth = new DateTime(currentTime.Year, currentTime.Month, DateTime.DaysInMonth(currentTime.Year, currentTime.Month));

                        // if schedule.MonthlyDayOfMonth > lastDayMonth.Day THEN lastDayMonth_time
                        if (Convert.ToInt32(schedule.MonthlyDayOfMonth) > lastDayMonth.Day)
                        {
                            nextSchedule = new DateTime(lastDayMonth.Year, lastDayMonth.Month, lastDayMonth.Day,
                                                        Convert.ToInt32(schedule.MonthlyHours),
                                                        Convert.ToInt32(schedule.MonthlyMinutes),
                                                        0);
                        }
                        else
                        {
                            while (b)
                            {
                                if (firstDayMonth.Day == Convert.ToInt32(schedule.MonthlyDayOfMonth))
                                {
                                    nextSchedule = new DateTime(firstDayMonth.Year, firstDayMonth.Month, firstDayMonth.Day,
                                                                Convert.ToInt32(schedule.MonthlyHours),
                                                                Convert.ToInt32(schedule.MonthlyMinutes),
                                                                0);
                                    b = false;
                                }
                                firstDayMonth = firstDayMonth.AddDays(1);
                            }
                        }
                        if (nextSchedule.Month == currentTime.Month & nextSchedule < currentTime.AddMinutes(1))
                            nextSchedule = nextSchedule.AddMonths(1);
                        break;
                }
            return nextSchedule;
        }
        public DateTime GenerateNextSchedule(Schedule schedule, DateTime firstorlastschedule)
        {
            DateTime firstSchedule = firstorlastschedule;

            DateTime nextSchedule = firstSchedule;

            if (!schedule.ScheduleType.Equals(ScheduleTypes.Select))
                switch (schedule.ScheduleType)
                {
                    case ScheduleTypes.Interval:
                        nextSchedule = firstSchedule.AddMinutes(Convert.ToInt32(schedule.IntervalInMinutes));
                        break;
                    case ScheduleTypes.Daily:
                        nextSchedule = firstSchedule.AddDays(1);
                        break;
                    case ScheduleTypes.Weekly:
                        nextSchedule = firstSchedule.AddDays(7);
                        break;
                    case ScheduleTypes.Monthly:
                        nextSchedule = firstSchedule.AddMonths(1);
                        break;
                }
            return nextSchedule;
        }

        public DateTime RepairSchedule(Schedule schedule, DateTime firstorlastschedule)
        {
            string formatString = "dd/MM/yyyy HH:mm";
            DateTime currentTime = DateTime.Parse(DateTime.Now.ToString(formatString));

            DateTime nextSchedule = firstorlastschedule;

            bool b = true;
            while (b)
            {
                if (nextSchedule < currentTime)
                    nextSchedule = GenerateNextSchedule(schedule, nextSchedule);
                else
                    b = false;
            }
            
            return nextSchedule;
        }
    }
}
