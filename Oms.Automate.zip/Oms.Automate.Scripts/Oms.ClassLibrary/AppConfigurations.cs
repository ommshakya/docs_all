﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public static class AppConfigurations
    {
        public static string WinApp_WindowService_Name
        {
            get
            {
                string serverName = "OmsScriptAutomationService";
                string name = ConfigurationManager.AppSettings["WinApp_WindowService_Name"];
                if (!string.IsNullOrEmpty(name))
                    serverName = name;
                return serverName;
            }
        }
    }
}
