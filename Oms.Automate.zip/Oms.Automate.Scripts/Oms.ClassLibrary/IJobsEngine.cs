﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public interface IJobsEngine
    {
        string CreateJob(Job job);
        bool DeleteJob(Job job);
        bool UpdateJob(Job job);
        IEnumerable<Job> GetAllJobs();
        IEnumerable<LogTrigger> GetTriggerLogs();
        IEnumerable<LogJobStatus> GetJobStatusLogs();
        IEnumerable<LogExecution> GetExecutionLogs();
    }
}
