﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Oms.ClassLibrary
{
    public class RExecutionEngine : IExecutionEngine
    {
        public Results ExecuteScript(Job job)
        {
            ILogger _logger = new FileLogger();

            var results = new Results();
            try
            {
                Console.WriteLine("Starting process..." + @job.ScriptFilePath);
                DateTime starttime = DateTime.Now;
                DateTime endtime = new DateTime(1900, 1, 1);

                var jsonJob = new JavaScriptSerializer().Serialize(job);

                string started = string.Format("jobid |:| {0}; status |:| {1}; starttime |:| {2}; endtime |:| {3}; job |:| {4}"
                                        , job.Id.ToString(), "ES101 # Started...", starttime, endtime, jsonJob);
                _logger.WriteShortLog(started);
                Console.WriteLine(started);

                Process p = new Process();
                p.StartInfo = new ProcessStartInfo(job.Interpreter, "\"" + job.ScriptFilePath + "\"")
                {
                    RedirectStandardOutput = true,
                    UseShellExecute = false,
                    CreateNoWindow = true,
                    RedirectStandardError = true
                };
                p.Start();

                string running = string.Format("jobid |:| {0}; status |:| {1}; starttime |:| {2}; endtime |:| {3}; job |:| {4}"
                                        , job.Id.ToString(), "ES102 # Running...", starttime, endtime, jsonJob);
                _logger.WriteShortLog(running);
                Console.WriteLine(running);

                string output = p.StandardOutput.ReadToEnd();
                string error = p.StandardError.ReadToEnd();
                p.WaitForExit();


                endtime = DateTime.Now;
                Console.WriteLine("collecting results...");

                string completed = string.Format("jobid |:| {0}; status |:| {1}; starttime |:| {2}; endtime |:| {3}; job |:| {4}"
                                        , job.Id.ToString(), "ES103 # Completed...", starttime, endtime, jsonJob);
                _logger.WriteShortLog(completed);
                Console.WriteLine(completed);

                results.enginetype = this.GetType().ToString();
                results.output = output;
                results.error = error;
                results.exception = null;
                results.starttime = starttime;
                results.endtime = endtime;

                Console.WriteLine("output: " + results);

                p.Close();
                p.Dispose();
            }
            catch
            {
                throw;
            }
            return results;
        }
    }
}
