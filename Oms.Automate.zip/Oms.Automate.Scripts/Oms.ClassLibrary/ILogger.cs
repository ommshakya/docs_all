﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public interface ILogger
    {
        void WriteLog(string log);
        void WriteError(string error);
        void WriteEngineLog(string path, string log);
        void WriteShortLog(string log);
    }
}
