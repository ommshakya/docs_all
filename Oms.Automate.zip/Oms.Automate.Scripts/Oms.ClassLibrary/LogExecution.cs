﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class LogExecution
    {
        public DateTime TimeStamp { get; set; }
        public Results Result { get; set; }
    }
}
