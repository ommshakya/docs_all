﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Oms.ClassLibrary
{
    public class JobHelper
    {
        public string CreateId(Job job)
        {
            return string.Join("_", job.ScriptType, job.IsActive.ToString(), job.Id.ToString());
        }
    }
}
