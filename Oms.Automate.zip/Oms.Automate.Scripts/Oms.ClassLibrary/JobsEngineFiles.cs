﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web.Script.Serialization;


namespace Oms.ClassLibrary
{
    public class JobsEngineFiles : IJobsEngine
    {
        private string SpecialFolder = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData), "OmsAutomateScripts");

        public string CreateJob(Job job)
        {
            string id = new JobHelper().CreateId(job);
            string fileName = id;
            fileName = Path.Combine(SpecialFolder, "Jobs", fileName + ".txt");

            var jsonJob = new JavaScriptSerializer().Serialize(job);

            if (!Directory.Exists(Path.GetDirectoryName(fileName)))
                Directory.CreateDirectory(Path.GetDirectoryName(fileName));

            if (!File.Exists(fileName))
                using (FileStream fs = File.Create(fileName)) { fs.Close(); }

            if (File.Exists(fileName))
            {
                using (StreamWriter sw = File.CreateText(fileName))
                {
                    sw.Write(jsonJob);
                }
            }
            return id;
        }
        public bool DeleteJob(Job job)
        {
            bool isDeleted = false;
            string id = new JobHelper().CreateId(job);
            string fileName = id;
            fileName = Path.Combine(SpecialFolder, "Jobs", fileName + ".txt");
            
            if (File.Exists(fileName))
            {
                File.Delete(fileName);
                isDeleted = true;
            }
            return isDeleted;
        }
        public bool UpdateJob(Job job)
        {
            string id = new JobHelper().CreateId(job);
            string fileName = id;
            fileName = Path.Combine(SpecialFolder, "Jobs", fileName + ".txt");

            var jsonJob = new JavaScriptSerializer().Serialize(job);

            File.WriteAllText(fileName, jsonJob);
            //TODO:
            //update the NextSchedule of job in the saved file
            return true;
        }
        public IEnumerable<Job> GetAllJobs()
        {
            List<Job> list = new List<Job>();
            DirectoryInfo dir = new DirectoryInfo(SpecialFolder);

            string folder = SpecialFolder + "\\Jobs";

            if (Directory.Exists(folder))
            {

                string[] jobFiles = Directory.GetFiles(SpecialFolder + "\\Jobs");

                foreach (string file in jobFiles)
                {
                    if (System.IO.File.Exists(file))
                    {
                        string jsonJob = System.IO.File.ReadAllText(file);
                        var job = new JavaScriptSerializer().Deserialize<Job>(jsonJob);
                        job.CreatedTime = job.CreatedTime.ToLocalTime();
                        job.FirstOrNextSchedule = job.FirstOrNextSchedule.ToLocalTime();
                        list.Add(job);
                    }
                }
            }

            return list.AsEnumerable();
        }

        //public IEnumerable<object> GetAllLogs()
        //{
        //    List<object> list = new List<object>();
        //    DirectoryInfo dir = new DirectoryInfo(SpecialFolder);

        //    string[] jobFiles = Directory.GetFiles(SpecialFolder + "\\OutputLogs");

        //    foreach (string file in jobFiles)
        //    {
        //        if (System.IO.File.Exists(file))
        //        {
        //            string jsonJob = System.IO.File.ReadAllText(file);
        //            //var job = new JavaScriptSerializer().Deserialize<Job>(jsonJob);
        //            list.Add(jsonJob);
        //        }
        //    }

        //    return list.AsEnumerable();
        //}
        public IEnumerable<LogTrigger> GetTriggerLogs()
        {
            List<LogTrigger> list = new List<LogTrigger>();
            DirectoryInfo dir = new DirectoryInfo(SpecialFolder);


            string folder = SpecialFolder + "\\LogsTrigger";

            if (Directory.Exists(folder))
            {

                string[] jobFiles = Directory.GetFiles(SpecialFolder + "\\LogsTrigger");

                foreach (string file in jobFiles)
                {
                    if (System.IO.File.Exists(file))
                    {
                        string[] lines = System.IO.File.ReadAllLines(file);
                        //var job = new JavaScriptSerializer().Deserialize<Job>(jsonJob);
                        foreach (string line in lines)
                        {
                            DateTime timestamp = DateTime.Now;
                            string content = string.Empty;
                            Job job = null;

                            string[] lineParts = line.Split('\t');

                            timestamp = Convert.ToDateTime(lineParts[0]);
                            content = lineParts[1];


                            string[] contentparts = lineParts[1].Split(new string[] { "Job #" }, StringSplitOptions.None);
                            if (contentparts.Length > 1)
                            {
                                content = contentparts[0];
                                string[] jobparts = contentparts[1].Split('#');
                                if (jobparts.Length > 1)
                                {
                                    var job_ = new JavaScriptSerializer().Deserialize<Job>(jobparts[0]);
                                    job = job_;
                                    job.CreatedTime = job.CreatedTime.ToLocalTime();
                                    job.FirstOrNextSchedule = job.FirstOrNextSchedule.ToLocalTime();
                                }
                            }
                            list.Add(new LogTrigger { TimeStamp = timestamp, Content = content, Job = job });
                        }
                    }
                }
            }

            return list.AsEnumerable();
        }

        public IEnumerable<LogJobStatus> GetJobStatusLogs()
        {
            List<LogJobStatus> list = new List<LogJobStatus>();
            DirectoryInfo dir = new DirectoryInfo(SpecialFolder);

            string folder = SpecialFolder + "\\LogsJobStatus";

            if (Directory.Exists(folder))
            {
                string[] jobFiles = Directory.GetFiles(folder);

                foreach (string file in jobFiles)
                {
                    if (System.IO.File.Exists(file))
                    {
                        string[] lines = System.IO.File.ReadAllLines(file);
                        foreach (string line in lines)
                        {
                            DateTime timestamp = DateTime.Now;
                            string content = string.Empty;
                            Job job = null;

                            DateTime starttime = DateTime.Now;
                            DateTime endtime = DateTime.Now;
                            string status = string.Empty;
                            string jobid = string.Empty;

                            string[] lineParts = line.Split('\t');

                            timestamp = Convert.ToDateTime(lineParts[0]);
                            content = lineParts[1];

                            string[] contentParts = content.Split(';');
                            foreach (string part in contentParts)
                            {
                                string key = part.Split(new string[] { "|:|" }, StringSplitOptions.None)[0].Trim();
                                string value = part.Split(new string[] { "|:|" }, StringSplitOptions.None)[1].Trim();
                                switch (key)
                                {
                                    case "jobid":
                                        jobid = value;
                                        break;
                                    case "status":
                                        status = value;
                                        break;
                                    case "starttime":
                                        starttime = Convert.ToDateTime(value);
                                        break;
                                    case "endtime":
                                        endtime = Convert.ToDateTime(value);
                                        break;
                                    case "job":
                                        job = new JavaScriptSerializer().Deserialize<Job>(value); // TODO : Just read unique job from file and append in job here
                                        job.CreatedTime = job.CreatedTime.ToLocalTime();
                                        job.FirstOrNextSchedule = job.FirstOrNextSchedule.ToLocalTime();
                                        break;
                                }
                            }

                            //string[] contentparts = lineParts[1].Split(new string[] { "Job #" }, StringSplitOptions.None);
                            //if (contentparts.Length > 1)
                            //{
                            //    content = contentparts[0];
                            //    string[] jobparts = contentparts[1].Split('#');
                            //    if (jobparts.Length > 1)
                            //    {
                            //        var job_ = new JavaScriptSerializer().Deserialize<Job>(jobparts[0]);
                            //        job = job_;
                            //    }
                            //}
                            list.Add(new LogJobStatus { TimeStamp = timestamp, JobId = jobid, StartTime = starttime, EndTime = endtime, Status = status, Job = job });
                        }
                    }
                }
            }

            return list.AsEnumerable();
        }

        public IEnumerable<LogExecution> GetExecutionLogs()
        {

            List<LogExecution> list = new List<LogExecution>();
            DirectoryInfo dir = new DirectoryInfo(SpecialFolder);

            string folder = SpecialFolder + "\\LogsExecution";

            if (Directory.Exists(folder))
            {
                string[] jobFiles = Directory.GetFiles(folder);

                foreach (string file in jobFiles)
                {
                    if (System.IO.File.Exists(file))
                    {
                        string[] lines = System.IO.File.ReadAllLines(file);
                        foreach (string line in lines)
                        {
                            DateTime timestamp = DateTime.Now;
                            string[] lineParts = line.Split('\t');

                            timestamp = Convert.ToDateTime(lineParts[0]);

                            string resultpart = lineParts[1];
                            var result = new JavaScriptSerializer().Deserialize<Results>(resultpart);


                            result.endtime = result.endtime.ToLocalTime();
                            result.starttime = result.starttime.ToLocalTime();

                            list.Add(new LogExecution { TimeStamp = timestamp, Result = result });
                        }
                    }
                }
            }
            return list.AsEnumerable();
        }
    }
}

