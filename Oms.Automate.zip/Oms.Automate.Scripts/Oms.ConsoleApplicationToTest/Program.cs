﻿using Oms.ClassLibrary;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Web.Script.Serialization;

namespace Oms.ConsoleApplicationToTest
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            IJobsEngine _jobsEngine = new JobsEngineFiles();
            
            string fileName = @"D:\python_auto_sample_1.py";
            string interpreter = @"C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe";
            string interpreter1 = @"C:\Program Files\Anaconda3\python.exe";

            IExecutionEngine pyengine = new PythonEngine();
            Results result = pyengine.ExecuteScript(interpreter1, fileName);
            ShowResults(result);
            Console.WriteLine("****************************************************************");
            IExecutionEngine rengine = new REngine();
            result = rengine.ExecuteScript(interpreter, fileName);
            ShowResults(result);
             */

            new AutomationServiceEngine().StartAutomation(null);
            Console.Read();
        }

        private static void ShowResults(Results result)
        {
            Console.WriteLine("Engine type : {0}", result.enginetype);

            Console.WriteLine("\nOutput \n");
            Console.WriteLine(result.output);

            if (!string.IsNullOrEmpty(result.error))
            {
                Console.WriteLine("\nError \n");
                Console.WriteLine(result.error);
            }

            if (!string.IsNullOrEmpty(result.exception))
            {
                Console.WriteLine("\nException \n");
                Console.WriteLine(result.exception);
            }
        }
    }
}
