# -*- coding: utf-8 -*-
"""
Created on Mon Mar  5 14:00:50 2018

@author: OmPrakash.Shakya
"""
#Import pyodbc module using below command
import pyodbc as db
import pandas as pd
 
connection_string = 'DRIVER={ODBC Driver 13 for SQL Server};SERVER=TSCDELLAP1001\SQLEXPRESS;Trusted_Connection=yes;DATABASE=Learn'

def ReadData_FlatCode():
    con = db.connect(connection_string)
    cur = con.cursor()
 
    #SELECT all rows from table
    qry = '''SELECT [Name]   
                    ,[Date]      
                    ,[Age]      
                    ,[Location]      
                    ,[Country]  
              FROM [Learn].[dbo].[MINI_DATA]
          '''
    cur.execute(qry)
    for row in cur:
        ### print a row
        ### print by property
        ### print by indexes
    
        print(row)
        #print(row.Name +"," + row.Age) 
        #print(row[0] + "," + row[1])
        
    ###Close the cursor and connection objects
    cur.close() 
    con.close()


def ReadData():
    try:
        con = db.connect(connection_string)
        cur = con.cursor()
        qry = 'SELECT [Name]   ,[Date]      ,[Age]      ,[Location]      ,[Country]  FROM [Learn].[dbo].[MINI_DATA]'
        cur.execute(qry)
        
#        ### Way 1 : loop throughh all the rows in cur
#        print('Way 1 : loop throughh all the rows in cur')
#        for row in cur:
#            ### print a row
#            ### print by property
#            ### print by indexes
#            
#            print(row)
#            #print(row.Name +"," + row.Age) 
#            #print(row[0] + "," + row[1]) 

#        ### Way 2 : loop throughh all the rows one by one at a time in cur
#        print('Way 2 : loop throughh all the rows one by one at a time in cur')
#        row = cur.fetchone()
#        while row:
#            ### print a row
#            ### print by property
#            ### print by indexes
#            
#            print(row)
#            #print(row.Name +"," + row.Age) 
#            #print(row[0] + "," + row[1]) 
#            row = cur.fetchone()
        
        ### Way 3 : Fetch all the rows in a single hit and loop throughh all the rows in cur
        print('Way 3 : Fetch all the rows in a single hit and loop throughh all the rows in cur')
        data = cur.fetchall()
        for row in data:
            ### print a row
            ### print by property
            ### print by indexes
            
            print(row)
            #print(row.Name +"," + row.Age) 
            #print(row[0] + "," + row[1])
            
        cur.close()
        
    except db.Error:
        if con:
            con.rollback()
            print('Exception occured')
    finally:
        if con:
            con.close()
            print('Finally it''s done')
        
if __name__ == '__main__':
    ReadData()


ReadData_FlatCode()




############pandas.DataFrame.to_sql() function to insert the dataframe into sql #########
import sqlalchemy
import pandas as pd
engine = sqlalchemy.create_engine("mssql+pyodbc://sa:admin@1234@odbc_sql_16")

df_test = pd.DataFrame(
            {
            "emp_code" : [20150102, 20150301, 20150302, 20150401],
            "emp_name" : ['Noah', 'Jacob', 'Ethan', 'James'],
            "emp_team" : ['IT', 'DA', 'DA', 'ADMIN'],
            "emp_grade" : ['L2', 'L2', 'L3', 'L1'],
            "emp_is_active" : [True, False, True, True],
            }
        )

df_test.head()
df_test.to_sql("tb_employees", engine, if_exists = 'append')

########## Read the table from sql ############
pd.read_sql_table('tb_employees', engine)




################# pyOdbc with DSN to interact with sql server ##############
import pyodbc as db
conn = db.connect('DSN=odbc_sql_16;UID=sa;PWD=admin@1234')
#conn = db.connect("DSN=BCTHEAT")
cursor = conn.cursor()
cursor.execute("select A, B from python_df_1")
row = cursor.fetchall()
for r in row:
    print(r)
    
########### Another way to define the connection string ############
    
    import pyodbc
import pandas as pd
instance_name = r"TSCDELLAP1001\SQLEXPRESS"
db_name = "Learn"
conn_str = (
    "Driver={SQL Server Native Client 11.0};" +
    "Server={0};".format(instance_name) +
    "Database={0};".format(db_name) +
    "Trusted_Connection=yes;"
    )
conn = pyodbc.connect(conn_str)
print("Connected to {0} database on {1}.".format(db_name, instance_name))
