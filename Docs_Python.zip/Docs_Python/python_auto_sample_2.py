# -*- coding: utf-8 -*-
"""
Created on Tue Apr  3 17:53:32 2018

@author: OmPrakash.Shakya
"""

import sys
print(sys.path)
print(sys.executable)

print("\n")

import os
print(os.path)
#print(os.__version__)

def Simple():
	print("Hello from Python")
	print("Call Dir(): ")
	print(dir())
	print("Print the Path: ")
	print(sys.path)
    
Simple()

#C:\Program Files (x86)\Microsoft Visual Studio\Shared\Anaconda3_64\python.exe