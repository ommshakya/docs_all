# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 10:13:33 2018

@author: OmPrakash.Shakya
"""

############pandas.DataFrame.to_sql() function to insert the dataframe into sql #########
import sqlalchemy
import pandas as pd
engine = sqlalchemy.create_engine("mssql+pyodbc://sa:admin@1234@odbc_sql_16")

df_test = pd.DataFrame(
            {
            "emp_code" : [20150102, 20150301, 20150302, 20150401],
            "emp_name" : ['Noah', 'Jacob', 'Ethan', 'James'],
            "emp_team" : ['IT', 'DA', 'DA', 'ADMIN'],
            "emp_grade" : ['L2', 'L2', 'L3', 'L1'],
            "emp_is_active" : [True, False, True, True],
            }
        )

df_test.head()
df_test.to_sql("tb_employees", engine, if_exists = 'append')

########## Read the table from sql ############
pd.read_sql_table('tb_employees', engine)



























