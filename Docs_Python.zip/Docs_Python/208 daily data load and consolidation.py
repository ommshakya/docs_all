# -*- coding: utf-8 -*-
"""
Created on Fri Nov 24 12:43:00 2017

@author: Mohit.Vats
"""

#Code to match the file column names
#import numpy as np
import pandas as pd
#import dask.dataframe as dd 
import os
import glob


#Set the current working directories
print("Existing current direcory: " + os.getcwd() + ", Changing CWD...")
os.chdir('D:\AutomationPython\MainFilesCreation')
print("Existing current direcory: " + os.getcwd())

basefolder = 'D:\\AutomationPython\\MainFilesCreation\\'

##### Function to read the raw files and do all the manipulation and standardization activities#####
def ReadData( file_name, sheetname, columnstoskip, rowstoskip, midcolumnstobedeleted, columnstobedeletedList, country_flag, countryName):
    
    ##### Extracting standard column names from the Standard File Format Folder #####
    stdFileColumnNames = basefolder + 'StandardizedColumnNames\\' + country_flag + '.xlsx'
    standardFileFormat = pd.read_excel(stdFileColumnNames, sheetname = "Sheet1")
    print('in read data start')
    ##### Extracting conversion rates for the currency conversion #####
#    conversionFileFormat = pd.read_excel('E:\\My Data\\Suntory\\MainFilesCreation\\StandardizedColumnNames\\List of Required Currency Conersion Rates - コピー.xlsx', 
#                                         sheetname = "cover",skiprows=2) # here sheetname is fixed
#    conversionFileFormat = conversionFileFormat.iloc[:,[2,3]]
#    conversionFileFormat.columns = ["Currency","Currency USD"]
#    conversionFileFormat = conversionFileFormat.dropna(axis=0, how='all')
    
    ##### Extracting data from the Raw Files Folder for processing and standardsation #####
    dataFile = pd.read_excel(fileName , sheetname = sheetname, skiprows = rowstoskip)
    
#    if country_flag == 'Japan Direct PM' and sheetname == 'PM':
#        dataFile = dataFile.iloc[:,0:31]
#    elif country_flag == 'Japan Direct RM' and sheetname == 'RM':
#        dataFile = dataFile.iloc[:,[1,2,3,4,5,6,7,8,9,10,11,12]] #,27,28,34,35,36,41,43
#    else:
#    dataFile.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\ZZZZZ.csv", sep=',', index = False)
    dataFile.to_csv(basefolder + "OutPutFiles\\"+country_flag+"AAAA.csv", sep=',', index = False, encoding='utf-8-sig')
    dataFile = dataFile.drop(dataFile.columns[columnstobedeletedList], axis = 1) # [0,19,20]
    
    if country_flag == 'Indonesia Indirect':
        dataFile = dataFile.drop(dataFile.columns[[1,14,15]], axis = 1)
    elif country_flag == 'Malaysia Indirect':
        dataFile = dataFile.drop(dataFile.columns[[1,13,15,21,22,24,26]], axis = 1)
    elif country_flag == 'Vietnam Indirect':
        dataFile = dataFile.drop(dataFile.columns[[24]], axis = 1)
    elif country_flag == 'SBFE':
        dataFile = dataFile.drop(dataFile.columns[[2,5,23,24]], axis = 1)
    elif country_flag == 'Frucor Indirect':
        dataFile = dataFile.drop(dataFile.columns[[13]], axis = 1)
    print('in read data start1')
    ##### Applying the standardized colum names to the data set #####
    df1_cols = list(standardFileFormat)
    dataFile.columns = df1_cols
    print('in read data start2')
    
    if 'Year' in dataFile:
        dataFile = dataFile[dataFile.Year == 2016]
        dataFile.insert(4, 'Month', '')
        dataFile.insert(5, 'Quarter', '')
    else:
        dataFile["Date"] = pd.to_datetime(dataFile["Date"] )
        dataFile = dataFile[dataFile.Date >= '01/01/2016']
        dataFile.insert(4, 'Month', dataFile['Date'].dt.month)
        dataFile.insert(5, 'Quarter', dataFile['Date'].dt.quarter)
        dataFile.insert(6, 'Year', dataFile['Date'].dt.year)
    
    
    if countryName == 'Frucor': 
        countryName = 'New Zealand'
    elif countryName == 'SBFE':
        countryName = 'Europe'
    else: 
        countryName
    
    
    ##### Adding additional columns like CountryName and SpendType #####
#    if country_flag != 'Japan Direct':
    dataFile.insert(1, 'Country', countryName)
    dataFile.insert(2, 'Spend Type', dataFile.apply (lambda row: spend_type (row),axis=1))
    
    print('--countryName is --'+countryName)
    print('--Country is --'+country)
    print('--Country Flag is --'+country_flag)
    
    dataFile['Company'] = dataFile.apply (lambda row: country_company_type (row),axis=1)
    
    if 'Categorization UID' in dataFile:
        dataFile['Categorization UID'] = countryName + ' ' + dataFile['Categorization UID'].astype(str) 
#        dataFile['Categorization UID New'] = countryName + ' ' + dataFile['Categorization UID'].astype(str)
    
    cleanedSupplNames = pd.read_excel(basefolder + 'StandardizedColumnNames\\Supplier Name Cleansing - 3 January 2018 - All.xlsx', 
                                         sheetname = "Consolidated") # here sheetname is fixed
    cleanedSupplNames = cleanedSupplNames.iloc[:,[0,1,2]]
    
    cleanedSupplNames['Join Column Key'] = cleanedSupplNames['Country'] + ' ' + cleanedSupplNames['Supplier Names']
    
    if countryName == 'Japan':
        dataFile['Join Column Key'] = dataFile['Country'] + ' ' + dataFile['Spend Type'] + ' ' + dataFile['Taxonomy L1'] + ' ' + dataFile['Supplier Name'].astype(str) 
    elif countryName == 'Australia' or countryName == 'SBFE':
        dataFile['Join Column Key'] = dataFile['Country'] + ' ' + dataFile['Supplier Name']
    else:
        dataFile['Join Column Key'] = dataFile['Country'] + ' ' + dataFile['Spend Type'] + ' ' + dataFile['Supplier Name']
    
    dataFile = pd.merge(dataFile, cleanedSupplNames[['Join Column Key','Clean Names']], how='left', on = ['Join Column Key'])
    
#    if country_flag == 'Vietnam Indirect':
#        dataFile.insert(52, 'Taxonomy L5', '')
    
    ##### Applying Data Conversion rules and values as per the data extracted above #####
#    dataConversion = pd.merge(dataFile, conversionFileFormat, how='left', on=['Currency'])
#    
#    dataFile['Currency USD'] = dataConversion['Currency USD']
##    del dataConversion
#    dataFile['Converted Value In USD'] = dataFile['Spend LCC'] * dataFile['Currency USD']
    
    return dataFile


##### Function to delete the irrelevant columns and rows #####
def GetColIndexToDelete(fDRecords):
    
    fDRecords=fDRecords.reset_index()
    columnstobedeletedList = []
#    print(columnstobedeletedList)
    noofcolumns = fDRecords.loc[0,"No of Columns"]
    colstoskip = fDRecords.loc[0,"Columns to skip"]
    colstodel = fDRecords.loc[0,"End Columns to be deleted"]
    columnsToSkipIndex = []

    if colstoskip > 0:
        for c in range(0, colstoskip):
            columnsToSkipIndex.append(c)
        
    if colstodel > 0:
        if colstoskip > 0:
            incrementalValue = 1
        else:
            incrementalValue = 0
        for cd in range(0, colstodel):
            columnsToSkipIndex.append(noofcolumns + incrementalValue)
            incrementalValue = incrementalValue + 1

    columnstobedeletedList = columnsToSkipIndex[:]

    return columnstobedeletedList

##### Function to create the Spend Type column based on the "Taxonomy L1" column #####
def spend_type (row):
   if row['Taxonomy L1'] == 'RM' or row['Taxonomy L1'] == 'PM':
      return 'Direct'
   elif row['Taxonomy L1'] == 'InterCompany' :
      return 'InterCompany'
   elif row['Taxonomy L1'] == 'Other' :
      return 'Other'
   elif row['Taxonomy L1'] == 'Utilities' :
      return 'Utilities'
   else:
       return 'Indirect'

def conversion(row):
    return row['J1'] * row['J2']

def country_company_type (row):
   if row['Country'] == 'Australia' :
      return 'Cerebos'
   elif row['Country'] == 'Japan' :
      return 'SBE'
   elif row['Country'] == 'Vietnam' :
      return 'SPVB'
   elif row['Country'] == 'New Zealand' :
      return 'Frucor'
   elif row['Country'] == 'Malaysia' :
      return 'SMY'
   elif row['Country'] == 'Indonesia' :
      return 'SGB'
   elif row['Country'] == 'Europe' :
      return 'SBFE'
   else:
       return 'Not Available'

def Get_USD_Value(df,countryCode):
    return float(df[df.Currency == countryCode]['Currency Conversion Rate(LCC vis-à-vis USD)'])

def Get_Dollar_Code (country):
   if country == 'Australia' :
      return 'AUD'
   elif country == 'Japan' :
      return  'JPY'
   elif country == 'Vietnam' :
      return  'VND'
   elif country == 'New Zealand' :
      return  'NZD'
   elif country == 'Malaysia' :
      return  'MYR'
   elif country == 'Indonesia' :
      return  'IDR'
   elif country == 'Europe' :
      return  'EUR'
   else:
       return  'Not Available'

def conversionA(row,df,country):
    dollarCode = Get_Dollar_Code (country)
    standardCountry = Get_USD_Value(df,row['Currency'])
    standardCountry1 = Get_USD_Value(df,dollarCode)
#    a = float(row['Spend (In LCC)'].replace(",", ""))
    a = float(row['Spend (In LCC)'])
    return (a * standardCountry)/standardCountry1

def conversionB(row,df,ctype):
    standardCountry = Get_USD_Value(df,ctype)
    aa = float(row['Currency Conversion Rate(LCC vis-à-vis USD)'])
    return aa/standardCountry

columnstobedeletedListParam = []

##### Read the File Dictionary for the file formats which have been standardized #####
fileDictionary = pd.read_excel('D:\AutomationPython\MainFilesCreation\StandardizedColumnNames\FileDictionary.xlsx', sheetname="Sheet1")

counter = 1

##### Code to read the raw files in an incremental manner #####
os.chdir('D:\AutomationPython\MainFilesCreation\RawDataFiles')
#os.chdir('E:\My Data\Suntory\MainFilesCreation\FilesExecutedAndCheckedWithCodeSucessfully')

for FileList in glob.glob('*.xlsx'):
    
    fileName = FileList
    print('File name ' + str(counter) + ' is '+ fileName)
    strarr = fileName.split(sep = ' ')
    country = strarr[0]
    spendType = strarr[1]
    print('spendType---'+spendType)
#    additionalFlag = strarr[2]
    country_flag = ''
    b = False
    if spendType == "Direct":
        print("Data Contains Direct And Country Is--- "+country)
        spendType = 'Direct'
        if country == 'Australia' or country == 'SBFE':
            country_flag = country
#        elif country == 'Japan':
#            country_flag = country + " Direct " + additionalFlag
        else:
            country_flag = country + " Direct"
    elif spendType == "Indirect":
        spendType = 'Indirect'
#        print("Data Contains Indirect In ElseIf Section")
        country_flag = country + " Indirect"
    else:
        country_flag = country
#        print("Data Contains Indirect in Else Section")
    
    # get record from dictionary
    fileDicRecords = fileDictionary[fileDictionary.Country == country_flag]
    noofrowsForCountry = fileDicRecords.shape[0]
    columnstobedeletedList = []
    df_1 = pd.DataFrame()

    ##### Function to create the Spend Type column based on the "Taxonomy L1" column #####
    if noofrowsForCountry > 1:
        print('In if1')
        #loop for each
        for n in range(noofrowsForCountry):
            print('In if2')
            lst=fileDicRecords.columns
            lst1=[]
            lst1.append(fileDicRecords.iloc[n])
            df=pd.DataFrame(data=lst1,columns=lst)
            
            ##### Function to delete the irrelevant columns and rows invoked here #####
            columnstobedeletedListParam =  GetColIndexToDelete(df)
            
            ##### Function to read the raw files and do all the manipulation and standardization activities invoked here #####
            # file_name, sheetname, columnstoskip, rowstoskip, columnstobedeleted
            temp_df = ReadData(fileName, fileDicRecords.iloc[n]["Sheet Name"]
                            , fileDicRecords.iloc[n]["Columns to skip"]
                            , fileDicRecords.iloc[n]["Rows to skip"]
                            , fileDicRecords.iloc[n]["Mid Columns To be deleted"]
                            , columnstobedeletedListParam, country_flag, country)
#            temp_df.insert(loc=2, column = 'Sheet Name', value = fileDicRecords.iloc[n]["Sheet Name"])
            df_1 = df_1.append(temp_df,ignore_index=True)
            
    else:
        ##### Function to delete the irrelevant columns and rows invoked here #####
        columnstobedeletedListParam =  GetColIndexToDelete(fileDicRecords)
        print('In else')
        ##### Function to read the raw files and do all the manipulation and standardization activities invoked here #####
        temp_df = ReadData(fileName, fileDicRecords.iloc[0]["Sheet Name"]
                            , fileDicRecords.iloc[0]["Columns to skip"]
                            , fileDicRecords.iloc[0]["Rows to skip"]
                            , fileDicRecords.iloc[0]["Mid Columns To be deleted"]
                            , columnstobedeletedListParam, country_flag, country)
#        print(fileDicRecords.iloc[0]["Mid Columns To be deleted"])
        df_1 = pd.DataFrame(columns=list(temp_df.columns))
        df_1 = df_1.append(temp_df)
    
    
    ##### Extracting conversion rates for the currency conversion #####
    conversionFileFormat = pd.read_excel(basefolder + 'StandardizedColumnNames\\List of Required Currency Conersion Rates - コピー.xlsx', 
                                         sheetname = "cover",skiprows=2) # here sheetname is fixed
    conversionFileFormat = conversionFileFormat.iloc[:,[2,3]]
    conversionFileFormat.columns = ["Currency","Currency Conversion Rate(LCC vis-à-vis USD)"]
    conversionFileFormat = conversionFileFormat.dropna(axis=0, how='all')
    
    df_1 = df_1[df_1['Spend (In LCC)'] != 0]
    df_1 = df_1.dropna(subset=['Spend (In LCC)'])
    
    if country_flag == 'Vietnam Direct':
        
        df_1['Spend (In LCC)'] = df_1['Unit Price'] * df_1['Quantity']
    
    df_1 = df_1.drop_duplicates(subset='UID', keep="last")
#    df_1 = df_1.dropna(subset=['Clean Names'])
#    df_1 = df_1['Spend LCC'].replace('', 0, inplace=True)
    
    ##### Applying Data Conversion rules and values as per the data extracted above #####
    df_ConvertedFile = pd.merge(df_1, conversionFileFormat, how='left', on=['Currency']) 
    
    
    ##### Applying Currency Conversion rules and values to local currency #####
    dCode = Get_Dollar_Code (country)
    
    df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')'] = df_ConvertedFile.apply (lambda row: conversionA (row,conversionFileFormat,country),axis=1)

     ##### Applying Currency Conversion rules and values as per the data extracted above #####
    df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis GBP)'] = df_ConvertedFile.apply (lambda row: conversionB (row,conversionFileFormat,'GBP'),axis=1)
    df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis JPY)'] = df_ConvertedFile.apply (lambda row: conversionB (row,conversionFileFormat,'JPY'),axis=1)
    df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis EUR)'] = df_ConvertedFile.apply (lambda row: conversionB (row,conversionFileFormat,'EUR'),axis=1)
    
    ##### Applying Spend Conversion rules and values as per the data extracted above #####
    df_ConvertedFile['Spend (in BU''s LCC)'] = df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')']
    df_ConvertedFile['Spend (In EUR)'] = df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')'] * df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis EUR)']
    df_ConvertedFile['Spend (In GBP)'] = df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')'] * df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis GBP)']
    df_ConvertedFile['Spend (In JPY)'] = df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')'] * df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis JPY)']
    df_ConvertedFile['Spend (In USD)'] = df_ConvertedFile['Cerebos Spend in LCC ('+dCode+')'] * df_ConvertedFile['Currency Conversion Rate(LCC vis-à-vis USD)']
#    df_1['Currency USD'] = dataConversionA['Currency USD']
#    df_1['Converted Value In USD'] = dataConversionA['Converted Value In USD']
    
#    df_1['Converted Value In USD'] = df_1['Spend LCC'] * df_1['Currency USD']
    
    
    
    
    
    ##### Write the file to the destination folder for all the Business Units' dynamically #####
    df_ConvertedFile.to_csv(basefolder + "OutPutFiles\\"+country_flag+".csv", sep=',', index = False, encoding='utf-8-sig')
    counter = counter + 1
    
###### Code to write the individual files to the consolidated file Starts #####
    
#dfAustralia = pd.read_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Australia.csv",encoding='utf-8-sig')
#dfFrucorDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Frucor Direct.csv",encoding='utf-8-sig')
#dfFrucorIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Frucor Indirect.csv",encoding='utf-8-sig')
#dfIndonesiaDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Indonesia Direct.csv",encoding='utf-8-sig')
##dfIndonesiaDirect.rename(columns={'BUâ€™s \r\nFactory': 'BU’s \r\nFactory', 'Manufacturerâ€™s \r\nFactory': 'Manufacturer’s \r\nFactory'}, inplace=True)
##indCols = list(dfIndonesiaDirect)
##dfIndonesiaDirect = dfIndonesiaDirect.loc[:, indCols]
#dfIndonesiaIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Indonesia Indirect.csv",encoding='utf-8-sig')
#dfJapanDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Japan Direct.csv",encoding='utf-8-sig')
#dfMalaysiaDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Malaysia Direct.csv",encoding='utf-8-sig')
#dfMalaysiaIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Malaysia Indirect.csv",encoding='utf-8-sig')
#dfSBFE = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\SBFE.csv",encoding='utf-8-sig')
#dfVietnamDirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Vietnam Direct.csv",encoding='utf-8-sig')
#dfVietnamIndirect = pd.read_csv("E:\My Data\Suntory\MainFilesCreation\OutPutFiles\Vietnam Indirect.csv",encoding='utf-8-sig')
#
#
#dfConsolidated = pd.concat([dfAustralia, dfFrucorDirect, dfFrucorIndirect, dfIndonesiaDirect, dfIndonesiaIndirect, dfJapanDirect, 
#                            dfMalaysiaDirect, dfMalaysiaIndirect, dfSBFE, dfVietnamDirect, dfVietnamIndirect], axis = 0, ignore_index = True)
#
#    
#dfConsolidated = dfConsolidated.drop(['Business Transaction Type','Department in Charge','Dept of Requester','Description 2',
#'File','Journal Entry Item','OU','PR Year','PO/OE Amount','PO/OE Date','PO/OE Price','PR Amount','PR PO Leadtime','PR/PO Balance','Payment Status',
#'Preparer','RFP Approved Date','RFP Date','RFP Number','RFP Status','Record Number','Requester',
##'Seller/Agent',
#'Source Document Date',
#'Source Document External Reference Number','Source Document Type','Supplier Plant','PO Quantity','PO Amount',
#'PO/OE Quantity', 'Calculated Net Order Value (LCU; Quantity Delivered x Unit Price)'], axis=1)
#
#cols = list(dfConsolidated)
#
#cols = [ 'UID', 'Country', 'Company', 'Month', 'Quarter', 'Year', 'Spend Type', 'Assigned Buyer', 'BU’s \r\nFactory', 'Buyer',
# 'CIC', 'Categorization UID', 'Category', 'Clean Names', 'Commodity ID', 'Company Code',
# 'Contract Number', 'Cost Center', 'Country \r\nof Origin', 'Date', 'Description 1', 'Description 1 Translated', 'Destination',
# 'Document Type', 'G/L Account', 'G/L Account Description', 'Item', 'Item Code', 'Item Type', 'Join Column Key', 'Manufacturer/Producer',
# 'Manufacturer’s \r\nFactory', 'Material Group', 'Material Group Code', 'Material Group Code 1',
# 'Material Group Description 1', 'Material Name 1', 'Material Name 2', 'Material Number', 'Material Type', 'Material Type Description',
# 'Offset G/L Account Description', 'Offset G/L Account Number', 'Plant Code', 'Plant Company Name', 'Plant Name', 'Price Unit',
# 'Purchase Organization', 'Purchase Type 1', 'Purchase Type 2', 'Purchase Type 3', 'Purchasing Document', 'Purchasing Group',
# 'Quantity', 'Specification\r\n(Material)', 'Specification\r\n(Size)', 'Specification\r\n(Thickness)', 'Specification\r\n(Weight)',
# 'Specifications\r\n (Size, Weight, \r\nDiameter)', 'Supplier Code', 'Supplier Name', 'Supplier Name Translated', 'Taxonomy L1',
# 'Taxonomy L2', 'Taxonomy L3', 'Taxonomy L4', 'Taxonomy L5', 'Unit', 'Unit Price', 'Weight', 'Spend (In EUR)', 'Spend (In GBP)',
# 'Spend (In JPY)', 'Spend (In LCC)', 'Spend (In USD)', 'Currency', 'Currency Conversion Rate(LCC vis-à-vis EUR)', 'Currency Conversion Rate(LCC vis-à-vis GBP)', 
# 'Currency Conversion Rate(LCC vis-à-vis JPY)', 'Currency Conversion Rate(LCC vis-à-vis USD)', 'Comments']
#
#
#dfConsolidated = dfConsolidated.loc[:, cols]
#    
#dfConsolidated = dfConsolidated.dropna(subset=['Spend (In LCC)'])
#dfConsolidated = dfConsolidated[dfConsolidated['Spend (In LCC)'] != 0]
#dfConsolidated = dfConsolidated[(dfConsolidated['Taxonomy L1'] != 'Intercompany') | (dfConsolidated['Taxonomy L1'] != 'Intercompany Spend')]
#dfConsolidated = dfConsolidated.drop_duplicates(subset='UID', keep="last")
##dataConversion.loc[dataConversion['Taxonomy L1'].isnull(),'Taxonomy L1'] = 'Categorisation Not Available'
##dataConversion.loc[dataConversion['Taxonomy L2'].isnull(),'Taxonomy L2'] = 'Categorisation Not Available'
##dataConversion.loc[dataConversion['Taxonomy L3'].isnull(),'Taxonomy L3'] = 'Categorisation Not Available'
##dataConversion.loc[dataConversion['Taxonomy L4'].isnull(),'Taxonomy L4'] = 'Categorisation Not Available'
#
##dfConsolidated.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Consolidated_Old.csv", sep=',', index = False)
#
##dfCategory = dfConsolidated[['UID', 'Country', 'Company', 'Month', 'Quarter', 'Year', 'Spend Type',
##                             'Taxonomy L1', 'Taxonomy L2', 'Taxonomy L3', 'Taxonomy L4', 'Taxonomy L5']]
#
##dfCategory.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Taxonomy.csv", sep=',', index = False)
#
#TaxUpdated = pd.read_excel('E:\\My Data\Suntory\\MainFilesCreation\\StandardizedColumnNames\\Consolidated Taxonomy - 4 Jan 2017 - Consolidated.xlsx', sheetname="Taxonomy_Updated")
#dataConversion = pd.merge(dfConsolidated, TaxUpdated, how = 'left', on = ['Taxonomy L1','Taxonomy L2','Taxonomy L3','Taxonomy L4'])
#
##dataConversion.loc[((dataConversion['L1_Updated']!= np.nan)) | (dataConversion['L1_Updated']!= ''), 'Taxonomy L1'] = dataConversion['L1_Updated']
##dataConversion.loc[((dataConversion['L1_Updated']!= np.nan)) | (dataConversion['L1_Updated']!= ''), 'Taxonomy L2'] = dataConversion['L2_Updated']
##dataConversion.loc[((dataConversion['L1_Updated']!= np.nan)) | (dataConversion['L1_Updated']!= ''), 'Taxonomy L3'] = dataConversion['L3_Updated']
##dataConversion.loc[((dataConversion['L1_Updated']!= np.nan)) | (dataConversion['L1_Updated']!= ''), 'Taxonomy L4'] = dataConversion['L4_Updated']
#
#
#dataConversion.loc[((dataConversion['L1_Updated'].notnull())),'Taxonomy L1'] = dataConversion['L1_Updated']
#dataConversion.loc[((dataConversion['L1_Updated'].notnull())),'Taxonomy L2'] = dataConversion['L2_Updated']
#dataConversion.loc[((dataConversion['L1_Updated'].notnull())),'Taxonomy L3'] = dataConversion['L3_Updated']
#dataConversion.loc[((dataConversion['L1_Updated'].notnull())),'Taxonomy L4'] = dataConversion['L4_Updated']
#
#dataConversion = dataConversion.drop(['L1_Updated','L2_Updated','L3_Updated','L4_Updated'], axis=1)
#
##TaxUpdated.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Z.csv", sep=',', index = False)
#
##dfConsolidated.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Consolidated.csv", sep=',', index = False)
#
#dataConversion.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Consolidated.csv", sep=',', index = False)
#
#dfCategorization = dataConversion[['Categorization UID','UID', 'Country', 'Company', 'Spend Type',
#                             'Taxonomy L1', 'Taxonomy L2', 'Taxonomy L3', 'Taxonomy L4', 'Taxonomy L5']]
#
#dfCategorization = dfCategorization.dropna(subset=['Categorization UID'])
#dfCategorization.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Taxonomy.csv", sep=',', index = False)
#
#
#dfTaxonomyUpdationStadardFile = pd.read_csv('E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Taxonomy.csv',encoding='cp1252')
#dfTaxonomyUpdationRawFile = pd.read_csv('E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\ConsolidatedTest.csv',encoding='cp1252')
#
#dataConversionFinal = pd.merge(dfTaxonomyUpdationRawFile, dfTaxonomyUpdationStadardFile, how = 'left', on = ['Categorization UID'])
#
#dataConversionFinal.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\ConsolidatedFinal.csv", sep=',', index = False)
#
#dfPivot = dataConversion.groupby(['Country' ,'Spend Type'])['Spend (In LCC)','Spend (In USD)'].sum()
#dfPivot.reset_index(inplace=True)
#dfPivot.to_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Pivot.csv", sep=',', index = False)
#
#TaxUpdateda = pd.read_excel('E:\\My Data\Suntory\\MainFilesCreation\\StandardizedColumnNames\\Consolidated Taxonomy - 26 December 2017_V2 - New.xlsx', sheetname="Taxonomy_Updated")
#dataConversiona = pd.merge(dfConsolidated, TaxUpdated, how = 'left', on = ['Taxonomy L1','Taxonomy L2','Taxonomy L3','Taxonomy L4'])
#
##Read in the csv files.
#df1 = dd.read_csv('E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\Taxonomy.csv')
#df2 = dd.read_csv("E:\\My Data\\Suntory\\MainFilesCreation\\OutPutFiles\\ConsolidatedTest.csv")
#
## Merge the csv files.
#df = dd.merge(dfTaxonomyUpdationRawFile, dfTaxonomyUpdationStadardFile, how = 'left', on = ['Categorization UID'])
#
## Write the output.
#df.to_csv('file3.csv', index=False) 
#
#del dfAustralia, dfFrucorDirect, dfFrucorIndirect, dfIndonesiaDirect, dfIndonesiaIndirect #, dfJapanDirectPM, dfJapanDirectRM
#del dfMalaysiaDirect, dfMalaysiaIndirect, dfSBFE, dfVietnamDirect, dfVietnamIndirect, dfConsolidated, dataConversion, dfPivot
#del TaxUpdated


