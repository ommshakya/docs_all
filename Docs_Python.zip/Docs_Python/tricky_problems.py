# -*- coding: utf-8 -*-
"""
Created on Thu Apr 12 11:22:42 2018

@author: OmPrakash.Shakya
"""

l=[]
for i in range(2000, 3201):
    if (i%7==0) and (i%5!=0):
        l.append(str(i))

print(','.join(l))

#--------------------------

def fact(x):
    if x == 0:
        return 1
    return x * fact(x - 1)

x = int(input())
print(fact(x))

#-------------------------

values = input()
l = values.split(",")
t = tuple(l)
print(l)
print(t)

#-------------------------

