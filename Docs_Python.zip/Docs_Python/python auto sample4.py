# -*- coding: utf-8 -*-
"""
Created on Tue Apr  3 15:11:53 2018

@author: OmPrakash.Shakya
"""

print("Hi om, Welcome to Python/R script automation!")