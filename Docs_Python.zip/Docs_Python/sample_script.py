# -*- coding: utf-8 -*-
"""
Created on Tue Apr  3 14:40:41 2018

@author: OmPrakash.Shakya
"""
import os
import pandas as pd
import numpy as np

#print("Hi om, Welcome to Rython/R script automation!")


#Set the current working directories
print("Existing current direcory: " + os.getcwd())
os.chdir('D:\z.Oms\Learn.Python\Iris')
print("Existing current direcory: " + os.getcwd())

#List all the files of current working directory
for file in os.listdir(os.getcwd()):
    print(file)

#Read the 'iris-data.csv' file
iris_data = pd.read_csv('iris-data.csv')

################ check missing values ################
# check if the dataframe has any missing values
iris_data.isnull().values.any()

# check there are how many rows that have missing values per column
iris_data.isnull().sum()

# total number of missing values
iris_data.isnull().sum().sum()

# get the columns which has missing values
null_columns = iris_data.columns[iris_data.isnull().any()]
for col in null_columns:
    print(col)