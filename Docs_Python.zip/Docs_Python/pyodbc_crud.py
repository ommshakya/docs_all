# -*- coding: utf-8 -*-
"""
Created on Tue Mar  6 09:01:22 2018

@author: OmPrakash.Shakya
"""
###########################
Using an ODBC driver
There are actually many SQL Server ODBC drivers written and distributed by Microsoft:

{SQL Server} - released with SQL Server 2000
{SQL Native Client} - released with SQL Server 2005 (also known as version 9.0)
{SQL Server Native Client 10.0} - released with SQL Server 2008
{SQL Server Native Client 11.0} - released with SQL Server 2012
{ODBC Driver 11 for SQL Server} - supports SQL Server 2005 through 2014
{ODBC Driver 13 for SQL Server} - supports SQL Server 2005 through 2016
###########################

###############SELECT################
#Import pyodbc module using below command
import pyodbc as db
 
#Create connection string to connect DBTest database with windows authentication
con = db.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=.;Trusted_Connection=yes;DATABASE=DBTest')
cur = con.cursor()
 
#SELECT all rows from employee table
qry = 'SELECT EmpName, CommaSepSkills FROM dbo.tbl_EmpMaster'
cur.execute(qry)
 
row = cur.fetchone() #Fetch first row
while row: #Fetch all rows using a while loop
    print(row)
    row = cur.fetchone()
cur.close() #Close the cursor and connection objects
con.close()
###############INSERT################
#Import pyodbc module using below command
import pyodbc as db
 
#Create connection string to connect DBTest database with windows authentication
con = db.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=.;Trusted_Connection=yes;DATABASE=DBTest')
cur = con.cursor()
 
#SELECT all rows from employee table
qry = '''INSERT INTO dbo.tbl_EmpMaster
        (EmpName, CommaSepSkills)
        VALUES(?, ?)
        '''
param_values = ['Mark', 'SQL,BigData,Spark,Azure']
cur.execute(qry, param_values)
 
print('{0} row inserted successfully.'.format(cur.rowcount))
 
cur.commit() #Use this to commit the insert operation
cur.close()
con.close()
###############UPDATE################
#Import pyodbc module using below command
import pyodbc as db
 
#Create connection string to connect DBTest database with windows authentication
con = db.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=.;Trusted_Connection=yes;DATABASE=DBTest')
cur = con.cursor()
 
#SELECT all rows from employee table
qry = '''UPDATE dbo.tbl_EmpMaster
        SET CommaSepSkills = ?
        WHERE EmpName = ?
        '''
param_values = ['Hadoop,Spark,BigData,SQL,Azure', 'Mark']
cur.execute(qry, param_values)
 
print('{0} row updated successfully.'.format(cur.rowcount))
 
cur.commit() #Use this to commit the update operation
cur.close()
con.close()
###############DELETE################
#Import pyodbc module using below command
import pyodbc as db
 
#Create connection string to connect DBTest database with windows authentication
con = db.connect('DRIVER={ODBC Driver 13 for SQL Server};SERVER=.;Trusted_Connection=yes;DATABASE=DBTest')
cur = con.cursor()
 
#SELECT all rows from employee table
qry = '''DELETE tbl_EmpMaster
        WHERE EmpName = ?
        '''
param_values = ['Mark']
cur.execute(qry, param_values)
 
print('{0} row deleted successfully.'.format(cur.rowcount))
 
cur.commit() #Use this to commit the delete operation
cur.close()
con.close()
