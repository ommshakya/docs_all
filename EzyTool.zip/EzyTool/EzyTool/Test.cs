﻿using EzyTool.ConstantObjectsEz;
using EzyTool.Services;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EzyTool
{
    public partial class Test : Form
    {
        public Test()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {


            comboBox1.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.Cases, null);
            comboBox1.DisplayMember = "Key";
            comboBox1.ValueMember = "Value";

            DataTable dtColumnList = new DataTable();
            dtColumnList.Columns.Add("ColumnNum", typeof(int));
            dtColumnList.Columns.Add("ExistingColumnName", typeof(string));

            dtColumnList.Rows.Add(1, "Col1");
            dtColumnList.Rows.Add(2, "Col2");

            dataGridView1.DataSource = DataTableHelperEz.GenerateListToChangeCases(dtColumnList);

            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.HeaderText = "ChooseCase";
            comboBoxColumn.Name = "cmbBoxChooseCase";
            comboBoxColumn.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.Cases, null);
            comboBoxColumn.DisplayMember = "Key";
            comboBoxColumn.ValueMember = "Value";
            comboBoxColumn.Width = 100;
            //comboBoxColumn.FlatStyle = FlatStyle.Flat;
            //comboBoxColumn.DisplayStyle = DataGridViewComboBoxDisplayStyle.ComboBox;


            dataGridView1.Columns.Insert(2, comboBoxColumn);



        }
        ComboBox combo;
        private void dataGridView1_EditingControlShowing(object sender, DataGridViewEditingControlShowingEventArgs e)
        {
            //var editingControl = dataGridView1.EditingControl as DataGridViewComboBoxEditingControl;
            //if (editingControl != null)
            //{
            //    //editingControl.DropDownStyle = ComboBoxStyle.DropDownList;
            //    editingControl.DroppedDown = true;
            //    editingControl.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);
            //    editingControl.SelectedIndexChanged += combo_SelectedIndexChanged;
            //}
            combo = e.Control as ComboBox;
            if (combo != null)
            {
                combo.DropDownStyle = ComboBoxStyle.DropDownList;

                combo.SelectedIndexChanged -= new EventHandler(combo_SelectedIndexChanged);
                combo.SelectedIndexChanged += combo_SelectedIndexChanged;
            }
        }
        private void combo_SelectedIndexChanged(object sender, EventArgs e)
        {
            string selected = (sender as ComboBox).SelectedItem.ToString();
            MessageBox.Show("selected: " + selected);
        }
    }
}
