﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.ConstantObjectsEz
{
    
    public static class ConstantObjectsEz
    {
        public static Dictionary<string, string> Cases = new Dictionary<string, string>
        {
            {"Choose case", "ChooseCase"},
            {"Lower case", "LowerCase"},
            {"Upper case", "UpperCase"},
            {"Proper case", "ProperCase"}
        };
        public static Dictionary<string, string> HeaderCases = new Dictionary<string, string>
        {
            {"Choose case", "ChooseCase"},
            {"Lower case", "LowerCase"},
            {"Upper case", "UpperCase"}
        };
        public static Dictionary<string, string> DateFormats = new Dictionary<string, string>
        {
            {"Choose date format", "ChooseDateFormat"},
            {"yyyy-mm-dd", "yyyy-mm-dd"},
            {"mm-dd-yyyy", "mm-dd-yyyy"},
            {"dd-mm-yyyy", "dd-mm-yyyy"}
        };
        public static Dictionary<string, string> DataExportFileTypes = new Dictionary<string, string>
        {
            {"Choose file type", "ChooseFileType"},
            {"Csv", "Csv"},
            {"Excel", "Excel"},
            {"Both", "Both"}
        };
    }
}