﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Configuration;
using System.Data.SqlClient;
using System.IO;
using System.Data.OleDb;
using EzyTool.Formatting;
using EzyTool.Services;
using EzyTool.ConstantObjectsEz;
using System.Threading;

namespace EzyTool
{
    public partial class frmMain : Form
    {
        //http://csharp-station.com/Tutorial/AdoDotNet/Lesson03
        //Split Column
        //New Column
        //Enter 'Rename column name' if you wish to change the name of column otherwise leave it blank.

        public int TopRecordsCount = 200;
        public DataTable dtRawData;
        public DataTable dtSourceData;
        public string fileNameRawData = string.Empty;
        public string tableNameRawData = string.Empty;
        public string tableNameSourceData = string.Empty;
        bool isSourceColumnProcessed = false;
        ImageList imageList1;
        public frmMain()
        {
            InitializeComponent();

            EnableDisableAllTabPages(false);
            chkBoxEnableSourceColumnsTab.Visible = false;
            SetSelectedTabPage(tabPageSourceColumns);

            //// initialize the imagelist
            //ImageList imageList1 = new ImageList();
            //imageList1.Images.Add("key1", Image.FromFile("Images/Image_1.png"));
            //imageList1.Images.Add("key2", Image.FromFile("Images/Image_2.png"));

            //tabControl.ImageList = imageList1;
            ////tabPageSourceColumns.ImageIndex = 1;
            PopulateDataExportCombobox();

            //Image image = Image.FromFile("Images/Image_1.png");
            //pictureBox1.Image = imageList1.Images[1];
            ////pictureBox1.Image = image;
            //pictureBox1.Width = 20;
            //pictureBox1.Height = 20;
            //pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            //LoadStepsDone();



            imageList1 = new ImageList();
            imageList1.Images.Add("img1", Image.FromFile("Images/Image_1.png"));
            imageList1.Images.Add("img2", Image.FromFile("Images/Image_2.png"));
            LoadStepsDone();
            lblDimension.Text = string.Empty;


        }

        private void PopulateDataExportCombobox()
        {
            comboBoxDataExportFileType.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.DataExportFileTypes, null);
            comboBoxDataExportFileType.DisplayMember = "Key";
            comboBoxDataExportFileType.ValueMember = "Value";
            comboBoxDataExportFileType.SelectedIndex = 0;
        }

        internal delegate void SetSelectedTabPageDelegate(TabPage tabPage);
        private void SetSelectedTabPage(TabPage tabPage)
        {
            this.tabControl.SelectedTab = tabPage;
        }
        private void ResetPublicVariables()
        {
            dtRawData = null;
            dtSourceData = null;
            fileNameRawData = string.Empty;
            tableNameRawData = string.Empty;
            tableNameSourceData = string.Empty;
            isSourceColumnProcessed = false;
            chkBoxSourceColumnsSelectAll.Checked = false;
            chkBoxChoosecaseSelectAll.Checked = false;
            chkBoxRemoveWhiteSpacesSelectAll.Checked = false;
            lblDimension.Text = string.Empty;
        }
        internal delegate void EnableDisableAllTabPagesDelegate(bool b);
        private void EnableDisableAllTabPages(bool isEnabled)
        {
            foreach (Control t in tabControl.TabPages)
            {
                t.Enabled = isEnabled;
                //t.Visible = isEnabled;
            }
        }
        internal delegate void EnableDisableTabPageDelegate(string s, bool b);
        private void EnableDisableTabPage(string TabPageName, bool isEnable)
        {
            foreach (Control t in tabControl.TabPages)
            {
                if (t.Name.Equals(TabPageName))
                {
                    t.Enabled = isEnable;
                    //t.Visible = isEnable;
                    t.Focus();
                }
            }
        }
        private void ClearDataGridViews(DataGridView dataGridView)
        {
                dataGridView.DataSource = null;
                dataGridView.Rows.Clear();
                dataGridView.Columns.Clear();
        }
        private void ShowDataInOtherForm()
        {
            //frmPreviewData form2 = new frmPreviewData();
            Form2 form2 = new Form2();
            if (!isSourceColumnProcessed)
                form2.tabControl1.SelectedTab = form2.tabPageRawData;
            else
                form2.tabControl1.SelectedTab = form2.tabPageFinalData;

            if (dtRawData != null)
            {
                DataView dataView = GetRaDataDataView();
                form2.dgvShowDetails.DataSource = dataView;
                //GriviewFormattingEz.FormatCsvGridView(form2.dgvShowDetails);
                //form2.dgvShowDetails.Height = 388;
                form2.dgvShowDetails.Columns[0].Visible = false;
            }
            if (dtSourceData != null)
            {
                form2.dgvFinalData.DataSource = dtSourceData;
                //GriviewFormattingEz.FormatCsvGridView(form2.dgvSourceData);
                //form2.dgvSourceData.Height = 388;
            }
            form2.ShowDialog();
        }

        private DataView GetRaDataDataView()
        {
            return new DataView(dtRawData.AsEnumerable().Take(TopRecordsCount).CopyToDataTable());
            //table.AsEnumerable().Reverse().Take(TopRecordsCount).CopyToDataTable(); // bottom n rows
        }

        private void LoadStepsDone()
        {
            dgvStepsDone.AllowUserToResizeColumns = false;
            dgvStepsDone.ReadOnly = true;

            dgvStepsDone.Columns[0].Width = 22;
            dgvStepsDone.Columns[0].DefaultCellStyle.BackColor = Color.White;
            //dgvStepsDone.Columns[1].Width = 0;
            dgvStepsDone.Columns[0].Resizable = DataGridViewTriState.False;
            //dgvStepsDone.Columns[1].Resizable = DataGridViewTriState.False;
        }
        private void AddStepDone(string stepDescription)
        {
            dgvStepsDone.Rows.Add(imageList1.Images[1], stepDescription);
        }
        private void ClearStepsDone()
        {
            dgvStepsDone.Rows.Clear();
        }
        internal delegate void PopulateGridWithDataTableDelegate(DataTable table);
        private void PopulateDataGridFirstTime(DataTable table)
        {
            // Invoke method if required:
            if (this.InvokeRequired)
            {
                this.Invoke(new PopulateGridWithDataTableDelegate(PopulateDataGridFirstTime), table);
            }
            else
            {
                ClearDataGridViews(dgvShowDetails);
                DataView dataView = GetRaDataDataView();
                DateTime dtStart = DateTime.Now;
                dgvShowDetails.DataSource = dataView;

                DateTime dtEnd = DateTime.Now;
                //GriviewFormattingEz.FormatCsvGridView(dgvShowDetails);
                //dgvShowDetails.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(dgvShowDetails_RowPostPaint);
                //dgvShowDetails.Columns[0].Visible = false;
                dgvShowDetails.Columns[0].HeaderText = string.Empty;
                dgvShowDetails.AllowUserToOrderColumns = false;
                dgvShowDetails.AllowUserToAddRows = false;
                foreach (DataGridViewColumn dgvc in dgvShowDetails.Columns)
                {
                    dgvc.SortMode = DataGridViewColumnSortMode.NotSortable;
                }


                DateTime dtEnd2 = DateTime.Now;
                progressBar.Visible = false;

                TimeSpan difference1 = dtEnd.Subtract(dtStart);
                TimeSpan difference2 = dtEnd2.Subtract(dtStart);
                //MessageBox.Show("Total sec: "+ difference1.TotalSeconds.ToString() + " Total sec: " + difference2.TotalSeconds.ToString());
            }
        }
        private void PopulateDataGridNextTime()
        {
            ClearDataGridViews(dgvShowDetails);
                dgvShowDetails.DataSource = dtSourceData;
            //GriviewFormattingEz.FormatCsvGridView(dgvShowDetails);
            //dgvShowDetails.Height = 58;
            //dgvShowDetails.RowPostPaint += new System.Windows.Forms.DataGridViewRowPostPaintEventHandler(dgvShowDetails_RowPostPaint);
            //dgvShowDetails.Columns[0].Visible = false;
            dgvShowDetails.Columns[0].HeaderText = string.Empty;
            dgvShowDetails.AllowUserToOrderColumns = false;
            dgvShowDetails.AllowUserToAddRows = false;
            foreach (DataGridViewColumn dgvc in dgvShowDetails.Columns)
            {
                dgvc.SortMode = DataGridViewColumnSortMode.NotSortable;
            }
        }
        private void PopulateSourceColumnsGrid(DataTable dt)
        {
            ClearDataGridViews(dgvSOurceColumns);
            dgvSOurceColumns.DataSource = DataTableHelperEz.GenerateListToSourceColumns(dt);
            GriviewFormattingEz.FormatGridView(dgvSOurceColumns);

            #region bind control
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "SelectColumn";
            checkBoxColumn.Name = "chkBoxSelectSourceColumn";
            checkBoxColumn.FlatStyle = FlatStyle.Standard;
            checkBoxColumn.ThreeState = false;
            dgvSOurceColumns.Columns.Insert(1, checkBoxColumn);
            #endregion

            foreach (DataGridViewColumn column in dgvSOurceColumns.Columns)
            {
                if (column.HeaderText.Equals("ColumnIndex"))
                {
                    column.DisplayIndex = 0;
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    column.HeaderText = HeaderTextSourceColumnsGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("SelectColumn"))
                {
                    column.DisplayIndex = 1;
                    column.Width = 30;
                    column.ReadOnly = false;
                    column.HeaderText = HeaderTextSourceColumnsGridEz.SelectColumn;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnName"))
                {
                    column.DisplayIndex = 2;
                    column.ReadOnly = true;
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    column.HeaderText = HeaderTextSourceColumnsGridEz.ExistingColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
            }

            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvSOurceColumns, chkBoxSourceColumnsSelectAll, "chkBoxSelectSourceColumn", tabPageSourceColumns, dgvSOurceColumns);

            //Set some required properties of the grid
            dgvSOurceColumns.AllowUserToResizeColumns = false;
            dgvSOurceColumns.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvSOurceColumns.ColumnHeadersHeight = 25;

            
        }
        private void PopulateRenameColumnsGrid(DataTable dt)
        {
            ClearDataGridViews(dgvRenameColumns);
            dgvRenameColumns.DataSource = DataTableHelperEz.GenerateListToRenameColumns(dt);
            GriviewFormattingEz.FormatGridView(dgvRenameColumns);

            foreach (DataGridViewColumn column in dgvRenameColumns.Columns)
            {
                if (column.HeaderText.Equals("ColumnIndex"))
                {
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    column.HeaderText = HeaderTextRenameColumnNamesGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnName"))
                {
                    column.Width = 340;
                    column.ReadOnly = true;

                    column.HeaderText = HeaderTextRenameColumnNamesGridEz.ExistingColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("RenameColumnName"))
                {
                    column.ReadOnly = false;
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    column.HeaderText = HeaderTextRenameColumnNamesGridEz.RenameColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                    
                    column.ToolTipText = "Enter \'Rename column name\' if you wish to change the name of column otherwise leave it blank.";
                }
            }
            //Set some required properties of the grid
            dgvRenameColumns.AllowUserToResizeColumns = false;
            dgvRenameColumns.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            dgvRenameColumns.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dgvRenameColumns_CellMouseEnter);
            dgvRenameColumns.CellMouseLeave += new System.Windows.Forms.DataGridViewCellEventHandler(dgvRenameColumns_CellMouseLeave);
        }
        private void PopulateChangeCaseGrid(DataTable dt)
        {
            ClearDataGridViews(dgvChangeCases);
            dgvChangeCases.DataSource = DataTableHelperEz.GenerateListToChangeCases(dt);

            //dgvChangeCases.Refresh();
            GriviewFormattingEz.FormatGridView(dgvChangeCases);

            #region bind control
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "SelectColumn";
            checkBoxColumn.Name = "chkBoxSelectChangeCase";
            checkBoxColumn.FlatStyle = FlatStyle.Standard;
            checkBoxColumn.ThreeState = false;
            dgvChangeCases.Columns.Insert(1, checkBoxColumn);

            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.HeaderText = "ChooseCase";
            comboBoxColumn.Name = "cmbBoxChooseCase";
            comboBoxColumn.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.Cases, null);
            comboBoxColumn.DisplayMember = "Key";
            comboBoxColumn.ValueMember = "Value";
            comboBoxColumn.Width = 100;
            comboBoxColumn.FlatStyle = FlatStyle.Flat;
            comboBoxColumn.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
            dgvChangeCases.Columns.Insert(3, comboBoxColumn);

            #endregion
            foreach (DataGridViewColumn column in dgvChangeCases.Columns)
            {
                if (column.HeaderText.Equals("ColumnNum"))
                {
                    //column.DisplayIndex = 0;
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    column.HeaderText = HeaderTextChangeCaseGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("SelectColumn"))
                {
                    //column.DisplayIndex = 1;
                    column.Width = 30;
                    column.ReadOnly = false;
                    column.HeaderText = HeaderTextChangeCaseGridEz.SelectColumn;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnName"))
                {
                    //column.DisplayIndex = 2;
                    column.ReadOnly = true;
                    column.Width = 515;

                    column.HeaderText = HeaderTextChangeCaseGridEz.ExistingColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ChooseCase"))
                {
                    //column.DisplayIndex = 3;
                    column.ReadOnly = false;
                    column.DefaultCellStyle.Format.ToUpper();
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    column.HeaderText = HeaderTextChangeCaseGridEz.ChooseCase;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
            }

            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvChangeCases, chkBoxChoosecaseSelectAll, "chkBoxSelectChangeCase", tabPageChangeCases, dgvChangeCases);
            chkBoxChoosecaseSelectAll.FlatStyle = FlatStyle.Standard;

            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvChangeCases, cmbBoxChoosecaseSelectAll, "cmbBoxChooseCase", tabPageChangeCases, dgvChangeCases);
            cmbBoxChoosecaseSelectAll.BackColor = Color.LightGray;
            cmbBoxChoosecaseSelectAll.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbBoxChoosecaseSelectAll.DrawMode = DrawMode.Normal;
            cmbBoxChoosecaseSelectAll.FlatStyle = FlatStyle.Flat;

            cmbBoxChoosecaseSelectAll.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.Cases, null);
            cmbBoxChoosecaseSelectAll.DisplayMember = "Key";
            cmbBoxChoosecaseSelectAll.ValueMember = "Value";
            cmbBoxChoosecaseSelectAll.SelectedIndex = 0;

            //Set some required properties of the grid
            dgvChangeCases.AllowUserToResizeColumns = false;
            dgvChangeCases.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            BindDefaultDgvChangeCases();

            // Add the events to listen for
            dgvChangeCases.CellValueChanged += new DataGridViewCellEventHandler(dgvChangeCases_CellValueChanged);
            dgvChangeCases.CurrentCellDirtyStateChanged += new EventHandler(dgvChangeCases_CurrentCellDirtyStateChanged);
        }
        private void PopulateChangeDateFormatGrid(DataTable dt)
        {
            ClearDataGridViews(dgvChangeDateFormat);
            dgvChangeDateFormat.DataSource = DataTableHelperEz.GenerateListToChangeDateFormat(dt);
            GriviewFormattingEz.FormatGridView(dgvChangeDateFormat);

            #region bind control
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "SelectColumn";
            checkBoxColumn.Name = "chkBoxSelectChangeDateFormat";
            checkBoxColumn.FlatStyle = FlatStyle.Standard;
            checkBoxColumn.ThreeState = false;
            dgvChangeDateFormat.Columns.Insert(1, checkBoxColumn);


            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.HeaderText = "ChooseDateFormat";
            comboBoxColumn.Name = "cmbBoxChooseDateFormat";
            comboBoxColumn.FlatStyle = FlatStyle.Flat;
            comboBoxColumn.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;

            comboBoxColumn.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.DateFormats, null);
            comboBoxColumn.DisplayMember = "Key";
            comboBoxColumn.ValueMember = "Value";
            dgvChangeDateFormat.Columns.Insert(3, comboBoxColumn);
            #endregion
            foreach (DataGridViewColumn column in dgvChangeDateFormat.Columns)
            {
                if (column.HeaderText.Equals("ColumnNum"))
                {
                    //column.DisplayIndex = 0;
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    column.HeaderText = HeaderTextChangeCaseGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("SelectColumn"))
                {
                    //column.DisplayIndex = 1;
                    column.Width = 30;
                    column.ReadOnly = false;
                    column.HeaderText = HeaderTextChangeCaseGridEz.SelectColumn;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnName"))
                {
                    //column.DisplayIndex = 2;
                    column.ReadOnly = true;
                    column.Width = 495;

                    column.HeaderText = HeaderTextChangeCaseGridEz.ExistingColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ChooseDateFormat"))
                {
                    //column.DisplayIndex = 3;
                    column.ReadOnly = false;
                    column.DefaultCellStyle.Format.ToUpper();
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    column.HeaderText = HeaderTextChangeDateFormatGridEz.ChooseDateFormat;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
            }


            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvChangeDateFormat, chkBoxChooseDateFormatSelectAll, "chkBoxSelectChangeDateFormat", tabPageChangeDateFormat, dgvChangeDateFormat);

            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvChangeDateFormat, cmbBoxChooseDateFormatSelectAll, "cmbBoxChooseDateFormat", tabPageChangeDateFormat, dgvChangeDateFormat);

            cmbBoxChooseDateFormatSelectAll.BackColor = Color.LightGray;
            cmbBoxChooseDateFormatSelectAll.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbBoxChooseDateFormatSelectAll.DrawMode = DrawMode.Normal;
            cmbBoxChooseDateFormatSelectAll.FlatStyle = FlatStyle.Flat;

            cmbBoxChooseDateFormatSelectAll.DataSource = new BindingSource(ConstantObjectsEz.ConstantObjectsEz.DateFormats, null);
            cmbBoxChooseDateFormatSelectAll.DisplayMember = "Key";
            cmbBoxChooseDateFormatSelectAll.ValueMember = "Value";
            cmbBoxChooseDateFormatSelectAll.SelectedIndex = 0;

            //Set some required properties of the grid
            dgvChangeDateFormat.AllowUserToResizeColumns = false;
            dgvChangeDateFormat.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;

            // Add the events to listen for
            dgvChangeDateFormat.CellValueChanged += new DataGridViewCellEventHandler(dgvChangeDateFormat_CellValueChanged);
            dgvChangeDateFormat.CurrentCellDirtyStateChanged += new EventHandler(dgvChangeDateFormat_CurrentCellDirtyStateChanged);

            BindDefaultDgvChangeDateFormat();
        }
        private void PopulateReplaceValuesGrid(DataTable dt)
        {

            SetSelectedTabPage(tabPageReplaceValues);

            ClearDataGridViews(dgvReplaceValue);
            dgvReplaceValue.DataSource = DataTableHelperEz.GenerateListToReplaceValues();// dt);
            GriviewFormattingEz.FormatGridView(dgvReplaceValue);


            #region bind control
            //DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            //checkBoxColumn.HeaderText = HeaderTextChangeDateFormatGridEz.SelectColumn;
            //checkBoxColumn.Name = "chbPass";
            //checkBoxColumn.FlatStyle = FlatStyle.Standard;
            //checkBoxColumn.ThreeState = false;
            //dgvChangeDateFormat.Columns.Add(checkBoxColumn);

            DataGridViewComboBoxColumn comboBoxColumn = new DataGridViewComboBoxColumn();
            comboBoxColumn.HeaderText = "SelectColumn";// HeaderTextReplaceValueGridEz.SelectColumn;//.ChooseCase;
            comboBoxColumn.Name = "comboBoxReplaceValueSelectColumn";
            comboBoxColumn.FlatStyle = FlatStyle.Flat;
            comboBoxColumn.DisplayStyle = DataGridViewComboBoxDisplayStyle.DropDownButton;
            dgvReplaceValue.Columns.Insert(1, comboBoxColumn);
            #endregion
            foreach (DataGridViewColumn column in dgvReplaceValue.Columns)
            {
                if (column.HeaderText.Equals("ColumnNum"))
                {
                    //column.DisplayIndex = 0;
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.Visible = true;

                    column.HeaderText = HeaderTextReplaceValueGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("SelectColumn"))
                {
                    //column.DisplayIndex = 1;
                    //column.Width = 350;
                    column.ReadOnly = false;
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;
                    column.HeaderText = HeaderTextReplaceValueGridEz.SelectColumn;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnValue"))
                {
                    //column.DisplayIndex = 2;
                    column.Width = 200;
                    column.ReadOnly = false;

                    column.HeaderText = HeaderTextReplaceValueGridEz.ExistingColumnValue;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ReplaceByValue"))
                {
                    //column.DisplayIndex = 3;
                    column.Width = 200;
                    column.ReadOnly = false;
                    column.HeaderText = HeaderTextReplaceValueGridEz.ReplaceByValue;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
            }

            dgvReplaceValue.ReadOnly = false;
            dgvReplaceValue.AllowUserToAddRows = !GriviewFormattingEz.AllowUserToAddRows;

            dgvReplaceValue.AllowUserToResizeColumns = false;
            dgvReplaceValue.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvReplaceValue.ColumnHeadersHeight = 25;

            dgvReplaceValue.RowPostPaint += new DataGridViewRowPostPaintEventHandler(dgvReplaceValue_RowPostPaint);
            dgvReplaceValue.CellMouseEnter += new System.Windows.Forms.DataGridViewCellEventHandler(dgvReplaceValue_CellMouseEnter);
            dgvReplaceValue.CellMouseLeave += new System.Windows.Forms.DataGridViewCellEventHandler(dgvReplaceValue_CellMouseLeave);

            BindDefaultDgvReplaceValuesFormat();
        }
        private void PopulateRemoveWhiteSpacesGrid(DataTable dt)
        {
            ClearDataGridViews(dgvRemoveWhiteSpaces);
            dgvRemoveWhiteSpaces.DataSource = DataTableHelperEz.GenerateListToRemoveWhiteSpaces(dt);
            GriviewFormattingEz.FormatGridView(dgvRemoveWhiteSpaces);

            #region bind control
            DataGridViewCheckBoxColumn checkBoxColumn = new DataGridViewCheckBoxColumn();
            checkBoxColumn.HeaderText = "SelectColumn";
            checkBoxColumn.Name = "chkBoxSelectRemoveWhiteSpacesColumn";
            checkBoxColumn.FlatStyle = FlatStyle.Standard;
            checkBoxColumn.ThreeState = false;
            dgvRemoveWhiteSpaces.Columns.Insert(1, checkBoxColumn);
            #endregion

            foreach (DataGridViewColumn column in dgvRemoveWhiteSpaces.Columns)
            {
                if (column.HeaderText.Equals("ColumnIndex"))
                {
                    //column.DisplayIndex = 0;
                    column.Width = 35;
                    column.ReadOnly = true;
                    column.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;

                    column.HeaderText = HeaderTextRemoveWhiteSpacesGridEz.ColumnIndex;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("SelectColumn"))
                {
                    //column.DisplayIndex = 1;
                    column.Width = 30;
                    column.ReadOnly = false;
                    column.HeaderText = HeaderTextRemoveWhiteSpacesGridEz.SelectColumn;

                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
                if (column.HeaderText.Equals("ExistingColumnName"))
                {
                    //column.DisplayIndex = 2;
                    column.ReadOnly = true;
                    column.AutoSizeMode = DataGridViewAutoSizeColumnMode.Fill;

                    column.HeaderText = HeaderTextRemoveWhiteSpacesGridEz.ExistingColumnName;
                    GriviewFormattingEz.FormatGridViewCustomColumn(column);
                }
            }

            //Place the chkBoxSourceColumnsSelectAll checkbox in the header of the grid
            SetLocationSizeOfControl(dgvRemoveWhiteSpaces, chkBoxRemoveWhiteSpacesSelectAll, "chkBoxSelectRemoveWhiteSpacesColumn", tabPageRemoveWhiteSpaces, dgvRemoveWhiteSpaces);

            //Set some required properties of the grid
            dgvRemoveWhiteSpaces.AllowUserToResizeColumns = false;
            dgvRemoveWhiteSpaces.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgvRemoveWhiteSpaces.ColumnHeadersHeight = 25;
        }

        private DataTable GetSelectedSourceColumnsFromGrid()
        {
            DataTable dtSelectedSourceColumns;
            dtSelectedSourceColumns = new DataTable();
            dtSelectedSourceColumns.Columns.Add("ColumnName", typeof(string));

            foreach (DataGridViewRow dgvr in dgvSOurceColumns.Rows)
            {
                object obj = dgvr.Cells["chkBoxSelectSourceColumn"].Value;
                if (obj != null)
                {
                    bool isSelected = (bool)obj;
                    object existingColumnNameValue = dgvr.Cells["ExistingColumnName"].Value;
                    string columnName = existingColumnNameValue != null ? existingColumnNameValue.ToString().Trim() : string.Empty;

                    if (isSelected)
                    {
                        dtSelectedSourceColumns.Rows.Add(columnName);
                    }
                }
            }
            return dtSelectedSourceColumns;
        }
        private DataTable GetRenameColumnNamesFromGrid()
        {
            DataTable dtRenameColumnNames;
            dtRenameColumnNames = new DataTable();
            dtRenameColumnNames.Columns.Add("ExistingColumnName", typeof(string));
            dtRenameColumnNames.Columns.Add("RenameColumnName", typeof(string));

            string headerCase = GetColumnHeaderCaseFromRadioButtons();
            foreach (DataGridViewRow dgvr in dgvRenameColumns.Rows)
            {
                object existingColumnNameValue = dgvr.Cells["ExistingColumnName"].Value;
                object renameColumnNameValue = dgvr.Cells["RenameColumnName"].Value;

                if (existingColumnNameValue != null && renameColumnNameValue != null)
                {
                    string existingColumnName = existingColumnNameValue.ToString().Trim();
                    string renameColumnName = renameColumnNameValue.ToString().Trim();
                    renameColumnName = string.IsNullOrEmpty(renameColumnName) ? existingColumnName : renameColumnName;

                    if (!string.IsNullOrEmpty(headerCase))
                    {
                        if (headerCase.Equals("UpperCase"))
                            renameColumnName = renameColumnName.ToUpper();
                        if (headerCase.Equals("LowerCase"))
                            renameColumnName = renameColumnName.ToLower();
                    }

                    dtRenameColumnNames.Rows.Add(existingColumnName, renameColumnName);
                }
            }
            return dtRenameColumnNames;
        }
        private DataTable GetChangeCasesFromGrid()
        {
            DataTable dtChangeCases;
            //try
            //{
                dtChangeCases = new DataTable();
                dtChangeCases.Columns.Add("ColumnName", typeof(string));
                dtChangeCases.Columns.Add("ChoosenCase", typeof(string));

                foreach (DataGridViewRow dgvr in dgvChangeCases.Rows)
                {
                    object chkBoxSelectChangeCaseValue = dgvr.Cells["chkBoxSelectChangeCase"].Value;
                    object existingColumnNameValue = dgvr.Cells["ExistingColumnName"].Value;
                    object cmbBoxChooseCaseValue = dgvr.Cells["cmbBoxChooseCase"].Value;

                    if (chkBoxSelectChangeCaseValue != null)
                    {
                        bool isSelected = (bool)chkBoxSelectChangeCaseValue;

                        string existingColumnName = existingColumnNameValue != null ? existingColumnNameValue.ToString().Trim() : string.Empty;// dgvr.Cells["ExistingColumnName"].Value.ToString().Trim();
                        string choosenCase = cmbBoxChooseCaseValue != null ? cmbBoxChooseCaseValue.ToString().Trim() : string.Empty;

                        if (isSelected)
                        {
                            dtChangeCases.Rows.Add(existingColumnName, choosenCase);
                        }
                    }
                }
                return dtChangeCases;
            //}
            //catch { return null; }
        }
        private DataTable GetChangeDateFormatsFromGrid() // TO BE IMPLEMENTED
        {
            DataTable dtChangeDateFormats;
            //try
            //{
                dtChangeDateFormats = new DataTable();
                dtChangeDateFormats.Columns.Add("ColumnName", typeof(string));
                dtChangeDateFormats.Columns.Add("ChoosenDateFormat", typeof(string));

                foreach (DataGridViewRow dgvr in dgvChangeCases.Rows)
                {
                    object chkBoxSelectChangeDateFormatValue = dgvr.Cells["chkBoxSelectChangeDateFormat"].Value;
                    object existingColumnNameValue = dgvr.Cells["ExistingColumnName"].Value;
                    object cmbBoxChooseDateFormatValue = dgvr.Cells["cmbBoxChooseDateFormat"].Value;

                    if (chkBoxSelectChangeDateFormatValue != null)
                    {
                        bool isSelected = (bool)chkBoxSelectChangeDateFormatValue;

                        string existingColumnName = existingColumnNameValue != null ? existingColumnNameValue.ToString().Trim() : string.Empty;
                        string choosenDateFormat = cmbBoxChooseDateFormatValue != null ? cmbBoxChooseDateFormatValue.ToString().Trim() : string.Empty;

                        if (isSelected)
                        {
                            dtChangeDateFormats.Rows.Add(existingColumnName, choosenDateFormat);
                        }
                    }
                }
                return dtChangeDateFormats;
            //}
            //catch { return null; }
        }
        private DataTable GetReplaceValuesFromGrid()
        {
            DataTable dtReplaceValues = null;
            //try
            //{
                dtReplaceValues = new DataTable();
                dtReplaceValues.Columns.Add("ColumnName", typeof(string));
                dtReplaceValues.Columns.Add("ExistingValue", typeof(string));
                dtReplaceValues.Columns.Add("ReplaceByValue", typeof(string));

                foreach (DataGridViewRow dgvr in dgvReplaceValue.Rows)
                {
                    if (dgvr.Cells["comboBoxReplaceValueSelectColumn"].Value != null)
                    {
                        object colName = dgvr.Cells["comboBoxReplaceValueSelectColumn"].Value;
                        object existingColValue = dgvr.Cells["ExistingColumnValue"].Value;
                        object replaceByValue = dgvr.Cells["ReplaceByValue"].Value;

                        if (colName != null)
                            colName = colName.ToString().Trim();
                        if (existingColValue != null)
                            existingColValue = existingColValue.ToString().Trim();
                        if (replaceByValue != null)
                            replaceByValue = replaceByValue.ToString().Trim();

                        if (!string.IsNullOrEmpty(colName.ToString()) && !colName.Equals("SelectColumn") && !string.IsNullOrEmpty(existingColValue.ToString()))
                        {
                            dtReplaceValues.Rows.Add(colName, existingColValue, replaceByValue);
                        }
                    }
                }
                return dtReplaceValues;
            //}
            //catch(Exception ex) { return null; }
        }
        private DataTable GetRemoveWhiteSpacesColumnsFromGrid()
        {
            DataTable dtRemoveWhiteSpacesColumns;
            dtRemoveWhiteSpacesColumns = new DataTable();
            dtRemoveWhiteSpacesColumns.Columns.Add("ColumnName", typeof(string));

            foreach (DataGridViewRow dgvr in dgvRemoveWhiteSpaces.Rows)
            {
                object obj = dgvr.Cells["chkBoxSelectRemoveWhiteSpacesColumn"].Value; // Implement this kind of thing
                if (obj != null) {
                    bool isSelected = (bool)obj;
                    if (isSelected)
                    {
                        object existingColumnNameValue = dgvr.Cells["ExistingColumnName"].Value;
                        string columnName = existingColumnNameValue != null ? existingColumnNameValue.ToString().Trim() : string.Empty;

                        dtRemoveWhiteSpacesColumns.Rows.Add(columnName);
                    }
                }
            }
            return dtRemoveWhiteSpacesColumns;
        }
        private string GetColumnHeaderCaseFromRadioButtons()
        {
            string headerCase = string.Empty;
            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)comboBoxHeaderCase.SelectedItem;
            if (selectedItem.Value.Equals("ChooseCase"))
                headerCase = string.Empty;
            else
                headerCase = selectedItem.Value;
            return headerCase;
        }

        private void BindHeaderCaseComboBox()
        {
            Dictionary<string, string> items = ConstantObjectsEz.ConstantObjectsEz.HeaderCases;
            //items.Remove("Proper case");

            comboBoxHeaderCase.DataSource = new BindingSource(items, null);
            comboBoxHeaderCase.DisplayMember = "Key";
            comboBoxHeaderCase.ValueMember = "Value";
            comboBoxHeaderCase.FlatStyle = FlatStyle.Standard;
            comboBoxHeaderCase.DropDownStyle = ComboBoxStyle.DropDownList;
            comboBoxHeaderCase.SelectedIndex = 2;
        }
        private void BindDefaultDgvChangeCases()
        {
            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChoosecaseSelectAll.SelectedItem;
            foreach (DataGridViewRow row in dgvChangeCases.Rows)
            {
                //DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeCase"] as DataGridViewCheckBoxCell);
                //checkBox.Value = false;
                DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseCase"] as DataGridViewComboBoxCell);
                comboBox.Value = selectedItem.Value;
            }
        }
        private void BindDefaultDgvChangeDateFormat()
        {
            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChooseDateFormatSelectAll.SelectedItem;
            foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
            {
                //DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeDateFormat"] as DataGridViewCheckBoxCell);
                //checkBox.Value = false;
                DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseDateFormat"] as DataGridViewComboBoxCell);
                comboBox.Value = selectedItem.Value;
            }
        }
        private void BindDefaultDgvReplaceValuesFormat()
        {
            DataTable dtColumnList;
            dtColumnList = DataTableHelperEz.GenerateListOfColumnsToReplaceValues(dtSourceData);

            //KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChooseDateFormatSelectAll.SelectedItem;
            foreach (DataGridViewRow row in dgvReplaceValue.Rows)
            {
                //DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeDateFormat"] as DataGridViewCheckBoxCell);
                //checkBox.Value = false;
                DataGridViewComboBoxCell comboBoxColumn = (row.Cells["comboBoxReplaceValueSelectColumn"] as DataGridViewComboBoxCell);
                
                comboBoxColumn.DataSource = dtColumnList;
                comboBoxColumn.DisplayMember = "ColumnNameText";
                comboBoxColumn.ValueMember = "ColumnNameValue";

                comboBoxColumn.Value = "SelectColumn";
            }
        }
        private void GetSelectedValuesForDataGridViewCombobox()
        {
            foreach (DataGridViewRow row in dgvChangeCases.Rows)
            {
                DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseCase"] as DataGridViewComboBoxCell);
                MessageBox.Show(comboBox.Value != null ? comboBox.Value.ToString() : "Value is null");
            }
            //For testing purpose
            //foreach (DataGridViewColumn col in dgvChangeCases.Columns)
            //{
            //    MessageBox.Show(col.Name + " : "+ col.HeaderText + " : "+ col.Index);
            //}
        }
        private void SetLocationSizeOfControl(DataGridView dataGridView,Control comboBox, string refColumn, TabPage tabPage, Control parentControl)
        {
            string controlName = comboBox.GetType().Name;
            this.tabControl.SelectedTab = tabPage;
            Rectangle rect = dataGridView.GetCellDisplayRectangle(dataGridView.Columns[refColumn].Index, -1, false);
            Size size = rect.Size;
            Point loc = rect.Location;
            //MessageBox.Show("Size is: (" + size.Width + "," + size.Height + ")" + " Location is: (" + loc.X + "," + loc.Y + ")");

            if(controlName.Equals("CheckBox"))
            {
                comboBox.Parent = parentControl;
                //comboBox.Anchor = AnchorStyles.None;
                comboBox.Location = new Point(loc.X + 8, loc.Y + 6); //10,8
                comboBox.BackColor = Color.LightGray;
                
            }
            if (controlName.Equals("ComboBox"))
            {
                comboBox.Parent = parentControl;
                comboBox.Location = new Point(loc.X, loc.Y+1); //Point(loc.X + 1, loc.Y + 3);
                //comboBox.Width = size.Width;
                comboBox.Size = size;
                comboBox.Width = comboBox.Width - 1;


            }
            //this.tabControl.SelectedTab = tabPageSourceColumns;
        }

        private void dgvShowDetails_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(dgvShowDetails.RowHeadersDefaultCellStyle.ForeColor))
            {
                e.Graphics.DrawString((e.RowIndex + 1).ToString(), e.InheritedRowStyle.Font, b, e.RowBounds.Location.X + 10, e.RowBounds.Location.Y + 4);
            }
        }
        /// <summary>
        /// This method or button is for testing purpose only.
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnShowDetails_Click(object sender, EventArgs e)
        {
            string conStr = ConfigurationManager.ConnectionStrings["EzyTool.Properties.Settings.DBEzyToolConnectionString"].ToString();
            SqlConnection sqlConnection1 = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            //SqlDataReader reader;

            cmd.CommandText = "SELECT * FROM TBL";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            //reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //dgvShowDetails.DataSource = dt;
            //dgvShowDetails.ColumnHeadersDefaultCellStyle.Font = new Font("Corbel", 8.5F, FontStyle.Regular);
            sqlConnection1.Close();



            //try
            //{
            //    //using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "CSV|*.csv", ValidateNames = true, Multiselect = false })
            //    //{
            //    //    if (ofd.ShowDialog() == DialogResult.OK)
            //    //        //dataGridView1.DataSource = ReadCsv(ofd.FileName);
            //    //        GetCount(ofd.FileName);
            //    //}

            //    ConnectLocalDb();

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //}

        }
        private void btnImportCsvFile_Click(object sender, EventArgs e)
        {
            ResetPublicVariables();
            string fileName = string.Empty;
            fileName = GetFile();
            if (!string.IsNullOrEmpty(fileName))
            {
                dtRawData = new DataTable();

                dtRawData = CsvHelperEz.ReadCsv(fileName);
                fileNameRawData = new FileInfo(fileName).Name.Split('.')[0].Replace("\\", "").Replace(" ", "_");
                tableNameRawData = "TBL_RAW_DATA_" + fileNameRawData;
                dtRawData.TableName = tableNameRawData;
                this.Invoke(new MethodInvoker(ShowFileDimension));

                Thread threadCreateTable = new Thread(CreateTableInSql);
                threadCreateTable.Start();
                Thread threadPopulateConfigurationGrids = new Thread(PopulateConfigurationGridAfterFileBrowseThread);
                threadPopulateConfigurationGrids.Start();
            }
            else
            {
                MessageBox.Show("Please browse a valid file.");
            }
        }

        private void ShowFileDimension()
        {
            lblDimension.Text = string.Format(@"No.of rows : {0} x No. of columns : {1}", dtRawData.Rows.Count, dtRawData.Columns.Count - 1);
        }

        private void PopulateConfigurationGridAfterFileBrowseThread()
        {
            this.Invoke(new MethodInvoker(BindHeaderCaseComboBox));
            this.Invoke(new MethodInvoker(ClearStepsDone));

            this.Invoke(new EnableDisableAllTabPagesDelegate(EnableDisableAllTabPages), true);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateSourceColumnsGrid), dtRawData);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateRenameColumnsGrid), dtRawData);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateChangeCaseGrid), dtRawData);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateChangeDateFormatGrid), dtRawData);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateReplaceValuesGrid), dtRawData);
            this.Invoke(new PopulateGridWithDataTableDelegate(PopulateRemoveWhiteSpacesGrid), dtRawData);
            this.Invoke(new EnableDisableAllTabPagesDelegate(EnableDisableAllTabPages), false);
            this.Invoke(new EnableDisableTabPageDelegate(EnableDisableTabPage), "tabPageSourceColumns", true);
            this.Invoke(new SetSelectedTabPageDelegate(SetSelectedTabPage), tabPageSourceColumns);
            this.Invoke(new MethodInvoker(ShowProgress));
            Thread threadPopulateGrid = new Thread(PopulateDataGridMainThread);
            threadPopulateGrid.Start();
        }

        private void ShowProgress()
        {
            progressBar.Visible = true;
            progressBar.Style = ProgressBarStyle.Marquee;
        }
        private void PopulateDataGridMainThread()
        {
            PopulateDataGridFirstTime(dtRawData);
        }
        private void CreateTableInSql()
        {
            //Generate the create table sql script
            string createtblcommand = SqlScriptHelperEz.GenerateCreateTableScript(dtRawData);
            //Create the table in sql db
            SqlDbAccessHelperEz.ExecuteSqlCommand(createtblcommand);
            //Load the csv data table into sql table
            SqlDbAccessHelperEz.LoadDataTableIntoSql(dtRawData);
        }

        private string GetFile()
        {
            string fileName = string.Empty;
            //Read csv file into data table
            using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "CSV|*.csv", ValidateNames = true, Multiselect = false })
            {
                if (ofd.ShowDialog() == DialogResult.OK)
                {
                    fileName = ofd.FileName;
                    txtFileName.Text = fileName;
                }
            }

            return fileName;
        }

        //private void btnImportCsvFile_Click_Bkp(object sender, EventArgs e)
        //{
        //    ResetPublicVariables();
        //    dtRawData = new DataTable();
        //    string fileName = string.Empty;

        //    //Read csv file into data table
        //    using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "CSV|*.csv", ValidateNames = true, Multiselect = false })
        //    {
        //        if (ofd.ShowDialog() == DialogResult.OK)
        //        {
        //            dtRawData = CsvHelperEz.ReadCsv(ofd.FileName);
        //            fileName = ofd.FileName;
        //            txtFileName.Text = fileName;
        //        }
        //    }
        //    //Poppulate the csv grid
        //    PopulateDataGrid(true);
        //    //ShowDataInOtherForm(dt);

        //    fileNameRawData = new FileInfo(fileName).Name.Split('.')[0].Replace("\\", "").Replace(" ", "_");
        //    //Create the table name
        //    tableNameRawData = "TBL_RAW_DATA_" + fileNameRawData;
        //    dtRawData.TableName = tableNameRawData;

        //    //Generate the create table sql script
        //    string createtblcommand = SqlScriptHelperEz.GenerateCreateTableScript(dtRawData);

        //    //Create the table in sql db
        //    SqlDbAccessHelperEz.ExecuteSqlCommand(createtblcommand);

        //    //Load the csv data table into sql table
        //    SqlDbAccessHelperEz.LoadDataTableIntoSql(dtRawData);

        //    BindHeaderCaseComboBox();

        //    EnableDisableAllTabPages(true);

        //    //Populate the Rename columns, Change case grids
        //    ClearStepsDone();
        //    PopulateSourceColumnsGrid(dtRawData);
        //    PopulateRenameColumnsGrid(dtRawData);
        //    PopulateChangeCaseGrid(dtRawData);
        //    PopulateChangeDateFormatGrid(dtRawData);
        //    PopulateReplaceValuesGrid(dtRawData);
        //    PopulateRemoveWhiteSpacesGrid(dtRawData);

        //    EnableDisableAllTabPages(false);

        //    EnableDisableTabPage("tabPageSourceColumns", true);

        //    SetSelectedTabPage(tabPageSourceColumns);

        //    //dgvShowDetails.DataSource = ExecuteGetData("SELECT SKU_ID, LOWER(SECT_NAME) AS LOWNAME, UPPER(SECT_NAME) AS UPPERNAME FROM " + tableName);
        //    //dgvShowDetails.DataSource = ExecuteGetData("SELECT * FROM " + tableName);

        //}
        private void btnPreviewData_Click(object sender, EventArgs e)
        {
            ShowDataInOtherForm();
        }

        private void btnProcessSourceColumns_Click(object sender, EventArgs e)
        {
            DataTable dt = GetSelectedSourceColumnsFromGrid();
            tableNameSourceData = "TBL_SOURCE_DATA_" + fileNameRawData;
            string script = SqlScriptHelperEz.GenerateCreateSourceTableScript(dt, tableNameRawData, tableNameSourceData);

            //Create the table in sql db
            SqlDbAccessHelperEz.ExecuteSqlCommand(script);
            ClearStepsDone();
            AddStepDone(tabPageSourceColumns.Text);
            dtSourceData = GetSourceData();

            MessageBox.Show("Proccessed.." + script);
            //Now load all the configuration grids in tab control


            EnableDisableAllTabPages(true);

            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            //EnableDisableAllTabPages(true);

            isSourceColumnProcessed = true;
            EnableDisableTabPage("tabPageSourceColumns", false);

            chkBoxEnableSourceColumnsTab.Visible = true;
            chkBoxEnableSourceColumnsTab.Checked = false;

            SetSelectedTabPage(tabPageSourceColumns);

            PopulateDataGridNextTime();
            //tabPageSourceColumns.ImageIndex = 1;

        }

        private DataTable GetSourceData()
        {
            return SqlDbAccessHelperEz.ExecuteGetData("SELECT TOP "+ TopRecordsCount.ToString() + " * FROM " + tableNameSourceData);
        }

        private void btnProcessRenameColumns_Click(object sender, EventArgs e)
        {
            DataTable dt = GetRenameColumnNamesFromGrid();
            string script = string.Empty;
            if (string.IsNullOrEmpty(tableNameSourceData))
            {
                tableNameSourceData = "TBL_SOURCE_DATA_" + fileNameRawData;
                script = SqlScriptHelperEz.GenerateCreateRenameColumnsScript(dt, tableNameRawData, tableNameSourceData);
            }
            else
            {
                script = SqlScriptHelperEz.GenerateCreateRenameColumnsScript(dt, tableNameSourceData, tableNameSourceData);
            }
            //Create the table in sql db
            SqlDbAccessHelperEz.ExecuteSqlCommand(script);
            AddStepDone(tabPageRenameColumns.Text);
            dtSourceData = GetSourceData();


            MessageBox.Show("Proccessed.." + script);

            EnableDisableAllTabPages(true);

            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            EnableDisableTabPage("tabPageSourceColumns", false);


            SetSelectedTabPage(tabPageRenameColumns);
            PopulateDataGridNextTime();
            //tabPageRenameColumns.ImageIndex = 1;

        }
        private void btnProcessChangeCases_Click(object sender, EventArgs e)//>>
        {
            DataTable dt = GetChangeCasesFromGrid();
            //tableNameSourceData = "TBL_SOURCE_DATA_" + fileNameRawData;
            string script = SqlScriptHelperEz.GenerateChangeCasesScript(dt, tableNameSourceData);

            ////Create the table in sql db
            SqlDbAccessHelperEz.ExecuteSqlCommand(script);
            AddStepDone(tabPageChangeCases.Text);
            dtSourceData = GetSourceData();


            MessageBox.Show("Proccessed.." + script);

            EnableDisableAllTabPages(true);

            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            EnableDisableTabPage("tabPageSourceColumns", false);

            chkBoxChoosecaseSelectAll.Checked = false;
            SetSelectedTabPage(tabPageChangeCases);
            PopulateDataGridNextTime();
            //tabPageChangeCases.ImageIndex = 1;

        }
        private void btnProcessChangeDateFormat_Click(object sender, EventArgs e) // TO BE IMPLEMENTED
        {
            DataTable dt = GetChangeDateFormatsFromGrid();
            //tableNameSourceData = "TBL_SOURCE_DATA_" + fileNameRawData;
            string script = SqlScriptHelperEz.GenerateChangeCasesScript(dt, tableNameSourceData);

            ////Create the table in sql db
            //SqlDbAccessHelperEz.ExecuteSqlCommand(script);
            AddStepDone(tabPageChangeDateFormat.Text);
            dtSourceData = GetSourceData();


            MessageBox.Show("Proccessed.." + script);

            EnableDisableAllTabPages(true);

            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            EnableDisableTabPage("tabPageSourceColumns", false);

            SetSelectedTabPage(tabPageChangeDateFormat);
            PopulateDataGridNextTime();
            //tabPageChangeDateFormat.ImageIndex = 1;

        }
        private void btnProcessReplaceValues_Click(object sender, EventArgs e)
        {
            DataTable dt = GetReplaceValuesFromGrid();
            List<string> scripts = SqlScriptHelperEz.GenerateReplaceValuesScript(dt, tableNameSourceData);

            foreach (string script in scripts)
            {
                SqlDbAccessHelperEz.ExecuteSqlCommand(script);
                //MessageBox.Show("Proccessed.." + script);
                if (scripts.Count > 1)
                    System.Threading.Thread.Sleep(1000);
            }
            AddStepDone(tabPageReplaceValues.Text);

            dtSourceData = GetSourceData();

            MessageBox.Show("Proccessed..");

            EnableDisableAllTabPages(true);

            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            EnableDisableTabPage("tabPageSourceColumns", false);

            SetSelectedTabPage(tabPageReplaceValues);
            PopulateDataGridNextTime();
            //tabPageReplaceValues.ImageIndex = 1;
        }
        private void btnProcessRemoveWhiteSpaces_Click(object sender, EventArgs e)
        {
            DataTable dt = GetRemoveWhiteSpacesColumnsFromGrid();
            tableNameSourceData = "TBL_SOURCE_DATA_" + fileNameRawData;
            List<string> scripts = SqlScriptHelperEz.GenerateRemoveWhiteSpacesScript(dt, tableNameSourceData);

            foreach (string script in scripts)
            {
                SqlDbAccessHelperEz.ExecuteSqlCommand(script);
                //MessageBox.Show("Proccessed.." + script);
                if (scripts.Count > 1)
                    System.Threading.Thread.Sleep(500);
            }

            AddStepDone(tabPageRemoveWhiteSpaces.Text);
            dtSourceData = GetSourceData();
            MessageBox.Show("Proccessed..");

            //Now load all the configuration grids in tab control


            EnableDisableAllTabPages(true);
            PopulateRenameColumnsGrid(dtSourceData);
            PopulateChangeCaseGrid(dtSourceData);
            PopulateChangeDateFormatGrid(dtSourceData);
            PopulateReplaceValuesGrid(dtSourceData);
            PopulateRemoveWhiteSpacesGrid(dtSourceData);

            EnableDisableTabPage("tabPageSourceColumns", false);

            SetSelectedTabPage(tabPageRemoveWhiteSpaces);
            PopulateDataGridNextTime();
            //tabPageRemoveWhiteSpaces.ImageIndex = 1;
        }
        
        private void btnCancelSourceColumns_Click(object sender, EventArgs e)
        {
                foreach (DataGridViewRow row in dgvSOurceColumns.Rows)
                {
                    DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectSourceColumn"] as DataGridViewCheckBoxCell);
                    checkBox.Value = false;
                }
                chkBoxSourceColumnsSelectAll.Checked = false;
        }
        private void btnCancelRenameColumns_Click(object sender, EventArgs e)
        {
                foreach (DataGridViewRow row in dgvRenameColumns.Rows)
                {
                    DataGridViewTextBoxCell txtBoxRenameColumnName = (row.Cells["RenameColumnName"] as DataGridViewTextBoxCell);
                    txtBoxRenameColumnName.Value = string.Empty;
                }

        }
        private void btnCancelChangeCases_Click(object sender, EventArgs e)
        {
            //GetSelectedValuesForDataGridViewCombobox();

            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChoosecaseSelectAll.SelectedItem;
            foreach (DataGridViewRow row in dgvChangeCases.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeCase"] as DataGridViewCheckBoxCell);
                checkBox.Value = false;
                DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseCase"] as DataGridViewComboBoxCell);
                comboBox.Value = selectedItem.Value;
            }
            chkBoxChoosecaseSelectAll.Checked = false;
            cmbBoxChoosecaseSelectAll.SelectedIndex = 0;

        }
        private void btnCancelChooseDateFormat_Click(object sender, EventArgs e)
        {
            //foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
            //{
            //    DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseDateFormat"] as DataGridViewComboBoxCell);
            //    MessageBox.Show(comboBox.Value != null ? comboBox.Value.ToString() : "Value is null");
            //}

            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChooseDateFormatSelectAll.SelectedItem;
            foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeDateFormat"] as DataGridViewCheckBoxCell);
                checkBox.Value = false;
                DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseDateFormat"] as DataGridViewComboBoxCell);
                comboBox.Value = selectedItem.Value;
            }
            chkBoxChooseDateFormatSelectAll.Checked = false;
            cmbBoxChooseDateFormatSelectAll.SelectedIndex = 0;
        }
        private void btnCancelReplaceValues_Click(object sender, EventArgs e)
        {
            PopulateReplaceValuesGrid(dtSourceData);
        }
        private void btnCancelRemoveWhiteSpaces_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvRemoveWhiteSpaces.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectRemoveWhiteSpacesColumn"] as DataGridViewCheckBoxCell);
                checkBox.Value = false;
            }
            chkBoxRemoveWhiteSpacesSelectAll.Checked = false;

        }

        private void chkBoxEnableSourceColumnsTab_Click(object sender, EventArgs e)
        {
            if (chkBoxEnableSourceColumnsTab.Checked)
            {
                MessageBox.Show("Do you want to reselect the source columns? The applied steps will be flushed out. Proceed?");
                EnableDisableTabPage("tabPageSourceColumns", true);
            }
            else
            {
                EnableDisableTabPage("tabPageSourceColumns", false);

            }
        }
        private void chkBoxSourceColumnsSelectAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvSOurceColumns.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectSourceColumn"] as DataGridViewCheckBoxCell);
                checkBox.Value = chkBoxSourceColumnsSelectAll.Checked;
            }
        }
        private void chkBoxChoosecaseSelectAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvChangeCases.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeCase"] as DataGridViewCheckBoxCell);
                checkBox.Value = chkBoxChoosecaseSelectAll.Checked;
            }
        }
        private void chkBoxChooseDateFormatSelectAll_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeDateFormat"] as DataGridViewCheckBoxCell);
                checkBox.Value = chkBoxChooseDateFormatSelectAll.Checked;
            }

        }
        private void chkBoxRemoveWhiteSpacesSelectAll_Click(object sender, EventArgs e)
        {

            foreach (DataGridViewRow row in dgvRemoveWhiteSpaces.Rows)
            {
                DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectRemoveWhiteSpacesColumn"] as DataGridViewCheckBoxCell);
                checkBox.Value = chkBoxRemoveWhiteSpacesSelectAll.Checked;
            }
        }
        private void cmbBoxChooseDateFormatSelectAll_SelectedIndexChanged(object sender, EventArgs e)
        {
            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChooseDateFormatSelectAll.SelectedItem;
            if (!selectedItem.Value.Equals("ChooseDateFormat"))
            {
                foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
                {
                    DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseDateFormat"] as DataGridViewComboBoxCell);
                    comboBox.Value = selectedItem.Value;
                }
            }

        }
        private void cmbBoxChoosecaseSelectAll_SelectedIndexChanged(object sender, EventArgs e)
        {
            KeyValuePair<string, string> selectedItem = (KeyValuePair<string, string>)cmbBoxChoosecaseSelectAll.SelectedItem;
            if (!selectedItem.Value.Equals("ChooseCase"))
            {
                foreach (DataGridViewRow row in dgvChangeCases.Rows)
                {
                    DataGridViewComboBoxCell comboBox = (row.Cells["cmbBoxChooseCase"] as DataGridViewComboBoxCell);
                    comboBox.Value = selectedItem.Value;
                }
            }
        }

        private void dgvSOurceColumns_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Point headerCellLocation = this.dgvSOurceColumns.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
            //MessageBox.Show("R,C : " + e.RowIndex + " , " + e.ColumnIndex + " X,Y : " + headerCellLocation.X + " , " + headerCellLocation.Y);
            if (e.RowIndex >= 0 && e.ColumnIndex == 1)
            {
                bool isChecked = true;
                foreach (DataGridViewRow row in dgvSOurceColumns.Rows)
                {
                    DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectSourceColumn"] as DataGridViewCheckBoxCell);
                    if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(false))
                    {
                        isChecked = false;
                        break;
                    }
                }
                chkBoxSourceColumnsSelectAll.Checked = isChecked;
            }
        }
        private void dgvChangeCases_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvChangeCases.IsCurrentCellDirty)
            {
                dgvChangeCases.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }
        private void dgvChangeCases_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                cmbBoxChoosecaseSelectAll.SelectedIndex = 0;
            }
        }
        private void dgvChangeCases_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show("Content Clicked " + e.ColumnIndex);
            ////MessageBox.Show("Row:Column : " + e.RowIndex + " : " + e.ColumnIndex);
            ////Point headerCellLocation = this.dgvChangeCases.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
            ////MessageBox.Show("R,C : "+ e.RowIndex + " , " + e.ColumnIndex + " X,Y : "+ headerCellLocation.X + " , " + headerCellLocation.Y);
            ////MessageBox.Show(headerCellLocation.X + "- " + headerCellLocation.Y);
            ////MessageBox.Show(e.RowIndex + "- " + e.ColumnIndex);

            //MessageBox.Show("Content Clicked " + e.ColumnIndex);
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvChangeCases.Columns["chkBoxSelectChangeCase"].Index) //1) ////dgvChangeCases.Columns["chkBoxSelectChangeCase"].Index
            {
                //MessageBox.Show("Content Clicked checkbox " + e.ColumnIndex);
                bool isChecked = true;
                foreach (DataGridViewRow row in dgvChangeCases.Rows)
                {
                    DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeCase"] as DataGridViewCheckBoxCell);
                    //MessageBox.Show(Convert.ToBoolean(checkBox.EditedFormattedValue).ToString());
                    if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(false))
                    {
                        isChecked = false;
                        break;
                    }
                }
                chkBoxChoosecaseSelectAll.Checked = isChecked;
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvChangeCases.Columns["cmbBoxChooseCase"].Index)//3) //dgvChangeCases.Columns["cmbBoxChooseCase"].Index
            {
            }
        }
        private void dgvChangeDateFormat_CurrentCellDirtyStateChanged(object sender, EventArgs e)
        {
            if (dgvChangeDateFormat.IsCurrentCellDirty)
            {
                dgvChangeDateFormat.CommitEdit(DataGridViewDataErrorContexts.Commit);
            }
        }
        private void dgvChangeDateFormat_CellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex > -1)
            {
                cmbBoxChooseDateFormatSelectAll.SelectedIndex = 0;
            }
        }
        private void dgvChangeDateFormat_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

            //Rectangle rect = this.dgvChangeCases.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false);
            //Size size = rect.Size;
            //Point loc = rect.Location;
            //MessageBox.Show("Cell content click Size is: (" + size.Width + "," + size.Height + ")" + " Location is: (" + loc.X + "," + loc.Y + ")");


            //MessageBox.Show("Content Clicked " + e.ColumnIndex);
            ////MessageBox.Show("Row:Column : " + e.RowIndex + " : " + e.ColumnIndex);
            ////Point headerCellLocation = this.dgvChangeDateFormat.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
            ////MessageBox.Show("R,C : "+ e.RowIndex + " , " + e.ColumnIndex + " X,Y : "+ headerCellLocation.X + " , " + headerCellLocation.Y);
            ////MessageBox.Show(headerCellLocation.X + "- " + headerCellLocation.Y);
            ////MessageBox.Show(e.RowIndex + "- " + e.ColumnIndex);

            //MessageBox.Show("Content Clicked " + e.ColumnIndex);
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvChangeDateFormat.Columns["chkBoxSelectChangeDateFormat"].Index) //1) ////dgvChangeCases.Columns["chkBoxSelectChangeCase"].Index
            {
                //MessageBox.Show("Content Clicked checkbox " + e.ColumnIndex);
                bool isChecked = true;
                foreach (DataGridViewRow row in dgvChangeDateFormat.Rows)
                {
                    DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectChangeDateFormat"] as DataGridViewCheckBoxCell);
                    //MessageBox.Show(Convert.ToBoolean(checkBox.EditedFormattedValue).ToString());
                    if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(false))
                    {
                        isChecked = false;
                        break;
                    }
                }
                chkBoxChooseDateFormatSelectAll.Checked = isChecked;
            }
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvChangeDateFormat.Columns["cmbBoxChooseDateFormat"].Index)//3) //dgvChangeCases.Columns["cmbBoxChooseCase"].Index
            {
            }
        }
        private void dgvRemoveWhiteSpaces_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            //Point headerCellLocation = this.dgvSOurceColumns.GetCellDisplayRectangle(e.ColumnIndex, e.RowIndex, false).Location;
            //MessageBox.Show("R,C : " + e.RowIndex + " , " + e.ColumnIndex + " X,Y : " + headerCellLocation.X + " , " + headerCellLocation.Y);
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvRemoveWhiteSpaces.Columns["chkBoxSelectRemoveWhiteSpacesColumn"].Index)// 1)
            {
                bool isChecked = true;
                foreach (DataGridViewRow row in dgvRemoveWhiteSpaces.Rows)
                {
                    DataGridViewCheckBoxCell checkBox = (row.Cells["chkBoxSelectRemoveWhiteSpacesColumn"] as DataGridViewCheckBoxCell);
                    if (Convert.ToBoolean(checkBox.EditedFormattedValue).Equals(false))
                    {
                        isChecked = false;
                        break;
                    }
                }
                chkBoxRemoveWhiteSpacesSelectAll.Checked = isChecked;
            }
        }
        private void dgvReplaceValue_RowPostPaint(object sender, DataGridViewRowPostPaintEventArgs e)
        {
            using (SolidBrush b = new SolidBrush(dgvReplaceValue.RowHeadersDefaultCellStyle.ForeColor))
            {
                e.Graphics.DrawString((e.RowIndex + 1).ToString(), e.InheritedRowStyle.Font, b, e.RowBounds.Location.X + 10, e.RowBounds.Location.Y + 4);
            }
        }

        private void dgvRenameColumns_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvRenameColumns.Columns["RenameColumnName"].Index)
            {
                dgvRenameColumns.Cursor = Cursors.IBeam;
            }
        }
        private void dgvRenameColumns_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && e.ColumnIndex == dgvRenameColumns.Columns["RenameColumnName"].Index)
            {
                dgvRenameColumns.Cursor = Cursors.Default;
            }
        }
        private void dgvReplaceValue_CellMouseEnter(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && (e.ColumnIndex == dgvReplaceValue.Columns["ExistingColumnValue"].Index
                || e.ColumnIndex == dgvReplaceValue.Columns["ReplaceByValue"].Index))
            {
                dgvReplaceValue.Cursor = Cursors.IBeam;
            }
        }
        private void dgvReplaceValue_CellMouseLeave(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0 && (e.ColumnIndex == dgvReplaceValue.Columns["ExistingColumnValue"].Index
                || e.ColumnIndex == dgvReplaceValue.Columns["ReplaceByValue"].Index))
            {
                dgvReplaceValue.Cursor = Cursors.Default;
            }
        }
        private void dgvReplaceValue_DefaultValuesNeeded(object sender, DataGridViewRowEventArgs e)
        {
            DataTable dtColumnList;
            dtColumnList = DataTableHelperEz.GenerateListOfColumnsToReplaceValues(dtSourceData);

            //MessageBox.Show("User Row added: "+ e.Row.Index);
            DataGridViewRow row = dgvReplaceValue.Rows[e.Row.Index];

            DataGridViewComboBoxCell comboBox = (row.Cells["comboBoxReplaceValueSelectColumn"] as DataGridViewComboBoxCell);
            comboBox.DataSource = dtColumnList;
            comboBox.DisplayMember = "ColumnNameText";
            comboBox.ValueMember = "ColumnNameValue";
            comboBox.Value = "SelectColumn";

            DataGridViewTextBoxCell txtBoxExistingValue = (row.Cells["ExistingColumnValue"] as DataGridViewTextBoxCell);
            txtBoxExistingValue.Value = string.Empty;
            DataGridViewTextBoxCell txtBoxReplaceByValue = (row.Cells["ReplaceByValue"] as DataGridViewTextBoxCell);
            txtBoxReplaceByValue.Value = string.Empty;

        }

        private void btnExportToCsv_Click(object sender, EventArgs e)
        {

            StringBuilder sb = new StringBuilder();
            DataTable dt = GetData();
            sb.Append("StudentID,StudentName,RollNumber,TotalMarks");
            sb.AppendLine();
            foreach (DataRow dr in dt.Rows)
            {
                foreach (DataColumn dc in dt.Columns)
                    sb.Append(FormatCSV(dr[dc.ColumnName].ToString()) + ",");
                sb.Remove(sb.Length - 1, 1);
                sb.AppendLine();
            }
            File.WriteAllText("D:\\z.Oms\\SampleCSV.csv", sb.ToString());


        }

        DataTable GetData()
        {
            DataTable dt = new DataTable();
            dt.Columns.Add("StudentID", typeof(int));
            dt.Columns.Add("StudentName", typeof(string));
            dt.Columns.Add("RollNumber", typeof(int));
            dt.Columns.Add("TotalMarks", typeof(int));
            dt.Rows.Add(1, "Jame's", 101, 900);
            dt.Rows.Add(2, "Steave, Smith", 105, 820);
            dt.Rows.Add(3, "Mark\"Waugh", 109, 850);
            dt.Rows.Add(4, "Steave,\"Waugh", 110, 950);
            dt.Rows.Add(5, "Smith", 111, 910);
            dt.Rows.Add(6, "Williams", 115, 864);
            return dt;
        }

        public static string FormatCSV(string input)
        {
            try
            {
                if (input == null)
                    return string.Empty;

                bool containsQuote = false;
                bool containsComma = false;
                int len = input.Length;
                for (int i = 0; i < len && (containsComma == false || containsQuote == false); i++)
                {
                    char ch = input[i];
                    if (ch == '"')
                        containsQuote = true;
                    else if (ch == ',')
                        containsComma = true;
                }

                if (containsQuote && containsComma)
                    input = input.Replace("\"", "\"\"");

                if (containsComma)
                    return "\"" + input + "\"";
                else
                    return input;
            }
            catch
            {
                throw;
            }
        }

        private void frmMain_SizeChanged(object sender, EventArgs e)
        {
            ChangePositionOfControlsInDataGridViewHeader();
        }

        private void ChangePositionOfControlsInDataGridViewHeader()
        {
            var selectedTabPage = tabControl.SelectedTab;

            switch (selectedTabPage.Name)
            {
                case "tabPageSourceColumns":
                    SetLocationSizeOfControl(dgvSOurceColumns, chkBoxSourceColumnsSelectAll, "chkBoxSelectSourceColumn", tabPageSourceColumns, dgvSOurceColumns);
                    break;
                case "tabPageChangeCases":
                    SetLocationSizeOfControl(dgvChangeCases, chkBoxChoosecaseSelectAll, "chkBoxSelectChangeCase", tabPageChangeCases, dgvChangeCases);
                    SetLocationSizeOfControl(dgvChangeCases, cmbBoxChoosecaseSelectAll, "cmbBoxChooseCase", tabPageChangeCases, dgvChangeCases);
                    break;
                case "tabPageChangeDateFormat":
                    SetLocationSizeOfControl(dgvChangeDateFormat, chkBoxChooseDateFormatSelectAll, "chkBoxSelectChangeDateFormat", tabPageChangeDateFormat, dgvChangeDateFormat);
                    SetLocationSizeOfControl(dgvChangeDateFormat, cmbBoxChooseDateFormatSelectAll, "cmbBoxChooseDateFormat", tabPageChangeDateFormat, dgvChangeDateFormat);
                    break;
                case "tabPageRemoveWhiteSpaces":
                    SetLocationSizeOfControl(dgvRemoveWhiteSpaces, chkBoxRemoveWhiteSpacesSelectAll, "chkBoxSelectRemoveWhiteSpacesColumn", tabPageRemoveWhiteSpaces, dgvRemoveWhiteSpaces);
                    break;
            }
        }

        private void tabControl_SelectedIndexChanged(object sender, EventArgs e)
        {
            ChangePositionOfControlsInDataGridViewHeader();
        }
    }
}


/*
DECLARE @str AS VARCHAR(100) = ' Welcome to   India '
SELECT TRIM(STRING_AGG(VAL, ' ')) FROM (
SELECT value AS VAL FROM STRING_SPLIT(@str, ' ') WHERE LTRIM(RTRIM(value)) <> ''
) AS A
-----------------------------------



SELECT EZY_ID, DESCRIPTION
INTO #SPLITING_SOURCE
FROM TBL_SOURCE_DATA_Mini_csv_sample_data

UPDATE TBL_SOURCE_DATA_Mini_csv_sample_data SET [DESCRIPTION] = [DESCRIPTION_UPD]
FROM TBL_SOURCE_DATA_Mini_csv_sample_data AS B
JOIN 
(
	SELECT EZY_ID, TRIM(STRING_AGG(value_upd, ' '))  AS [DESCRIPTION_UPD] FROM (
	SELECT  EZY_ID, value, CASE WHEN value = 'iss' THEN REPLACE(value, 'iss', 'is') ELSE value END AS value_upd
		FROM #SPLITING_SOURCE  
			CROSS APPLY STRING_SPLIT([DESCRIPTION], ' ')
	) AS A
	GROUP BY EZY_ID
) AS C ON B.EZY_ID = C.EZY_ID

IF OBJECT_ID('TempDB.dbo.#SPLITING_SOURCE') IS NOT NULL
	DROP TABLE #SPLITING_SOURCE
-------------------------------------------

SELECT EZY_ID, {1}
INTO #SPLITING_SOURCE
FROM {0}

UPDATE {0} SET [{1}] = [{4}]
FROM {0} AS B
JOIN 
(
	SELECT EZY_ID, TRIM(STRING_AGG(value_upd, ' '))  AS [{4}] 
    FROM (
	        SELECT  EZY_ID, value, CASE WHEN value = '{2}' THEN REPLACE(value, '{2}', '{3}') ELSE value END AS value_upd
		    FROM #SPLITING_SOURCE  
			CROSS APPLY STRING_SPLIT([{1}], ' ')
	) AS A
	GROUP BY EZY_ID
) AS C ON B.EZY_ID = C.EZY_ID

IF OBJECT_ID('TempDB.dbo.#SPLITING_SOURCE') IS NOT NULL
	DROP TABLE #SPLITING_SOURCE


 */



//private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
//{
//    var senderGrid = (DataGridView)sender;

//    if (senderGrid.Columns[e.ColumnIndex] is DataGridViewButtonColumn &&
//        e.RowIndex >= 0)
//    {
//        //TODO - Button Clicked - Execute Code Here
//    }
//}
//private void dataGridView1_CellClick(object sender, DataGridViewCellEventArgs e)
//{
//    // Ignore clicks that are not in our 
//    if (e.ColumnIndex == dataGridView1.Columns["MyButtonColumn"].Index && e.RowIndex >= 0)
//    {
//        Console.WriteLine("Button on row {0} clicked", e.RowIndex);
//    }
//}

//dataTable.Columns.Remove("EzID");

//foreach (DataRowView dr in dataTable.DefaultView)
//{
//    if (dr["ExistingColumnName"].Equals("EzID"))
//        dr.Row.Delete();
//}
//dataTable.AcceptChanges();

/* btn show details
string conStr = ConfigurationManager.ConnectionStrings["EzyTool.Properties.Settings.DBEzyToolConnectionString"].ToString();
            SqlConnection sqlConnection1 = new SqlConnection(conStr);
            SqlCommand cmd = new SqlCommand();
            //SqlDataReader reader;

            cmd.CommandText = "SELECT * FROM TBL";
            cmd.CommandType = CommandType.Text;
            cmd.Connection = sqlConnection1;

            sqlConnection1.Open();

            //reader = cmd.ExecuteReader();
            // Data is accessible through the DataReader object here.

            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataTable dt = new DataTable();
            da.Fill(dt);
            //dgvShowDetails.DataSource = dt;
            //dgvShowDetails.ColumnHeadersDefaultCellStyle.Font = new Font("Corbel", 8.5F, FontStyle.Regular);
            sqlConnection1.Close();



            //try
            //{
            //    //using (OpenFileDialog ofd = new OpenFileDialog() { Filter = "CSV|*.csv", ValidateNames = true, Multiselect = false })
            //    //{
            //    //    if (ofd.ShowDialog() == DialogResult.OK)
            //    //        //dataGridView1.DataSource = ReadCsv(ofd.FileName);
            //    //        GetCount(ofd.FileName);
            //    //}

            //    ConnectLocalDb();

            //}
            //catch (Exception ex)
            //{
            //    MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            //} 
     
     
*/
