﻿using Microsoft.VisualBasic.FileIO;
using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EzyTool.Services
{
    public static class CsvHelperEz
    {
        private static DataTable AddAutoIncrementColumn()
        {
            DataColumn dataColumn = new DataColumn();
            dataColumn.AllowDBNull = false;
            dataColumn.AutoIncrement = true;
            dataColumn.AutoIncrementSeed = 1;
            dataColumn.AutoIncrementStep = 1;
            dataColumn.ColumnName = "EzID";
            dataColumn.DataType = System.Type.GetType("System.Int32");
            dataColumn.Unique = true;
            
            DataTable dataTable = new DataTable();
            dataTable.Columns.Add(dataColumn);
            return dataTable;
        }
        private static DataTable AddAutoIncrementColumn(DataTable sourceDataTable)
        {
            DataColumn dataColumn = new DataColumn();
            dataColumn.AllowDBNull = false;
            dataColumn.AutoIncrement = true;
            dataColumn.AutoIncrementSeed = 1;
            dataColumn.AutoIncrementStep = 1;
            dataColumn.ColumnName = "EzID";
            dataColumn.DataType = System.Type.GetType("System.Int32");
            dataColumn.Unique = true;

            DataTable dataTable = new DataTable();
            dataTable.Columns.Add(dataColumn);
            dataTable.Merge(sourceDataTable);

            return dataTable;
        }
        private static DataTable ParseListToDataTable(List<string[]> list)
        {
            DataTable dataTable = new DataTable();

            // Get maximum number of columns
            int columns = 0;
            foreach (var array in list)
            {
                if (array.Length > columns)
                {
                    columns = array.Length;
                }
            }

            // Get the header row from the list
            var header = list[0];

            // Add columns to the data table
            for (int i = 0; i < columns; i++)
            {
                dataTable.Columns.Add(header[i]);
            }
            list.RemoveAt(0);

            // Add rows to the data table
            foreach (var array in list)
            {
                dataTable.Rows.Add(array);
            }

            return dataTable;
        }

        public static DataTable ReadCsvV0(string fileName)
        {
            DataTable dt = new DataTable();
            dt = AddAutoIncrementColumn();
            using (OleDbConnection con = new OleDbConnection("Provider=Microsoft.Jet.OLEDB.4.0;Data Source=\"" +
                Path.GetDirectoryName(fileName) + "\";Extended Properties=\"Text;HDR=yes;IMEX=1;FMT=CSVDelimited\";")) //;Extended Properties='text;HDR=Yes;FMT=Delimited(,)';
            {
                using (OleDbCommand cmd = new OleDbCommand(string.Format("SELECT * FROM [{0}]", new FileInfo(fileName).Name), con))
                {
                    con.Open();
                    using (OleDbDataAdapter adapter = new OleDbDataAdapter(cmd))
                    {
                        adapter.Fill(dt);
                    }
                }
            }
            return dt;
        }
        public static DataTable ReadCsv(string fileName)
        {
            List<string[]> listOfRecords = new List<string[]>();
            
            using (TextFieldParser parser = new TextFieldParser(fileName))
            {
                parser.CommentTokens = new string[] { "#" };
                parser.SetDelimiters(new string[] { "," });
                parser.HasFieldsEnclosedInQuotes = true;

                // First line is the header line.
                var headerRow = parser.ReadFields();

                // Add header row in the list of records
                listOfRecords.Add(headerRow);

                // Loop though all the lines that are actually data rows
                while (!parser.EndOfData)
                {
                    listOfRecords.Add(parser.ReadFields());
                }
            }

            // Convert the list of records into the data table
            // Add the identity column in the data table
            DataTable dataTable = new DataTable();
            dataTable = ParseListToDataTable(listOfRecords);
            dataTable = AddAutoIncrementColumn(dataTable);
            return dataTable;
        }

        //Code to make use in cas if it is required
        public static void CreateCsvSchemaFile(string filePath)
        {
            using (FileStream fs = new FileStream(Path.GetDirectoryName(filePath) + "\\schema.ini", FileMode.Create, FileAccess.Write))
            {
                using (StreamWriter sw = new StreamWriter(fs))
                {
                    sw.WriteLine("[" + Path.GetFileName(filePath) + "]");
                    sw.WriteLine("ColNameHeader=True");
                    //sw.WriteLine("MaxScanRows=0");
                    sw.WriteLine("Format=Delimited(;)");
                    sw.WriteLine("DateTimeFormat=yyyy-MM-dd");
                    sw.WriteLine("CharacterSet=ANSI");
                    sw.WriteLine("Col1=\"Operating Unit Organization Name\" Text Width 255");
                    sw.WriteLine("Col2=\"Year\" Long");
                    sw.WriteLine("Col3=\"Sales Rep Name\" Text Width 255");
                    sw.WriteLine("Col4=\"Date\" DateTime");
                    sw.WriteLine("Col5=\"Week\" Text Width 255");
                    sw.WriteLine("Col6=\"Product Number\" Text Width 255");
                    sw.WriteLine("Col7=\"Account Name\" Text Width 255");
                    sw.WriteLine("Col8=\"Customer Number\" Text Width 255");
                    sw.WriteLine("Col9=\"Corporate Brand\" Text Width 255");
                    sw.WriteLine("Col10=\"Brand\" Text Width 255");
                    sw.WriteLine("Col11=\"Ordered Quantity\" Long");
                    sw.WriteLine("Col12=\"Amount\" Currency");
                    sw.Close();
                    sw.Dispose();
                }

                fs.Close();
                fs.Dispose();
            }
        }
    }
}
