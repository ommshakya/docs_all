I am persuing **PGDAST** (*Post Graduate Diploma in Applied Statistics*) from IGNOU, 
Regional Center Bengalore.

This repo contains my efforts on studying this course.

*About me* : 

My name is **PRASHANT CHIKHALKAR**, I am Software Engineer working for Wind River ( An Intel Company) in Bengalore, India.

I did my engineering in Electronics from Nagpur University, Nagpur, Maharastra.

You can reach me at : prashantchikhalkar@gmail.com
