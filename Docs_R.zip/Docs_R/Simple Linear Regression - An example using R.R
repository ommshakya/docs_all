# https://feliperego.github.io/blog/2015/03/11/Simple-Linear-Regression-Example-in-R
# load the required packages.

if(!require(car)) library(car) # Library containing the dataset.
if(!require(ggplot2)) library(ggplot2) # Library to create some nice looking graphs.
if(!require(MASS)) library(MASS) # Library for our box-cox transform down the end.

# Inspect and summarize the data.

head(Prestige)
str(Prestige)
summary(Prestige)

# Since our focus in this example is the simple linear regression model, we'll discard all 
# other variables and keep only two: Income will be our target variable and education will 
# be our predictor variable in the analysis.

# Subset the data to capture only income and education.
newdata = Prestige[,c("education", "income")] # OR newdata = Prestige[,c(1:2)]
summary(newdata)

# Histogram of the variable Education.
qplot(education, data = newdata, geom = "histogram", binwidth = 1) +
  labs(title = "Historgram of Average Years of Education") +
  labs(x = "Average Years of Education") +
  labs(y = "Frequency") +
  scale_y_continuous(breaks = c(1:20), minor_breaks = NULL) +
  scale_x_continuous(breaks = c(6:16), minor_breaks = NULL) +
  geom_vline(xintercept = mean(newdata$education), show.legend = TRUE, color = "red") +
  geom_vline(xintercept = median(newdata$education), show.legend = TRUE, color = "blue")

# Histogram of the variable Income.
qplot(income, data = newdata, geom = "histogram", binwidth = 1000) +
  labs(title = "Historgram of Average Income") +
  labs(x ="Average Income") +
  labs(y = "Frequency") +
  scale_y_continuous(breaks = c(1:20), minor_breaks = NULL) +
  scale_x_continuous(breaks = c(0, 2000, 4000, 6000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 22000, 24000, 26000), minor_breaks = NULL) +
  geom_vline(xintercept = mean(newdata$income), show.legend=TRUE, color="red") +
  geom_vline(xintercept = median(newdata$income), show.legend=TRUE, color="blue")

# Finally, let's draw a scatterplot of both variables to see their relationship:
# Create a plot of the subset data.
qplot(education, income, data = newdata, main = "Relationship between Income and Education") +
  scale_y_continuous(breaks = c(1000, 2000, 4000, 6000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 25000), minor_breaks = NULL) +
  scale_x_continuous(breaks = c(6:16), minor_breaks = NULL)

#we'll fit a linear regression and see how well this model fits the observed data. We want to 
# estimate the relationship and fit a line that explains this relationship.

# fit a linear model and run a summary of its results.
set.seed(1)
education.c = scale(newdata$education, center = TRUE, scale = FALSE)
education.c = as.data.frame(education.c)
names(education.c)[1] = "education.c"
newdata = cbind(newdata, education.c)
mod1 = lm(income ~ education.c, data = newdata)
summary(mod1)

# Let's examine how the fitted line looks like in the scatterplot:
# visualize the model results.
qplot(education.c, income, data = newdata, main = "Relationship between Income and Education") +
  stat_smooth(method = "lm", col="red", se = FALSE) +
  scale_y_continuous(breaks = c(1000, 2000, 4000, 6000, 8000, 10000, 12000, 14000, 16000, 18000, 20000, 25000), minor_breaks = NULL)

# visualize residuals and fitted values.
plot(mod1, pch = 16, which = 1)


# Run the box-cox transform on the model results and pin point the optimal lambda value.
trans = boxcox(mod1)

trans_df = as.data.frame(trans)
optimal_lambda = trans_df[which.max(trans$y), 1]

# Create a new calculated variable based on the optimal lambda value and inspect the new dataframe.
newdata = cbind(newdata, newdata$income ^ optimal_lambda)
names(newdata)[4] = "income_transf"
head(newdata,5)

summary(newdata)

# fit a linear model on the income_transf data and run a summary of its results.
mod2 = lm(income_transf ~ education.c, data = newdata)
summary(mod2)

qplot(income_transf, data = newdata, geom = "histogram", binwidth = 0.5) +
  labs(title = "Historgram of Average Income Transformed by Box-Cox") +
  labs(x ="Average Income") +
  labs(y = "Frequency") +
  geom_vline(xintercept = mean(newdata$income_transf), show.legend = TRUE, color = "red") +
  geom_vline(xintercept = median(newdata$income_transf), show.legend = TRUE, color = "blue")

qplot(education.c, income_transf, data = newdata, main = "Relationship between Income and Education") +
  stat_smooth(method = "lm", se = FALSE) +
  geom_point()

plot(mod2, pch = 16, which = 1)

# run new model with quadratic term.
mod3 = lm(income_transf ~ education.c + I(education.c^2), data = newdata)
summary(mod3)

# plot residuals of the new model.
plot(mod3, pch = 16, which = 1)

# create 100 x-values based on range of plotted values and plot the quadratic line fit.
plot(income_transf ~ education.c, data=newdata, xlab = "education.c", ylab = "income_transf", main = "Quadratic Model Fit of Income and Education")
minmax = range(education.c)
xvals = seq(minmax[1], minmax[2], len = 100)
yvals = predict(mod3, newdata = data.frame(education.c = xvals))
lines(xvals, yvals, col = "red", lwd = 3)







