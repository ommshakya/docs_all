head(mtcars)
mtcars$car = rownames(mtcars)
head(mtcars)

mtcars <- mtcars[, c(12, 1:11)]
head(mtcars)


mtcarsNew <- mtcars %>% gather(attribute, value, -car)
head(mtcarsNew)
tail(mtcarsNew)

mtcarsNew <- mtcars %>% gather(attribute, value, mpg:gear)
head(mtcarsNew)


mtcarsSpred = spread(mtcarsNew, attribute, value)
head(mtcarsSpred)


set.seed(1)
date = as.Date('2017-01-01') + 0:14
hour = sample(1:24, 15)
min = sample(1:60, 15)
sec = sample(1:60, 15)
event = sample(letters, 15)
data = data.frame(date, hour, min, sec, event)
data

dataNew = unite(data, datahour, date, hour, sep = " ")
dataNew = unite(dataNew,datetime, datahour, min, sec, sep = ":")
dataNew


data1 <- dataNew %>% 
  separate(datetime, c('date', 'time'), sep = ' ') %>% 
  separate(time, c('hour', 'min', 'second'), sep = ':')
data1
