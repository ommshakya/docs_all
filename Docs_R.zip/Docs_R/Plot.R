######### Prepare data set to plot ###############

# generate 12 months (integer)
month = c(1:12)

# generate 12 random numeric values with mean = 100 and sd = 20
set.seed(1)
sales = rnorm(12, 100, 5)

# create data set to plot
datatoplot = data.frame(month, sales)

# see first few observations
head(datatoplot)

# see the structure of the data ser
str(datatoplot)

######## now lets explore the plot function ###########

# Example: 1
# lets first try to plot only months
plot(datatoplot$month)

## Result: In graph you can see that it plotted a scatter plot based on the index value of each item from 1 to 12

# Example: 2
# lets try to plot the sales only
plot(datatoplot$sales)

## Result: It also plotted a scatter plot for each value of sales based on the index

# Examplle: 3
# lets pass both the variables to the plot function
plot(datatoplot$month, datatoplot$sales, "b", main = "sales by month plot for previous year", sub = "sales by month", xlab = "month #", ylab = "sales #")


?plot


require(stats)
head(cars)
plot(cars)
lines(lowess(cars))

plot(sin, -pi, 2*pi)

plot(x <- sort(rnorm(47)), type = "s", main = "plot(x, type = \"s\")")
points(x, cex = .5, col = "dark red")


par()

max.temp


tempdata = data.frame(days = c('sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat'), temp = c(22, 27, 26, 24, 23, 26, 28))
tempdata

par(mfrow = c(1, 2))
days = c('sun', 'mon', 'tue', 'wed', 'thu', 'fri', 'sat')
temp = tempdata$temp
names(temp) = days
temp
barplot(temp, main = 'bar plot of max temperature by day')
pie(temp, main = 'pie chart of max temperature by day', radius = 1)



Temperature <- airquality$Temp
Ozone <- airquality$Ozone

par(mfrow=c(2,2))

hist(Temperature)
boxplot(Temperature, horizontal=TRUE)
hist(Ozone)
boxplot(Ozone, horizontal=TRUE)


# make labels and margins smaller
par(cex=0.7, mai=c(0.1,0.1,0.2,0.1))

Temperature <- airquality$Temp

# define area for the histogram
par(fig=c(0.1,0.7,0.3,0.9))
hist(Temperature)

# define area for the boxplot
par(fig=c(0.8,1,0,1), new=TRUE)
boxplot(Temperature)

# define area for the stripchart
par(fig=c(0.1,0.67,0.1,0.25), new=TRUE)
stripchart(Temperature, method="jitter")

getwd()


jpeg(file="saving_plot1.jpeg")
hist(Temperature, col="darkgreen")
dev.off()


bmp(file="saving_plot3.bmp",
    width=6, height=4, units="in", res=100)
hist(Temperature, col="steelblue")
dev.off()


pdf(file="saving_plot4.pdf")
hist(Temperature, col="violet")
dev.off()



piedata = c(600, 300, 150, 100, 200)
names(piedata) = c('housing', 'food', 'cloths', 'entertainment', 'others')

pie(piedata, labels = names(piedata))
?pie
