# Set the working directory

getwd()
setwd("D:\\Abhishek.R.Training\\ProcureSpend_R\\")
getwd()

#Read the data file
dfRawData = read.csv("RawDataFiles\\Spend_Vis_extract_P10.csv")

#Check the structure of the file, and few records
str(dfRawData)
head(dfRawData)

# ISNULL(PO_NUMBER) || LEN(TRIM(PO_NUMBER)) == 0 || ISNULL(FULL_NAME) || 
# LEN(TRIM(FULL_NAME)) == 0 || ISNULL(PO_ACCOUNT_NUMBER) || LEN(TRIM(PO_ACCOUNT_NUMBER)) == 0 || 
# ISNULL(PO_COST_CENTRE) || LEN(TRIM(PO_COST_CENTRE)) == 0 || ISNULL(SUPPLIER_NUMBER) 
# || LEN(TRIM(SUPPLIER_NUMBER)) == 0
filter = is.na(dfRawData$PO_NUMBER) | dfRawData$FULL_NAME =='' | 
  is.na(dfRawData$PO_ACCOUNT_NUMBER) | dfRawData$PO_COST_CENTRE =='' | dfRawData$SUPPLIER_NUMBER ==''

dfBadRecords = dfRawData[filter,]
str(dfBadRecords)
dfBadRecords[, c("PO_NUMBER", "FULL_NAME", "PO_ACCOUNT_NUMBER", "PO_COST_CENTRE", "SUPPLIER_NUMBER")]

dfGoodRecords = dfRawData[!filter,]
str(dfGoodRecords)
head(dfGoodRecords)

nrow(dfRawData)
nrow(dfBadRecords)
nrow(dfGoodRecords)

dfTargetData = dfGoodRecords

dfDim_Account = unique(dfTargetData[c("PO_ACCOUNT_NUMBER","PO_ACCOUNT_DESCRIPTION")])
#df %>% select(var1, var2) %>% distinct
nrow(dfDim_Account)

dfDim_CostCentre = unique(dfTargetData[c("PO_COST_CENTRE","PO_COST_CENTRE_DESCRIPTION")])
nrow(dfDim_CostCentre)

dfDim_Requestor = unique(dfTargetData[c("FULL_NAME","REQUESTOR_LOCATION")])
nrow(dfDim_Requestor)

library(dplyr) 

# as.Date(as.POSIXct(dist_gbpa_enddate1$dt1, format = "%Y-%m-%d", tz="Asia/Calcutta"), tz="Asia/Calcutta")
# today <- Sys.Date()
# today
# Sys.timezone()

dfDim_GBPA = unique(dfTargetData[c("GBPA_NUMBER","GBPA", "GBPA_LIMIT", "GBPA_END_DATE")])
nrow(dfDim_GBPA)

dfDim_GBPA$GBPA_END_DATE_Modified <- case_when(
  is.na(dfDim_GBPA$GBPA_END_DATE) ~ as.POSIXct(NA),
  is.na(as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%m/%d/%Y")) 
  ~ as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%d-%m-%Y"),
  TRUE ~ as.POSIXct(dfDim_GBPA$GBPA_END_DATE, format = "%m/%d/%Y")
)
dfDim_GBPA$GBPA_END_DATE_Modified <- as.Date(
  as.POSIXct(dfDim_GBPA$GBPA_END_DATE_Modified
             , format = "%Y-%m-%d"
             , tz="Asia/Calcutta")
  , tz="Asia/Calcutta")
#### TO DO:>>> 
#### 1. Remove 'GBPA_END_DATE' column
#### 2. Rename 'GBPA_END_DATE_Modified' to 'GBPA_END_DATE'

#str(dfDim_GBPA)
nrow(dfDim_GBPA)

str(dfTargetData)

dfDim_Supplier = unique(dfTargetData[c("SUPPLIER_NUMBER","VENDOR_NAME", "ADDRESS_LINE1"
                                       , "ADDRESS_LINE2", "ADDRESS_LINE3", "CITY"
                                       ,"ZIP", "COUNTRY", "SUPPLIER_TERMS")])
nrow(dfDim_Supplier)

dfDim_Contract = unique(dfTargetData[c("CONTRACT_NUMBER","CONTRACT", "CONTRACT_LIMIT", "CONTRACT_END_DATE", "LINE_TYPE")])
nrow(dfDim_Contract)


dfDim_Contract$CONTRACT_END_DATE_Modified <- case_when(
  is.na(dfDim_Contract$CONTRACT_END_DATE) ~ as.POSIXct(NA),
  is.na(as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%m/%d/%Y")) 
  ~ as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%d-%m-%Y"),
  TRUE ~ as.POSIXct(dfDim_Contract$CONTRACT_END_DATE, format = "%m/%d/%Y")
)
dfDim_Contract$CONTRACT_END_DATE_Modified <- as.Date(
  as.POSIXct(dfDim_Contract$CONTRACT_END_DATE_Modified
             , format = "%Y-%m-%d"
             , tz="Asia/Calcutta")
  , tz="Asia/Calcutta")

nrow(dfDim_Contract)
#unique(dfDim_Contract[c("CONTRACT_END_DATE")])
#### TO DO:>>> 
#### 1. Remove 'GBPA_END_DATE' column
#### 2. Rename 'GBPA_END_DATE_Modified' to 'GBPA_END_DATE'

df_Temp_Items <- dfTargetData[c("VENDOR_PRODUCT_NUM", "CATEGORY_1")]

df_Temp_Items$VENDOR_PRODUCT_NUM <- trimws(df_Temp_Items$VENDOR_PRODUCT_NUM)
df_Temp_Items$CATEGORY_1 <- trimws(df_Temp_Items$CATEGORY_1)

df_Temp_Items$VENDOR_PRODUCT_NUM[is.na(df_Temp_Items$VENDOR_PRODUCT_NUM)] <- ''
df_Temp_Items$CATEGORY_1[is.na(df_Temp_Items$CATEGORY_1)] <- ''

df_Temp_Items$ItemNo <- case_when(
  df_Temp_Items$VENDOR_PRODUCT_NUM == '' & df_Temp_Items$CATEGORY_1 != '' ~ paste('NA-',df_Temp_Items$CATEGORY_1, sep =""),
  TRUE ~ df_Temp_Items$VENDOR_PRODUCT_NUM
)

df_Temp_Items$VENDOR_PRODUCT_NUM <- toupper(df_Temp_Items$VENDOR_PRODUCT_NUM)
df_Temp_Items$CATEGORY_1 <- toupper(df_Temp_Items$CATEGORY_1)
df_Temp_Items$ItemNo <- toupper(df_Temp_Items$ItemNo)

dfDim_Items_unq <- unique(df_Temp_Items[c("ItemNo", "CATEGORY_1")])

head(dfDim_Items_unq)

#### project dim
str(dfTargetData)

df_Temp_Projects <- dfTargetData[c("PROJECT_NUMBER", "PROJECT_NAME")]
df_Temp_Projects$PROJECT_NUMBER <- toupper(df_Temp_Projects$PROJECT_NUMBER)
df_Temp_Projects$PROJECT_NAME <- toupper(df_Temp_Projects$PROJECT_NAME)

dfDim_Project = unique(df_Temp_Projects[c("PROJECT_NUMBER","PROJECT_NAME")])
nrow(dfDim_Project)


### category dim >>>> working here...
# cat1
df_Temp_cat1 <- dfTargetData[c("CATEGORY_1")]
df_Temp_cat1$CATEGORY_1 <- toupper(df_Temp_cat1$CATEGORY_1)
df_Temp_cat1$CATEGORY_1 <- df_Temp_cat1[order(df_Temp_cat1$CATEGORY_1),]
cat1 = unique(df_Temp_cat1[c("CATEGORY_1")])
cat1$Cat1_ID <- seq.int(nrow(cat1))
str(cat1)

#cat 2
df_Temp_cat2 <- dfTargetData[c("CATEGORY_2", "CATEGORY_1")]
df_Temp_cat2$CATEGORY_2 <- toupper(df_Temp_cat2$CATEGORY_2)
df_Temp_cat2$CATEGORY_1 <- toupper(df_Temp_cat2$CATEGORY_1)
str(df_Temp_cat2)
# now join df_Temp_cat2 with cat1 on CATEGORY_1 and take ID of cat1
#$: Inner join: merge(df1, df2) OR merge(df1, df2, by = "CustomerId")
#$: Outer join: merge(x = df1, y = df2, by = "CustomerId", all = TRUE)
#$: Left outer: merge(x = df1, y = df2, by = "CustomerId", all.x = TRUE)
#$: Right outer: merge(x = df1, y = df2, by = "CustomerId", all.y = TRUE)
#$: Cross join: merge(x = df1, y = df2, by = NULL)

# merge two data frames by ID
df_cat2_cat1 <- merge(df_Temp_cat2, cat1, by="CATEGORY_1")[,c("CATEGORY_2","Cat1_ID")]
str(df_cat2_cat1)

df_Temp_cat2 <- df_cat2_cat1[order(df_cat2_cat1$CATEGORY_2),]
str(df_Temp_cat2)
cat2 = unique(df_Temp_cat2[c("CATEGORY_2", "Cat1_ID")])
cat2$cat2_ID <- seq.int(nrow(cat2))
str(cat2)

# cat 3
#select distinct c1.Catgeory1, c2.Cat2Id, c2.Catgeory2  from @Category1 c1 join @Category2 c2 on c1.Cat1Id = c2.Cat1Id

df_middle_qry <- merge(cat1, cat2, by="Cat1_ID")[,c("CATEGORY_1","cat2_ID","CATEGORY_2")]
str(df_middle_qry)

df_Temp_cat3 <- dfTargetData[c("CATEGORY_3", "CATEGORY_2", "CATEGORY_1")]
df_Temp_cat3$CATEGORY_3 <- toupper(df_Temp_cat3$CATEGORY_3)
df_Temp_cat3$CATEGORY_2 <- toupper(df_Temp_cat3$CATEGORY_2)
df_Temp_cat3$CATEGORY_1 <- toupper(df_Temp_cat3$CATEGORY_1)

df_Temp_cat3_middle_qry <- merge(df_Temp_cat3, df_middle_qry, by=c("CATEGORY_1", "CATEGORY_2"))[,c("CATEGORY_3","cat2_ID")]
str(df_Temp_cat3_middle_qry)

df_Temp_cat3 <- df_Temp_cat3_middle_qry[order(df_Temp_cat3_middle_qry$CATEGORY_3),]
str(df_Temp_cat3)
cat3 = unique(df_Temp_cat3[c("CATEGORY_3", "cat2_ID")])
cat3$cat3_ID <- seq.int(nrow(cat3))
str(cat3)

# now join cat1, cat2, and cat3

df_Join_1_2 <- merge(cat1, cat2, by="Cat1_ID")
str(df_Join_1_2)
df_Join_1_2_3 <- merge(df_Join_1_2, cat3, by="cat2_ID")[,c("Cat1_ID", "CATEGORY_1", "cat2_ID", "CATEGORY_2", "cat3_ID", "CATEGORY_3")]
str(df_Join_1_2_3)

dfDim_Category <- df_Join_1_2_3[order(df_Join_1_2_3$Cat1_ID),]
str(dfDim_Category)
nrow(dfDim_Category)

########################### Generate fact ############################
########################### Step 1: Select target data with transformed columns ######
df_TargetDataForFact = dfTargetData
str(df_TargetDataForFact)

# require("sqldf")
# head(dfRawData)
# str(dfRawData)
# 
# d <- sqldf("select COMMODITY, GBPA_NUMBER, GBPA_NUMBER/2 AS CONT, UPPER(LINE_TYPE) AS LINE_TYPE FROM dfRawData")
# head(d)
# str(d)



