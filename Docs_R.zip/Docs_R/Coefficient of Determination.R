#Problem
#Find the coefficient of determination for the simple linear regression model of the data set faithful.

eruption.lm = lm(eruptions ~ waiting, data=faithful)
model_summary = summary(eruption.lm)

model_summary
model_summary$r.squared     #equivalent to summary(eruption.lm)$r.squared 

############# OR ################

eruption.lm = lm(eruptions ~ waiting, data=faithful)
summary(eruption.lm)$r.squared

help(summary.lm)
