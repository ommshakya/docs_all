# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
# # 1. Set the working directory in the 'setwd' command below to the path where the code is placed
# # 2. Make a folder 'Input' in the working directory 
# # 3. Place the 'Packages' folder in the working directory
# # 4. Run the code
# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#

# # Setting working directory

setwd("Z:/Depository/424-US-SPR-Ryder/18226##Data Analytics Support/Next Best Offer project/NBO_MDM")

# this will remove any Output/Datasets named folder on the working directory

#unlink( paste(getwd(),"/Output",sep = ""), recursive = TRUE,force = TRUE )

#unlink( paste(getwd(),"/Datasets",sep = ""), recursive = TRUE,force = TRUE )

dir.create(path = paste(getwd(),"/Output",sep = ""))

dir.create(path = paste(getwd(),"/Datasets",sep = ""))

dir.create(path = paste(getwd(),"/Output/Active",sep = ""))

dir.create(path = paste(getwd(),"/Output/Inactive",sep = ""))


# # # Installing packages if not already installed
packages_required <- c("RODBC", "arules", "dplyr", "magrittr", "tidyr","data.table")
if (length(setdiff(packages_required, rownames(installed.packages()))) > 0) {
  install.packages(paste(getwd(),"/Packages/",setdiff(packages_required, rownames(installed.packages()))
                         ,".zip",sep="")
                   ,repos=NULL,type='binary')
}

# # # Loading Packages
library(RODBC)
library(arules)
library(dplyr)
library(magrittr)
library(tidyr)
library(data.table)
library(stringr)
library(reshape2)
Sys.time()

rm(packages_required)
# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
# #------------------------------- IMPORTING AND CONSOLIDATING ---------------------------#
# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#

# # #Creating a connection string for SQL Server
# channel <- odbcDriverConnect("Driver={SQL Server}; Server=SSCBPBIAMSQL02; Database=Marketing; trusted_connection=yes")
# 
# #Importing data (this might take some time)
# datamart <- sqlQuery(channel, "SELECT * FROM tb_EnterpriseDataSet_ForNBO_TSC_11_02_16")

RawFilesDir="Z:/Depository/424-US-SPR-Ryder/18226##Data Analytics Support/Next Best Offer project/NBO_MDM/Input" 
RdatasetDir="Z:/Depository/424-US-SPR-Ryder/18226##Data Analytics Support/Next Best Offer project/NBO_MDM/Datasets"
dataStartYr=1
########
## RawFilesDir - Containes Raw Data files for each year in .xlsx format  
## RdatasetDir - writes r datasets into this folder
## dataStartYr - starting year of data availability
########

setwd(RawFilesDir)
for (z in 1:length(list.files())){
  tempData<-openxlsx::read.xlsx(xlsxFile=list.files()[z],sheet=1)
  gc()
  xi<-dataStartYr-1+z
  saveRDS(tempData,paste(RdatasetDir,"/Month_",xi,sep=""))
  rm(tempData)
  gc() 
}


datamart <-NULL

# loop to read the R datasets and combine
for (z in 1:length(list.files(RdatasetDir))){
  xi<-dataStartYr-1+z
  tempData<-readRDS(paste(RdatasetDir,"/Month_",xi,sep=""))
  assign(paste("temp_",xi,sep = ""),tempData)
  gc()
  datamart<-rbind(datamart,tempData)
  rm(tempData)
}
  
for (z in 1:length(list.files(RdatasetDir))) {
  xi<-dataStartYr-1+z
  rm(list =  paste("temp_",xi,sep = ""))
}

# # Setting working directory

setwd("Z:/Depository/424-US-SPR-Ryder/18226##Data Analytics Support/Next Best Offer project/NBO_MDM")

#save(datamart,file = "Datasets/datamart.Rdata")

#importing enterprise names file

enterprise_names <- read.csv(file = "Revenue Transaction number.csv")

enterprise_names$Revenue <- enterprise_names$Total.Revenue+enterprise_names$UVS.Proceeds

top_rev_names <-enterprise_names %>%
  group_by(Revenue.Transaction.Customer.Nbr)%>%
  arrange(Revenue.Transaction.Customer.Nbr,-Revenue)%>%
  top_n(n=1,wt=Revenue)


# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
# #----------------------------------- DATA PREPROCESSING --------------------------------#
# #xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#

load(file = "Datasets/datamart.Rdata")
datamart<- filter(datamart,!is.na(Customer.MDM.ID))
datamart$Year <-str_sub(datamart$Financial.Accounting.Year,-4,-1) 
datamart$Financial.Accounting.Year<- NULL

datamart$Month <- trimws(gsub("[0-9]","",datamart$Financial.Accounting.Month))
datamart$MonthStart <- paste("01","-",datamart$Month,"-",datamart$Year,sep = "")
datamart$MonthStart <- as.Date(datamart$MonthStart, format = "%d-%B-%Y")
datamart$Month<-NULL


Datamart_final<- datamart
rm(datamart,RawFilesDir,dataStartYr,RdatasetDir,xi,z)

Datamart_final$Enterprise_Name_cleaned =Datamart_final$Customer.MDM.ID
Datamart_final<- filter(Datamart_final,Hyperion.Product.Line!="CONTRACT RELATED MAINTENANCE")
#save(Datamart_final,file ="Datasets/Datamart_final.Rdata")
#load(file = "Datasets/Datamart_final.Rdata")
#product names list
product_names <- as.data.frame(unique(Datamart_final$Hyperion.Sub.Product.Line.Nm))
product_names$Hyperion.Sub.Product.Line.Nm <- product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`
product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`<-NULL


# importing location file
location_codes <- read.csv(file = "location-hierachy.csv")
location_codes$Financial.Domicile.Location<-as.character(location_codes$Financial.Domicile.Location)
#unique list of customers and locations

cust_locations <- Datamart_final %>% select(Enterprise_Name_cleaned,Financial.Domicile.Location)%>% distinct()

cust_locations_1 <- left_join(cust_locations,location_codes,by="Financial.Domicile.Location")

cust_locations_1 <- filter(cust_locations_1,!is.na(Hyperion.Domicile.Country))%>% 
  select(Enterprise_Name_cleaned,Hyperion.Domicile.Country)%>%
  distinct()

cust_loc_counts <- cust_locations_1%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(loc_count=n_distinct(Hyperion.Domicile.Country))

cust_loc_counts_1 <- filter(cust_loc_counts,loc_count==1)

cust_loc_counts_1<- left_join(cust_loc_counts_1,cust_locations_1,by="Enterprise_Name_cleaned")

cust_loc_counts_2<-filter(cust_loc_counts,loc_count==2)

cust_loc_counts_2$Hyperion.Domicile.Country="USA/Canada"

final_location<- rbind(cust_loc_counts_2,cust_loc_counts_1)

rm(cust_loc_counts_2,cust_loc_counts_1,cust_loc_counts,cust_locations,location_codes,cust_locations_1)

#------Grouping at MDM ID level

Datamart_final$Financial.Domicile.Location <- as.factor(Datamart_final$Financial.Domicile.Location)

Datamart_final$Revenue = Datamart_final$Total.Revenue+Datamart_final$UVS.Proceeds

Enterprise_level=Datamart_final%>%group_by(Enterprise_Name_cleaned) %>%
  summarise(Final_AnnualSalesRevenue_Used=max(Company.Annual.Sales.Volume,na.rm=TRUE),
            Revenue=sum(Revenue,na.rm=TRUE),
            Location_count=n_distinct(Financial.Domicile.Location),
            contract_count=n_distinct(Revenue.Transaction.Customer.Nbr))

Enterprise_Industry <- Datamart_final %>%
    group_by(Enterprise_Name_cleaned,Marketing.Industry.Grp.Vertical) %>%
    select(Enterprise_Name_cleaned,Marketing.Industry.Grp.Vertical,Revenue) %>%
    summarise(Revenue_Enterprise_SIC_grouped=sum(Revenue))%>%
    arrange(Enterprise_Name_cleaned,-Revenue_Enterprise_SIC_grouped)%>%
    top_n(n=1,wt=Revenue_Enterprise_SIC_grouped) %>%
    #top_n(n=1,wt=as.numeric(Ryder_SF_FIS_DTSSCS_SIC_4Char)) %>%
    select(Enterprise_Name_cleaned,Marketing.Industry.Grp.Vertical)
  
Enterprise_Industry<-Enterprise_Industry[!duplicated(Enterprise_Industry[1]),]
# Enterprise_level_categorical <- Datamart_final %>%
#   group_by(Enterprise_Name_cleaned) %>%
#   mutate (ToprevSic_Industry_Vertical_grouped=
#             as.factor(ifelse(length(unique(na.omit(Marketing.Industry.Grp.Vertical)))==1,as.character(unique(na.omit(Marketing.Industry.Grp.Vertical))[[1]]),
#                              ifelse(length(unique(na.omit(Marketing.Industry.Grp.Vertical)))==0,NA,"Multiple"))))%>%
#   distinct(ToprevSic_Industry_Vertical_grouped)
# 
 Enterprise_level <- left_join(Enterprise_level,Enterprise_Industry,by="Enterprise_Name_cleaned")

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx
#top product by revenue last 12 months
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
max_date=max(Datamart_final$MonthStart)

Product_revenue_12 <- Datamart_final %>%
  filter(MonthStart>seq(max_date,length=2, by="-12 months")[2])%>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm)%>%
  summarise(Revenue=sum(Revenue,na.rm=TRUE))%>%
  spread(Hyperion.Sub.Product.Line.Nm,Revenue,fill=0)

Enterprise_level <- left_join(Enterprise_level,Product_revenue_12,by="Enterprise_Name_cleaned")

# revenue top product

Enterprise_level$rev_top_product <-apply(Enterprise_level[as.character(product_names$Hyperion.Sub.Product.Line.Nm)],1,max,na.rm= TRUE)



# Duration from first purchase of the customer (for the period of 2014-till date)
Datamart_final <- as.data.frame(Datamart_final)
Enterprise_additional_15 <- Datamart_final%>% group_by(Enterprise_Name_cleaned)%>%
  select(Enterprise_Name_cleaned,MonthStart)%>%
  summarise(First_engagement_date= min(MonthStart))

end_date <- max(Datamart_final$MonthStart)

Enterprise_additional_15$duration = sapply(Enterprise_additional_15$First_engagement_date,function(start_date) {
  ed <- as.POSIXlt(end_date)
  sd <- as.POSIXlt(start_date)
  12 * (ed$year - sd$year) + (ed$mon - sd$mon)
})
Enterprise_additional_15$First_engagement_date<-NULL

Enterprise_level<-left_join(Enterprise_level, Enterprise_additional_15,by=("Enterprise_Name_cleaned"))

rm(end_date,Enterprise_additional_15)

# Time from last transaction of the customer
Datamart_final <- as.data.frame(Datamart_final)
Enterprise_additional_16 <- Datamart_final%>% group_by(Enterprise_Name_cleaned)%>%
  select(Enterprise_Name_cleaned,MonthStart)%>%
  summarise(last_engagment_date= max(MonthStart))

end_date <- max(Datamart_final$MonthStart)

Enterprise_additional_16$months_from_last_engagment = sapply(Enterprise_additional_16$last_engagment_date,
                                                             function(start_date) {
                                                               ed <- as.POSIXlt(end_date)
                                                               sd <- as.POSIXlt(start_date)
                                                               12 * (ed$year - sd$year) + (ed$mon - sd$mon)})
Enterprise_additional_16$last_engagment_date<-NULL
Enterprise_level<-left_join(Enterprise_level, Enterprise_additional_16,by=("Enterprise_Name_cleaned"))
rm(end_date,Enterprise_additional_16)


# No of engagment months of customer (for the period of 2014-till date)
Engagement_months <- Datamart_final %>%
  group_by(Enterprise_Name_cleaned,MonthStart) %>%
  distinct() %>%
  arrange(Enterprise_Name_cleaned,MonthStart) %>%
  group_by(Enterprise_Name_cleaned) %>%
  summarise(No_of_months=length(Enterprise_Name_cleaned))

Enterprise_level<-left_join(Enterprise_level, Engagement_months,by=("Enterprise_Name_cleaned"))

rm(Engagement_months)


# Calculating products with revenue at enterprise level (in the last 12 months)

revenue_filter <- Datamart_final %>%
  filter(MonthStart > (seq(max(Datamart_final$MonthStart), by= "-12 month",length.out=2))[2])%>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm)%>%
  summarise(count=n_distinct(MonthStart))%>%
  spread(Hyperion.Sub.Product.Line.Nm,count,0)

revenue_filter$product_revenue_1000 <- rowSums(revenue_filter[,-1] != 0)


# Joining
Enterprise_level <- left_join(Enterprise_level,revenue_filter[,c("Enterprise_Name_cleaned","product_revenue_1000")],by= "Enterprise_Name_cleaned")
Enterprise_level[is.na(Enterprise_level$product_revenue_1000) ,'product_revenue_1000']<-0
Enterprise_level$product_revenue_1000=as.factor(Enterprise_level$product_revenue_1000)

#--------------------Ryder Fleet Counts and Market Power Fleet Count--------------------#
# 
# Ryder Fleet Count for latest month for each lessee
fleet_count <- Datamart_final%>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  summarise(Ryder_MonthlyFleetCnt= sum(Active.Fleet.Cnt,na.rm=TRUE))%>%
            arrange(Enterprise_Name_cleaned,desc(MonthStart))%>%
            top_n(n=1,wt=MonthStart)
Enterprise_level <- left_join(Enterprise_level,fleet_count,by="Enterprise_Name_cleaned")
 
# # # Market power fleet count
# power_fleet <- Datamart_final %>%
#   group_by(Enterprise_Name_cleaned)%>%
#   summarise(MarketPower_FleetCnt= max(Market_power_unit_cnt,na.rm=TRUE))
# 

# Enterprise_level <- left_join(Enterprise_level,power_fleet,by="Enterprise_Name_cleaned")
# 
# ----------------------------Active customer flag
# Customers present in the last month and having a min revenue of $100
# Datamart_final<-as.data.frame(Datamart_final)
# active_customers <- Datamart_final %>% filter(MonthStart== max(Datamart_final$MonthStart))%>%
#   group_by(Enterprise_Name_cleaned)%>%
#   summarise(Monthly_revenue = sum(Revenue,na.rm=TRUE))%>%
#   filter(Monthly_revenue>=100)
# 
# active_customers$active_customers_flag <- "Active"
# active_customers$Monthly_revenue<- NULL
# 
# # Joining flag with the masterfile
# Enterprise_level <-left_join(Enterprise_level,active_customers,by="Enterprise_Name_cleaned")
# Enterprise_level[is.na(Enterprise_level$active_customers_flag) ,'active_customers_flag']<-"Inactive"


save(Enterprise_level,file = "Datasets/EL.RData")
save(Datamart_final,file="Datasets/DF.RData")

###FOR EDA ONLy
# dedicated trend

dedicated_customers <- filter(Datamart_final,Hyperion.Product.Line=="RYDER DEDICATED")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

dedicated_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% (dedicated_customers$Enterprise_Name_cleaned))

dedicated_time_line <- dedicated_data %>% select(Enterprise_Name_cleaned,MonthStart,Hyperion.Product.Line)%>%distinct()

x=aggregate(Hyperion.Product.Line ~ Enterprise_Name_cleaned+MonthStart, data = dedicated_time_line, c)

x$Hyperion.Product.Line <- vapply(x$Hyperion.Product.Line, paste, collapse = ", ", character(1L))

test <- spread(x,key = MonthStart,value = Hyperion.Product.Line,fill = NA)

#dcast(DT.m1, family_id + age_mother ~ child, value.var = "dob")

check_filter <- dedicated_data%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(Unique_products_purchased = n_distinct(Hyperion.Product.Line))

dedicated_customers_pattern <-left_join(test,check_filter,by="Enterprise_Name_cleaned")

Product_package <- Datamart_final %>%
  filter(Enterprise_Name_cleaned %in% dedicated_customers_pattern$Enterprise_Name_cleaned)%>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  arrange(MonthStart,Enterprise_Name_cleaned) %>%
  mutate(Dummy_col=1) %>%
  spread(Hyperion.Sub.Product.Line.Nm,Dummy_col,fill=0)

Product_package$Package=apply(Product_package[,!names(Product_package) %in% 
                                                c('MonthStart','Enterprise_Name_cleaned')], 1,
                              function(x) names(which(x=="1")))

# First Product Package
Enterprise_additional_8 <- Product_package %>%
  group_by(Enterprise_Name_cleaned) %>%
  arrange(Enterprise_Name_cleaned,MonthStart) %>%
  filter(row_number()==1)

colnames(Enterprise_additional_8) <- paste("First_Product", colnames(Enterprise_additional_8), sep = "_")

dedicated_customers_pattern<-left_join(dedicated_customers_pattern,Enterprise_additional_8 ,by=c("Enterprise_Name_cleaned"="First_Product_Enterprise_Name_cleaned"))

dedicated_customers_pattern$First_Product_Package <- vapply(dedicated_customers_pattern$First_Product_Package, paste, collapse = ", ", character(1L))

lease_to_dts <- filter(dedicated_customers_pattern,(`First_Product_RYDER DEDICATED`==0)& 
                         (`First_Product_CHOICE LEASE`==1))
lease_avg_rev <-Datamart_final%>% filter(Enterprise_Name_cleaned %in% lease_to_dts$Enterprise_Name_cleaned)%>% 
  filter(Hyperion.Sub.Product.Line.Nm=="CHOICE LEASE")%>%
  group_by(Enterprise_Name_cleaned)%>%
  summarise(months=n_distinct(MonthStart),
            revenue= sum(Total.Revenue,na.rm=T))%>%
  mutate(mean_rev=revenue/months)


write.csv(dedicated_customers_pattern,file ="dedicated_customers_v31july.csv" )



# SCS trend

scs_customers <- filter(Datamart_final,Hyperion.Product.Line=="SUPPLY CHAIN")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

scs_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% (scs_customers$Enterprise_Name_cleaned))

scs_time_line <- scs_data %>% select(Enterprise_Name_cleaned,MonthStart,Hyperion.Product.Line)%>%distinct()

x=aggregate(Hyperion.Product.Line ~ Enterprise_Name_cleaned+MonthStart, data = scs_time_line, c)

x$Hyperion.Product.Line <- vapply(x$Hyperion.Product.Line, paste, collapse = ", ", character(1L))

test <- spread(x,key = MonthStart,value = Hyperion.Product.Line,fill = NA)

#dcast(DT.m1, family_id + age_mother ~ child, value.var = "dob")

check_filter <- scs_data%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(Unique_products_purchased = n_distinct(Hyperion.Product.Line))

scs_customers_pattern <-left_join(test,check_filter,by="Enterprise_Name_cleaned")

# lease_uvs customers
lease_customers  <- filter(Datamart_final,Hyperion.Product.Line=="CHOICE LEASE")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

uvs_customers  <- filter(Datamart_final,Hyperion.Product.Line=="UVS")%>%
  select(Enterprise_Name_cleaned)%>% distinct()


lease_uvs_customers <- inner_join(lease_customers,uvs_customers,by="Enterprise_Name_cleaned")


#  trend

lease_uvs_customers_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% 
                                     (lease_uvs_customers$Enterprise_Name_cleaned) & 
                                     (Hyperion.Product.Line=="CHOICE LEASE" | Hyperion.Product.Line=="UVS"))

lease_uvs_customers_time_line <- lease_uvs_customers_data %>% select(Enterprise_Name_cleaned,MonthStart,Hyperion.Product.Line)%>%distinct()

x=aggregate(Hyperion.Product.Line ~ Enterprise_Name_cleaned+MonthStart, data = lease_uvs_customers_time_line, c)

x$Hyperion.Product.Line <- vapply(x$Hyperion.Product.Line, paste, collapse = ", ", character(1L))

test <- spread(x,key = MonthStart,value = Hyperion.Product.Line,fill = NA)

#dcast(DT.m1, family_id + age_mother ~ child, value.var = "dob")

check_filter <- lease_uvs_customers_data%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(Unique_products_purchased = n_distinct(Hyperion.Product.Line))

lease_uvs_customers_pattern <-left_join(test,check_filter,by="Enterprise_Name_cleaned")

# Rental_uvs customers
rental_customers  <- filter(Datamart_final,Hyperion.Product.Line=="COMMERCIAL RENTAL")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

uvs_customers  <- filter(Datamart_final,Hyperion.Product.Line=="UVS")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

rental_uvs_customers <- inner_join(rental_customers,uvs_customers,by="Enterprise_Name_cleaned")


#  trend

rental_uvs_customers_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% 
                                     (rental_uvs_customers$Enterprise_Name_cleaned) & 
                                     (Hyperion.Product.Line=="COMMERCIAL RENTAL" | Hyperion.Product.Line=="UVS"))

rental_uvs_customers_time_line <- rental_uvs_customers_data %>% select(Enterprise_Name_cleaned,MonthStart,Hyperion.Product.Line)%>%distinct()

x=aggregate(Hyperion.Product.Line ~ Enterprise_Name_cleaned+MonthStart, data = rental_uvs_customers_time_line, c)

x$Hyperion.Product.Line <- vapply(x$Hyperion.Product.Line, paste, collapse = ", ", character(1L))

test <- spread(x,key = MonthStart,value = Hyperion.Product.Line,fill = NA)

#dcast(DT.m1, family_id + age_mother ~ child, value.var = "dob")

check_filter <- rental_uvs_customers_data%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(Unique_products_purchased = n_distinct(Hyperion.Product.Line))

rental_uvs_customers_pattern <-left_join(test,check_filter,by="Enterprise_Name_cleaned")

uvs_customer_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% 
                                      (uvs_customers$Enterprise_Name_cleaned))

number_of_products <- uvs_customer_data %>% group_by(Enterprise_Name_cleaned)%>%
  summarise(count=n_distinct(Hyperion.Product.Line))


# loading name_roll_up file

name_roll_up <- read.csv(file="Name_roll_up.csv")

name_roll_up$Revenue <- name_roll_up$Total.Revenue+name_roll_up$UVS.Proceeds

name_roll_up$key <- paste(name_roll_up$Marketing.Enterprise.Customer.Nm,name_roll_up$Standardized.Customer.Nm,
                          name_roll_up$Customer.MDM.ID,name_roll_up$Revenue.Transaction.Customer.Nbr)

check <- name_roll_up[duplicated(name_roll_up$key),]

test<- name_roll_up %>%
group_by(Revenue.Transaction.Customer.Nbr,Customer.MDM.ID)%>%
summarise(count= n_distinct(Marketing.Enterprise.Customer.Nm),
          count1=n_distinct(Standardized.Customer.Nm))

top_rev_names <-name_roll_up %>%
  group_by(Revenue.Transaction.Customer.Nbr,Customer.MDM.ID,Standardized.Customer.Nm,Marketing.Enterprise.Customer.Nm)%>%
  summarise(Revenue=sum(Revenue,na.rm=T))%>%
  group_by(Revenue.Transaction.Customer.Nbr,Customer.MDM.ID)%>%
  arrange(Revenue.Transaction.Customer.Nbr,Customer.MDM.ID,-Revenue)%>%
  top_n(n=1,wt=Revenue)

top_rev_names_2 <-name_roll_up %>%
  group_by(Revenue.Transaction.Customer.Nbr,Customer.MDM.ID,Standardized.Customer.Nm,Marketing.Enterprise.Customer.Nm)%>%
  summarise(Revenue=sum(Revenue,na.rm=T))



top_rev_names$key <- paste(top_rev_names$Marketing.Enterprise.Customer.Nm,top_rev_names$Standardized.Customer.Nm,
                           top_rev_names$Customer.MDM.ID,top_rev_names$Revenue.Transaction.Customer.Nbr)

test <- anti_join(name_roll_up,top_rev_names,by="key")



# uvs
uvs_customers  <- filter(Datamart_final,Hyperion.Product.Line=="UVS" & 
              MonthStart > (seq(max(Datamart_final$MonthStart), by= "-30 month",length.out=2)[2]))%>%
  select(Enterprise_Name_cleaned)%>% distinct()

uvs_customer_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% 
                              (uvs_customers$Enterprise_Name_cleaned))

number_of_products <- uvs_customer_data %>% group_by(Enterprise_Name_cleaned)%>%
  summarise(count=n_distinct(Hyperion.Product.Line))


#-------------Company - Product Average Gap
Average_product_gap <- Datamart_final %>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  arrange(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm,MonthStart) %>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm) %>%
  mutate(from_date=lag(MonthStart),to_date=MonthStart) %>%
  group_by(Enterprise_Name_cleaned,MonthStart,Hyperion.Sub.Product.Line.Nm) %>%
  mutate(Company_product_ave_gap=ifelse(is.na(from_date),NA,length(seq(from=from_date,to=to_date,by='month'))-1)) %>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm) %>%
  summarise(Company_product_ave_gap=mean(Company_product_ave_gap,na.rm=TRUE)) %>%
  spread(Hyperion.Sub.Product.Line.Nm,Company_product_ave_gap,fill=NA)


average_uvs_gap <- left_join(Clusters, Average_product_gap[,c("USED VEHICLE SALES","Enterprise_Name_cleaned")]
                                                           ,by="Enterprise_Name_cleaned")
average_uvs_gap <- left_join(average_uvs_gap,Product_last_6,by="Enterprise_Name_cleaned")

