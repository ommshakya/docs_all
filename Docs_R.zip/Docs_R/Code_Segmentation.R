
install.packages("randomForest")
# Loading Packages
library(RODBC)
library(arules)
library(dplyr)
library(magrittr)
library(tidyr)
library(randomForest)
setwd(Set_working_directory_Flag)
 
load(file = "Datasets/EL.RData")
load(file = "Datasets/DF.RData")

#product names list
product_names <- as.data.frame(unique(Datamart_final$Hyperion.Sub.Product.Line.Nm))
product_names$Hyperion.Sub.Product.Line.Nm <- product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`
product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`<-NULL


#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
#----------------------------- DATA PREPARATION FOR SEGMENTATION ------------------------#
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
# Factors to numeric for k-means
Enterprise_level$No_of_months=as.numeric(Enterprise_level$No_of_months)
Enterprise_level$product_revenue_1000= as.numeric(as.character(Enterprise_level$product_revenue_1000))
# removing enterprises with no revenue

Enterprise_level <-  filter(Enterprise_level,!is.infinite(rev_top_product) & rev_top_product>0 )

Enterprise_level <- filter(Enterprise_level,Revenue>0)

  
# validating the variables selected using random forest
test<-lm(Revenue~product_revenue_1000+Location_count+No_of_months+
           rev_top_product+duration+contract_count,Enterprise_level)
summary(test)



#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
#------------------------------------- SEGMENTATION ------------------------------------#
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#

# Standardizing variables used for k-means (selected using Random Forest and regression)
avg <- Enterprise_level[,c('product_revenue_1000','Location_count',
                           'No_of_months','rev_top_product','duration','contract_count')]

Enterprise_level[,c('product_revenue_1000','Location_count',
                    'No_of_months','rev_top_product','duration','contract_count')] <-
  apply(Enterprise_level[,c('product_revenue_1000',
                            'Location_count','No_of_months','rev_top_product','duration','contract_count')],2,as.numeric)

avg=as.data.frame(avg)
avg=as.data.frame(apply(avg,2,as.numeric))

x <- as.data.frame(apply(avg, 2, mean))
y <- as.data.frame(apply(avg, 2, sd))

avg_test <- Enterprise_level %>% mutate(product_revenue_1000_avg = ((product_revenue_1000-x[1,])/y[1,]),
                                        Location_count_avg = ((Location_count-x[2,])/y[2,]),
                                        No_of_months_avg = ((No_of_months-x[3,])/y[3,]),
                                        rev_top_product_avg = ((rev_top_product-x[4,])/y[4,]),
                                        duration_avg=((duration-x[5,])/y[5,]),
                                        contract_count_avg=(contract_count-x[6,]/y[6,]))



Enterprise_level_1 <-Enterprise_level



collist <- colnames(avg)
test_1 <- test


for (i in 1:length(collist)) {
  
  
  Enterprise_level_1$temp = ((Enterprise_level_1[,collist[i]]-x[collist[i],])/y[collist[i],])
  
  names(Enterprise_level_1)[names(Enterprise_level_1) == 'temp'] <- paste(collist[i],"_","norm")
  
}

# Cleaning environment
rm(x)
rm(y)
rm(avg)

#Elbow method - to identify number of segments

wss=0
for (i in 1:10) {
  wss[i] <- sum(kmeans(avg_test[,c('product_revenue_1000_avg','Location_count_avg',
                                   'No_of_months_avg','rev_top_product_avg','duration_avg')],i,
                       algorithm = "MacQueen",iter.max = 250,nstart = 1000)$withinss)
}

plot(2:11, wss[2:11], type="b", xlab="Number of Clusters",
     ylab="Within groups sum of squares")


# K-means Clustering for segmentation
Sys.time()

set.seed(1)
Final_clusters <- kmeans(avg_test[,c('product_revenue_1000_avg','Location_count_avg',
                                     'No_of_months_avg','rev_top_product_avg',
                                     "duration_avg","contract_count_avg")],8,
                         algorithm = "MacQueen",iter.max = 450,nstart = 200000)
avg_test<-as.data.frame(avg_test)

Final_clusters$size
Final_clusters$tot.withinss
centers <-as.data.frame(Final_clusters$centers)

# K-means with sorted centers (to sort segments from best to worst)
centers <- centers %>%
  arrange(desc(rev_top_product_avg),desc(product_revenue_1000_avg),desc(Location_count_avg),
          desc(No_of_months_avg))

Final_clusters <- kmeans(avg_test[,c('product_revenue_1000_avg','Location_count_avg',
                                     'No_of_months_avg','rev_top_product_avg','duration_avg',"contract_count_avg")],centers = centers,
                         algorithm = "MacQueen",iter.max = 250,nstart = 1000)
Final_clusters$size
Final_clusters$tot.withinss

Clusters=cbind(avg_test,as.data.frame(Final_clusters$cluster))
Clusters<-as.data.frame(Clusters)

#load(file = "Input/cluster.RData")
save(Clusters,file = "Datasets/Cluster.RData")
save(Enterprise_level,file = "Datasets/EL.RData")

Sys.time()







Clusters_2<-  Clusters%>%  filter(Enterprise_Name_cleaned %in% c(Offer_upsell$Enterprise_Name_cleaned ))



# segment wise distributions active

active_clusters <- Clusters %>% filter(active_customers_flag=="Active")

inactive_clusters <- Clusters %>% filter(active_customers_flag=="Inactive")

#all customers

segment_distribution <- Clusters_2 %>%
  group_by(Segment_ID) %>%
  summarise(`Number of Enterprises`= n_distinct(Enterprise_Name_cleaned),
            `Average Revenue`= mean(rev_top_product,na.rm=TRUE),
            `Maximum Revenue`=max(Revenue,na.rm=TRUE),
            `Minimum Revenue`=min(Revenue,na.rm=TRUE) ,
            `Average Products with revenue greater than 1000`=mean(product_revenue_1000,na.rm=TRUE),
            `Average Location Count`=mean(Location_count,na.rm=TRUE),
            `Average Duration from First Engagement`=mean(duration,na.rm=TRUE),
            `Average Number of Engagement Months`=mean(No_of_months,na.rm=TRUE))

names(segment_distribution)[names(segment_distribution) == "Final_clusters$cluster"] <- "Segment ID"
#segment_distribution$type ="All"
write.csv(segment_distribution, "Output/Segments.csv")

#Box plots exporting


png(filename = "Output/Revenue.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(Clusters$Revenue~Clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Total Revenue")
dev.off()


png(filename = "Output/Product_1000.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(Clusters$product_revenue_1000~Clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Products with revenue greater than 1000")
dev.off()


png(filename = "Output/Location.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(Clusters$Location_count~Clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Location Count")
dev.off()


png(filename = "Output/No_months.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(Clusters$No_of_months~Clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Number of Engagement Months")
dev.off()

png(filename = "Output/Duration.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(Clusters$duration~Clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Duration from First Engagement")
dev.off()


#--------------active customers

segment_distribution_active <- active_clusters%>%
  group_by(`Final_clusters$cluster`) %>%
  summarise(`Number of Enterprises`= n_distinct(Enterprise_Name_cleaned),
            `Average Revenue`= mean(Revenue,na.rm=TRUE),
            `Maximum Revenue`=max(Revenue,na.rm=TRUE),
            `Minimum Revenue`=min(Revenue,na.rm=TRUE) ,
            `Average Products with revenue greater than 1000`=mean(product_revenue_1000,na.rm=TRUE),
            `Average Location Count`=mean(Location_count,na.rm=TRUE),
            `Average Duration from First Engagement`=mean(duration,na.rm=TRUE),
            `Average Number of Engagement Months`=mean(No_of_months,na.rm=TRUE))

x=as.data.frame(unique(Clusters$`Final_clusters$cluster`))
colnames(x)<-"Final_clusters$cluster"
segment_distribution_active <-left_join(x,segment_distribution_active,
                                        by="Final_clusters$cluster")

segment_distribution_active<- arrange(segment_distribution_active,`Final_clusters$cluster`)
names(segment_distribution_active)[names(segment_distribution_active) == "Final_clusters$cluster"] <- "Segment ID"

write.csv(segment_distribution_active, "Output/Active/Segments_active.csv")

#--------------inactive customers

segment_distribution_inactive <- inactive_clusters%>%
  group_by(`Final_clusters$cluster`) %>%
  summarise(`Number of Enterprises`= n_distinct(Enterprise_Name_cleaned),
            `Average Revenue`= mean(Revenue,na.rm=TRUE),
            `Maximum Revenue`=max(Revenue,na.rm=TRUE),
            `Minimum Revenue`=min(Revenue,na.rm=TRUE) ,
            `Average Products with revenue greater than 1000`=mean(product_revenue_1000,na.rm=TRUE),
            `Average Location Count`=mean(Location_count,na.rm=TRUE),
            `Average Duration from First Engagement`=mean(duration,na.rm=TRUE),
            `Average Number of Engagement Months`=mean(No_of_months,na.rm=TRUE),
            `Average Number of Lessee Contract Count`= mean(Lessee_Contract_count,na.rm=TRUE))

segment_distribution_inactive <-left_join(x,segment_distribution_inactive,
                                          by="Final_clusters$cluster")

segment_distribution_inactive<- arrange(segment_distribution_inactive,`Final_clusters$cluster`)


names(segment_distribution_inactive)[names(segment_distribution_inactive) == "Final_clusters$cluster"] <- "Segment ID"
write.csv(segment_distribution_inactive, "Output/Inactive/Segments_inactive.csv")


#Box plots exporting active

png(filename = "Output/Active/Revenue.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(active_clusters$Revenue~active_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Total Revenue")
dev.off()


png(filename = "Output/Active/Product_1000.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(active_clusters$product_revenue_1000~active_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Products with revenue greater than 1000")
dev.off()


png(filename = "Output/Active/Location.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(active_clusters$Location_count~active_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Location Count")
dev.off()


png(filename = "Output/Active/No_months.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(active_clusters$No_of_months~active_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Number of Engagement Months")
dev.off()


png(filename = "Output/Active/Duration.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(active_clusters$duration~active_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Duration from First Engagement")
dev.off()



#Box plots exporting inactive


png(filename = "Output/Inactive/Revenue.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(inactive_clusters$Revenue~inactive_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Total Revenue")
dev.off()


png(filename = "Output/Inactive/Product_1000.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(inactive_clusters$product_revenue_1000~inactive_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Products with revenue greater than 1000")
dev.off()


png(filename = "Output/Inactive/Location.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(inactive_clusters$Location_count~inactive_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Location Count")
dev.off()


png(filename = "Output/Inactive/No_months.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(inactive_clusters$No_of_months~inactive_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Number of Engagement Months")
dev.off()


png(filename = "Output/Inactive/Duration.png",
    width = 600, height = 480, units = "px", pointsize = 12,
    bg = "white")
boxplot(inactive_clusters$duration~inactive_clusters$`Final_clusters$cluster`,col=c("powderblue","lightgreen","burlywood","lightyellow","cadetblue","grey","white","mistyrose"),main="Duration from First Engagement")
dev.off()

