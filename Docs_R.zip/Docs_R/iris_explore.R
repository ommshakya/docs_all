library(caret)

#### attach the iris dataset to the environment
data("iris")

# rename the dataset locally
dataset = iris

#### create a validation dataset
# split the dataset into 2 parts
# 1. train data (80% of dataset)
# 2. validation data (20% of dataset)

# create a list of 80% of the rows in the original dataset we can use for training
validation_index <- createDataPartition(dataset$Species, p = 0.80, list = FALSE)
?createDataPartition

# select 20% of the data for validation
validation <- dataset[-validation_index,]

# use the remaining 80% of data to training and testing the models
dataset <- dataset[validation_index,]

#### Summarize the dataset
#Look the data

# dimesnion of the dataset
dim(dataset)

## datatypes of attributes
str(dataset)

# OR

sapply(dataset, class)

# view top 6 records
head(dataset)

# Levels of the class
# check the levels of species
levels(dataset$Species)

# class distribution
#  look at the number of instances (rows) that belong to each class. We can view this as 
# an absolute count and as a percentage.

percentage <- prop.table(table(dataset$Species)) * 100
cbind(freq=table(dataset$Species), percentage = percentage)

# statical summary
# summarize attribute
summary(dataset)


#### visualize the dataset

