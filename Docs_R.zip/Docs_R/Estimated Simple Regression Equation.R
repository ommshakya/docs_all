#list down all the default data sets already installed
data()

#check the structure of the 'faithful' data set
str(faithful)

#Problem
#Apply the simple linear regression model for the data set faithful, and estimate the next eruption duration 
#if the waiting time since the last eruption has been 80 minutes.

#generate the linear regression model
eruption.lm = lm(eruptions ~ waiting, data = faithful)
eruption.lm

#summary(eruption.lm)

#extract the coefficients from the model
coeff = coefficients(eruption.lm)
coeff

#We now fit the eruption duration using the estimated regression equation.
waiting = 80       #the waiting time

duration = coeff[1] + coeff[2] * waiting
duration

#Answer
#Based on the simple linear regression model, if the waiting time since the last eruption has been 80 minutes, 
#we expect the next one to last 4.1762 minutes.

#####Alternate solution

#We wrap the waiting parameter value inside a new data frame named newdata.
newdata = data.frame(waiting=80) # wrap the parameter

#Then we apply the predict function to eruption.lm along with newdata.
predict(eruption.lm, newdata)    # apply predict 


