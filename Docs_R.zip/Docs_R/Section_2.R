# Set the working directory

getwd()
setwd("D:\\Abhishek.R.Training\\Udemy.Courses\\R-Course-Advanced")
getwd()

# Read the csv file into a dataframe

# basic: fin <- read.csv("Future-500.csv")
fin <- read.csv("Future-500.csv", na.string=c(""))
head(fin)
tail(fin)
str(fin)
summary(fin)

# Changing from non-factor to factor

fin$ID <- factor(fin$ID)
fin$Inception <- factor(fin$Inception)
str(fin)

# Factor variable trap (FVT) [change factor to other data type]
# convert factor into numeric
a <- factor(c("12","13", "14", "12", "12"))
a
typeof(a)
b <- as.numeric(as.character(a))
typeof(a)

# sub() and gsub()
?sub

fin$Expenses <- gsub(" Dollars", "", fin$Expenses)
fin$Expenses <- gsub(",", "", fin$Expenses)

fin$Revenue <- gsub("\\$", "", fin$Revenue)
fin$Revenue <- gsub(",", "", fin$Revenue)

fin$Growth <- gsub("%", "", fin$Growth)

fin$Expenses <- as.numeric(fin$Expenses)
fin$Revenue <- as.numeric(fin$Revenue)
fin$Growth <- as.numeric(fin$Growth)
str(fin)
summary(fin)

# Dealing with missing data
# 1. Predict with 100 % accuracy
# 2. Leave record as is
# 3. Remove record entirely
# 4. Replace with mean or median
# 5. Fill in by exploring correlations and similarities
# 6. Introduce dummy varianle for Missingness


# What is an NA
?NA

# Locating missing values
fin

head(fin, n = 24)
fin[!complete.cases(fin),]
str(fin)

# Filtering : using which() for non-missing data
head(fin)
fin[fin$Revenue == 9746272, ]

?which
which(fin$Revenue == 9746272)
fin[which(fin$Revenue == 9746272), ]


# Filtering: using is.na() for missing data

a <- c(1, 23, NA, 21, 87, NA)
is.na(a)
a[is.na(a)]
a[!is.na(a)]

is.na(fin$Expenses)
fin[is.na(fin$Expenses), ]

# Removing records with missing data

fin_backup <- fin

fin[!complete.cases(fin), ]
fin[is.na(fin$Industry),]
fin[!is.na(fin$Industry),]

fin <- fin[!is.na(fin$Industry),]
fin


# Resetting the dataframe index

fin

#First way
rownames(fin) <- 1:nrow(fin)
fin

#Second way
rownames(fin) <- NULL
fin

# Replacing missing data: Factual Analysis

fin[!complete.cases(fin), ]

fin[is.na(fin$State),]
fin[is.na(fin$State) & fin$City == "New York",]
fin[is.na(fin$State) & fin$City == "New York", "State"] <- "NY"

fin[c(11, 377),]

fin[!complete.cases(fin), ]

fin[is.na(fin$State) & fin$City == "San Francisco",]
fin[is.na(fin$State) & fin$City == "San Francisco", "State"] <- "CA"
fin[c(82, 265),]

fin[fin$City == "San Francisco",]

# Replacing missing data : Median Imputation Method (Part 1)

fin[!complete.cases(fin), ]
median(fin[, "Employees"], na.rm = TRUE)
med_emp_retail <- median(fin[fin$Industry == "Retail", "Employees"], na.rm = TRUE)
med_emp_retail

fin[is.na(fin$Employees) & fin$Industry == "Retail", "Employees"] <- med_emp_retail
fin[3,]


median(fin[, "Employees"], na.rm = TRUE)
med_emp_finserv <- median(fin[fin$Industry == "Financial Services", "Employees"], na.rm = TRUE)
fin[is.na(fin$Employees) & fin$Industry == "Financial Services",] 
fin[is.na(fin$Employees) & fin$Industry == "Financial Services","Employees"] <- med_emp_finserv
fin[c(330),]



# Replacing missing data : Median Imputation Method (Part 2)


fin[!complete.cases(fin), ]
med_growth_constr <- median(fin[fin$Industry == "Construction", "Growth"], na.rm = TRUE)

med_growth_constr

fin[is.na(fin$Growth) & fin$Industry == "Construction",] 
fin[is.na(fin$Growth) & fin$Industry == "Construction", "Growth"] = med_growth_constr
fin[8,]

fin_backup_2 <- fin
fin <- fin_backup_2

fin[!complete.cases(fin), ]
med_revenue_constr <- median(fin[fin$Industry == "Construction", "Revenue"], na.rm = TRUE)
med_revenue_constr
fin[is.na(fin$Revenue) & fin$Industry == "Construction",] 
fin[is.na(fin$Revenue) & fin$Industry == "Construction", "Revenue"] = med_revenue_constr
fin[c(8,42), ]

fin[!complete.cases(fin), ]
med_exp_constr <- median(fin[fin$Industry == "Construction", "Expenses"], na.rm = TRUE)
med_exp_constr
fin[is.na(fin$Expenses) & fin$Industry == "Construction" & is.na(fin$Profit),] 
fin[is.na(fin$Expenses) & fin$Industry == "Construction" & is.na(fin$Profit), "Expenses"] = med_exp_constr
fin[c(8,42), ]

#fin[!complete.cases(fin), ]
#med_exp_itserv <- median(fin[fin$Industry == "IT Services", "Expenses"], na.rm = TRUE)
fin[is.na(fin$Expenses) & fin$Industry == "IT Services",] 
fin[is.na(fin$Expenses) & fin$Industry == "IT Services", "Expenses"] = med_exp_itserv
#fin[c(15), ]

# Replacing missing data : Median Imputation Method (Part 3)
fin[!complete.cases(fin), ]

# Replacing missing data: driving values
#Revenue - Expenses = Profit
#Expenses - Revenue = Profit
fin[is.na(fin$Profit),"Profit"] <- fin[is.na(fin$Profit),"Revenue"] - fin[is.na(fin$Profit),"Expenses"]
fin[c(8, 42),]

fin[!complete.cases(fin), ]
fin[is.na(fin$Expenses),"Expenses"] <- fin[is.na(fin$Expenses),"Revenue"] - fin[is.na(fin$Expenses),"Profit"]

fin[!complete.cases(fin), ]


# Visualization:
library(ggplot2)
library("ggplot2", lib.loc="~/R/win-library/3.3")
#A scatterplot classified by industry showing revenue, expenses, profit
p <- ggplot(data = fin)
p
p + geom_point(aes(x = Revenue, y = Expenses,
                   colour = Industry, size = Profit))


#A scatterplot that includes industry trends for the expenses~revenue relationship
d <- ggplot(data = fin,aes(x = Revenue, y = Expenses,
                           colour = Industry))
d + geom_point() +
  geom_smooth(fill = NA, size = 1.2)

#BoxPlots showing growth by industry
f <- ggplot(data = fin, aes(x = Industry, y = Growth,
                            colour = Industry))
f + geom_boxplot(size = 1)

#Extra:

f + geom_jitter() +
  geom_boxplot(size = 1, alpha = 0.5, outlier.color = NA)






