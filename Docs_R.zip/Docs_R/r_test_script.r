
sessionInfo()

R.home()
R.home("bin")
.libPaths()