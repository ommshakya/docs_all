# # # Loading Packages
library(RODBC)
library(arules)
library(dplyr)
library(magrittr)
library(tidyr)
# 
# setwd(Set_working_directory_Flag)
# 
load(file = "Datasets/EL.RData")
load(file = "Datasets/DF.RData")
load(file = "Datasets/Cluster.RData")
# 
max_date=max(Datamart_final$MonthStart)
 
 #product names list
 product_names <- as.data.frame(unique(Datamart_final$Hyperion.Sub.Product.Line.Nm))
 product_names$Hyperion.Sub.Product.Line.Nm <- product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`
 product_names$`unique(Datamart_final$Hyperion.Sub.Product.Line.Nm)`<-NULL

 
 # # Removing revenue of each product columns
  Enterprise_level <- Enterprise_level[ ,-which(names(Enterprise_level) %in% as.character(product_names$Hyperion.Sub.Product.Line.Nm))]
  Clusters <- Clusters[ ,-which(names(Clusters) %in% as.character(product_names$Hyperion.Sub.Product.Line.Nm))]
  
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX
#products bought in last 6 months
#XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX

Product_last_6 <- Datamart_final %>%
  filter(MonthStart>seq(max_date,length=2, by="-6 months")[2])%>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm)%>%
  summarise(count= n_distinct(MonthStart))%>%
  spread(Hyperion.Sub.Product.Line.Nm,count,fill="0")

Enterprise_level <- left_join(Enterprise_level,Product_last_6,by="Enterprise_Name_cleaned")

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
#-------------------------------------- ASSOCIATION ------------------------------------#
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
Product_package_all <- Datamart_final %>%
  filter(MonthStart>seq(max_date,length=2, by="-12 months")[2])%>%
    group_by(Enterprise_Name_cleaned) %>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  mutate(Dummy_col=TRUE) %>%
  spread(Hyperion.Sub.Product.Line.Nm,Dummy_col,fill=FALSE)

# Product_package_all <- Datamart_final %>%
#   filter(MonthStart>seq(max_date,length=2, by="-12 months")[2])%>%
#   group_by(Enterprise_Name_cleaned)%>%
#   summarise(Lease=  ifelse(length(unique(MonthStart[LeaseCust_WithRev==1]))>0,TRUE,FALSE),
#             Rental= ifelse(length(unique(MonthStart[Rental_Cust_WithRev==1]))>0,TRUE,FALSE),
#             SCS= ifelse(length(unique(MonthStart[SCS_Cust_WithRev==1]))>0,TRUE,FALSE),
#             dedicated= ifelse(length(unique(MonthStart[DTS_Cust_WithRev==1]))>0,TRUE,FALSE),
#             uvs= ifelse(length(unique(MonthStart[UVS_Cust_WithProceeds==1]))>0,TRUE,FALSE),
#             contract_maint= ifelse(length(unique(MonthStart[Maint_Cust_WithRev==1]))>0,TRUE,FALSE),
#             on_demand= ifelse(length(unique(MonthStart[Ondemand_Cust_WithRev==1]))>0,TRUE,FALSE)) 

Product_package_all=inner_join(Product_package_all,Clusters[,c("Enterprise_Name_cleaned","Final_clusters$cluster")])

Product_package_all[,1] <- NULL
Product_package_all <- as.data.frame(Product_package_all)

for (i in c(1:8)){
  Product_package_all_filter <-Product_package_all %>% filter(`Final_clusters$cluster`==i)
  rules <- apriori(as(as.data.frame(Product_package_all_filter)[,1:(NCOL(Product_package_all)-1)],"transactions"),
                   parameter=list(support =0.01, confidence =0.50, minlen=2,maxlen=3))
  rules<- subset(rules,  subset = lift > 1 & confidence !=1)
  temp=as(rules, "data.frame")
  if(NROW(temp)!=0){
    temp$segmentID = i
    
    support_filter = NROW(Product_package_all_filter)/NROW(Product_package_all)
    temp<- temp %>% filter(support > ifelse(support_filter<0.0015,0.25,ifelse(support_filter>0.0015 & support_filter<0.2,0.1,0.01)))
    temp<- temp %>% top_n(n=ifelse(support_filter<0.0015,nrow(temp)/2,
                                   ifelse(support_filter>0.0015 & support_filter<0.005,0.75*nrow(temp),nrow(temp))),wt=lift)}
  assign(paste("rules_df_",i,sep=""),temp)
}

rules_df_all <- rbind(rules_df_1,rules_df_2,rules_df_3,rules_df_4,rules_df_5,rules_df_6,rules_df_7,rules_df_8)


rm(rules_df_1)
rm(rules_df_2)
rm(rules_df_3)
rm(rules_df_4)
rm(rules_df_5)
rm(rules_df_6)
rm(rules_df_7)
rm(rules_df_8)

# Splitting Rules into 'LHS' and 'RHS' columns
rules_df_list <- data.frame(do.call('rbind', strsplit(as.character(rules_df_all$rules),'=>',fixed=TRUE)))

colnames(rules_df_list)[colnames(rules_df_list)=="X1"] <- "LHS"
colnames(rules_df_list)[colnames(rules_df_list)=="X2"] <- "RHS"

rules_df_list$LHS <- gsub("{","",rules_df_list$LHS,fixed = TRUE)
rules_df_list$LHS <- gsub("}","",rules_df_list$LHS,fixed = TRUE)
rules_df_list$RHS <- gsub("{","",rules_df_list$RHS,fixed = TRUE)
rules_df_list$RHS <- gsub("}","",rules_df_list$RHS,fixed = TRUE)

rules_df<-cbind(rules_df_all,rules_df_list)
rules_df$LHS <-trimws(rules_df$LHS)
rules_df$RHS <-trimws(rules_df$RHS)

rm(Product_package_all_filter,rules_df_list,rules_df_all,temp,Product_package_all)

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
#----------------------------------- SELECTION OF NBO ----------------------------------#
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#

# Changing Column name
names(Clusters)[names(Clusters) == "Final_clusters$cluster"] <- "Segment_ID"

# Getting Product Composition (Package) for each customer for the last six months
Product_package_all <- Datamart_final %>%
  filter(MonthStart>seq(max_date,length=2, by="-6 months")[2])%>%
  group_by(Enterprise_Name_cleaned) %>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  mutate(Dummy_col=TRUE) %>%
  spread(Hyperion.Sub.Product.Line.Nm,Dummy_col,fill=FALSE)


# Product_package_all <- Datamart_final %>%
#   filter(MonthStart>seq(max_date,length=2, by="-6 months")[2])%>%
#   group_by(Enterprise_Name_cleaned)%>%
#   summarise(Lease=  ifelse(length(unique(MonthStart[LeaseCust_WithRev==1]))>0,TRUE,FALSE),
#             Rental= ifelse(length(unique(MonthStart[Rental_Cust_WithRev==1]))>0,TRUE,FALSE),
#             SCS= ifelse(length(unique(MonthStart[SCS_Cust_WithRev==1]))>0,TRUE,FALSE),
#             dedicated= ifelse(length(unique(MonthStart[DTS_Cust_WithRev==1]))>0,TRUE,FALSE),
#             uvs= ifelse(length(unique(MonthStart[UVS_Cust_WithProceeds==1]))>0,TRUE,FALSE),
#             contract_maint= ifelse(length(unique(MonthStart[Maint_Cust_WithRev==1]))>0,TRUE,FALSE),
#             on_demand= ifelse(length(unique(MonthStart[Ondemand_Cust_WithRev==1]))>0,TRUE,FALSE)) 

# Joining Segment ID
Product_package_all <- inner_join(Product_package_all,Clusters[,c("Enterprise_Name_cleaned","Segment_ID")])
Product_package_all <- as.data.frame(Product_package_all)

# Creating data frame for filling up offers obtained from association
Offer_association=select(Product_package_all,Enterprise_Name_cleaned)
Offer_association$NBO_Association <- NA
Offer_association$From <- NA
Offer_association$To <-NA

#------------- Suggestion of NBO for customers who bought some (but not all) -----------#
#------------------------------ of the associated products -----------------------------#

#------------ The first for-loop is for going through each segment & the second --------#
#-------------- for-loop is for going through all the rules for the segment ------------#

for (Loop_segment_no in c(1:8)){
  
  # Filtering product package for selected segment
  Product_package_all_filter <-Product_package_all %>%
    filter(Segment_ID==Loop_segment_no)
  
  # Filtering rules for the selected segment and sorting by lift
  rules_df_filter <- rules_df %>%
    filter(segmentID==Loop_segment_no) %>%
    arrange(desc(lift),desc(confidence),desc(support))
  
  # Filtering enterprises for the selected segment
  Enterprise_filter <- Product_package_all %>%
    select(Enterprise_Name_cleaned,Segment_ID) %>%
    filter(Segment_ID==Loop_segment_no)
  
  # Converting product package data to 'transactions' type and back to 'data frame' to
  # get product compostition in apriori readable format
  transactions <- as(as.data.frame(Product_package_all_filter)[,2:(NCOL(Product_package_all)-1)],"transactions")
  itemsetInfo(transactions) <- as.data.frame(Product_package_all_filter[,1])
  transactions_df<-as(transactions, "data.frame")
  colnames(transactions_df)[colnames(transactions_df)=="Product_package_all_filter[, 1]"]<- "Enterprise_Name_cleaned"
  
  for (Loop_rule_no in c(1:NROW(rules_df_filter))){
    
    if(NROW(rules_df_filter)!=0){
      
      # Filtering the customers with the product composition on the left side of the rule
      # but never bought the product on the right side of the rule
      ifelse(length(as.list(strsplit(trimws(rules_df_filter[Loop_rule_no,'LHS']), ","))[[1]]) ==1,
             
             (Cust_association=subset(transactions_df, grepl(paste("\\<",paste(trimws(rules_df_filter[Loop_rule_no,'LHS'])),"\\>",sep="")
                                                             ,transactions_df$items)
                                      & !(grepl(paste("\\<",paste(trimws(rules_df_filter[Loop_rule_no,'RHS'])),"\\>",sep=""),transactions_df$items)))),
             
             (Cust_association=subset(transactions_df, grepl(paste("\\<",paste(as.list(strsplit(trimws(rules_df_filter[Loop_rule_no,'LHS']), ","))[[1]][1]),"\\>",sep="")
                                                             ,transactions_df$items)
                                      & grepl(paste("\\<",paste(as.list(strsplit(trimws(rules_df_filter[Loop_rule_no,'LHS']), ","))[[1]][2]),"\\>",sep=""),transactions_df$items)
                                      & !(grepl(paste("\\<",paste(trimws(rules_df_filter[Loop_rule_no,'RHS'])),"\\>",sep=""),transactions_df$items)))))
      
      # Extracting offer suggested by the rule
      Cust_association=as(Cust_association, "data.frame")
      if(NROW(Cust_association)!=0){
        Cust_association$offer <- rules_df_filter[Loop_rule_no,'RHS']
        Cust_association$from <- rules_df_filter[Loop_rule_no,'LHS']
        Cust_association$to <- rules_df_filter[Loop_rule_no,'RHS']
      }
      # Assigning offer suggested by the current rule to the customers which adhere to the
      # conditions and also were not suggested any offer by the previous rules
      Offer_association_temp=Offer_association$Enterprise_Name_cleaned[match(Cust_association$Enterprise_Name_cleaned,Offer_association$Enterprise_Name_cleaned)]
      
      Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                        & (is.na(Offer_association$NBO_Association)),"NBO_Association"] <-
        ifelse(length(Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                        & (is.na(Offer_association$NBO_Association)),"NBO_Association"])>0,
               as.character(Cust_association$offer),Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                                                      & (is.na(Offer_association$NBO_Association)),"NBO_Association"])
      
      Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                        & (is.na(Offer_association$From)),"From"] <-
        ifelse(length(Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                        & (is.na(Offer_association$From)),"From"])>0,
               as.character(Cust_association$from),Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                                                     & (is.na(Offer_association$From)),"From"])
      
      Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                        & (is.na(Offer_association$To)),"To"] <-
        ifelse(length(Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                        & (is.na(Offer_association$To)),"To"])>0,
               as.character(Cust_association$to),Offer_association[(Offer_association$Enterprise_Name_cleaned %in% Offer_association_temp)
                                                                   & (is.na(Offer_association$To)),"To"])
      
      rm(Offer_association_temp)
    }}
}


Offer_association$NBO_Association <- ifelse(Offer_association$From=="SCS" & Offer_association$To=="Dedicated",NA
                                            ,Offer_association$NBO_Association)

Offer_association$From <-ifelse(is.na(Offer_association$NBO_Association),NA,Offer_association$From)

Offer_association$To <-ifelse(is.na(Offer_association$NBO_Association),NA,Offer_association$To)

#--------------------- Suggestion of NBO for customers who bought all ------------------#
#------------------------------ of the associated products -----------------------------#

Clusters <- left_join(Clusters,Enterprise_level[,c("Enterprise_Name_cleaned",as.character(product_names$Hyperion.Sub.Product.Line.Nm))],by = "Enterprise_Name_cleaned")              

Offer_transaction <- left_join(Offer_association,Clusters[,c("Enterprise_Name_cleaned","Segment_ID",as.character(product_names$Hyperion.Sub.Product.Line.Nm))])

Offer_transaction[as.character(product_names$Hyperion.Sub.Product.Line.Nm)] <- sapply(Offer_transaction[as.character(product_names$Hyperion.Sub.Product.Line.Nm)],as.numeric)

# Segment-wise Indexing of products
for (Product_name in as.character(product_names$Hyperion.Sub.Product.Line.Nm)){
  Offer_transaction <- Offer_transaction %>%
    group_by(Segment_ID) %>%
    mutate_(.dots=setNames(paste0("`",Product_name,"`","/sum(`",Product_name,"`)"),Product_name))
}

# Zeros to NA
Offer_transaction[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)][Offer_transaction[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)]==0] <- NA
Rules_for_index <- rules_df


# Filtering out customers who were assigned offer by association rules
Offer_index_conf <- Offer_transaction %>%
  filter(is.na(NBO_Association))

Offer_index_conf=as.data.frame(Offer_index_conf)
Offer_index_conf$NBO_Association<-NULL

# Adding column for offers generated by indexing
Offer_index_conf$NBO_Ind_conf <- NA


# Merging 'items' (product composition)
transactions <- as(as.data.frame(Product_package_all)[,2:(NCOL(Product_package_all)-1)],"transactions")
itemsetInfo(transactions) <- as.data.frame(Product_package_all[,1])
transactions_df<-as(transactions, "data.frame")
colnames(transactions_df)[colnames(transactions_df)=="Product_package_all[, 1]"]<- "Enterprise_Name_cleaned"

Offer_index_conf <- left_join(Offer_index_conf,transactions_df)

# Function to extract best offer (most associated but minimum purchased by the customer)
Ind_Conf_offer <- function (Customer_name,Customer_df=Cust_ind_conf,Rules_df=Offer_select_temp_table) {
  temp_rules_df <- Rules_df
  temp_rules_df$Index=apply(as.data.frame(temp_rules_df[,"RHS"]),1,function(y)
    Customer_df[Customer_df$Enterprise_Name_cleaned==Customer_name,as.character(y)])
  temp_rules_df$Ind_Conf <- temp_rules_df$Index*(1-temp_rules_df$confidence)
  offer=filter(temp_rules_df,Ind_Conf==min(Ind_Conf,na.rm = T))
  return(as.character(unique(offer[,"RHS"])))
}

for(Loop_segment_no in (1:8)){
  
  Offer_index_conf_filter <- Offer_index_conf %>% filter(Segment_ID==Loop_segment_no)
  Rules_for_index_filter <- Rules_for_index %>%
    filter(segmentID==Loop_segment_no) %>%
    arrange(desc(lift))
  
  Loop_rule_no=NROW(Rules_for_index_filter)
  
  while (Loop_rule_no>0) {
    
    # Filtering the customers with the product composition on the left side as well as
    # the right side of the rule
    
    ifelse(length(as.list(strsplit(trimws(Rules_for_index_filter[Loop_rule_no,"LHS"]), ","))[[1]]) == 1,
           (Cust_ind_conf=subset(Offer_index_conf_filter, grepl(paste("\\<",paste(trimws(Rules_for_index_filter[Loop_rule_no,"LHS"])),"\\>",sep=""),Offer_index_conf_filter$items)
                                 & (grepl(paste("\\<",paste(trimws(Rules_for_index_filter[Loop_rule_no,"RHS"])),"\\>",sep=""),Offer_index_conf_filter$items)))),
           (Cust_ind_conf=subset(Offer_index_conf_filter, grepl(paste("\\<",paste(as.list(strsplit(trimws(Rules_for_index_filter[Loop_rule_no,"LHS"]), ","))[[1]][1]),"\\>",sep=""),Offer_index_conf_filter$items)
                                 & grepl(paste("\\<",paste(as.list(strsplit(trimws(Rules_for_index_filter[Loop_rule_no,"LHS"]), ","))[[1]][2]),"\\>",sep=""),Offer_index_conf_filter$items)
                                 & (grepl(paste("\\<",paste(trimws(Rules_for_index_filter[Loop_rule_no,"RHS"])),"\\>",sep=""),Offer_index_conf_filter$items)))))
    
    if (!(NROW(Cust_ind_conf)==0)){
      # Calling 'Ind_Conf_offer' function to extract offer for each customer
      Offer_select_temp_table <- Rules_for_index_filter[,c("RHS","confidence")]
      Cust_ind_conf$NBO_Ind_conf <- apply(as.data.frame(Cust_ind_conf$Enterprise_Name_cleaned),1,function (y)
        Ind_Conf_offer(Customer_name=y,Customer_df=Cust_ind_conf,Rules_df=Offer_select_temp_table))
      
      # Recording extracted offer
      Offer_index_conf$NBO_Ind_conf[match(Cust_ind_conf$Enterprise_Name_cleaned,
                                          Offer_index_conf$Enterprise_Name_cleaned)] <- Cust_ind_conf$NBO_Ind_conf
    }
    Loop_rule_no=Loop_rule_no-1
  }
  print(paste("Segment",Loop_segment_no,"over",sep=" "))
}

Offer_transaction=left_join(Offer_transaction,Offer_index_conf[,c("Enterprise_Name_cleaned","NBO_Ind_conf")])


# min revenue in last six months

Min_revenue <- Datamart_final%>%
  filter(MonthStart>seq(max_date,length=2, by="-6 months")[2])%>%
  group_by(Enterprise_Name_cleaned,Hyperion.Product.Line)%>%
    summarise(Rev= sum(Revenue,na.rm=T))%>%
  filter(Rev>=100)%>%
  group_by(Enterprise_Name_cleaned)%>%
  summarise(total_rev=sum(Rev,na.rm=T))%>%
  filter(total_rev>=600)

Offer_upsell <- Offer_transaction %>% filter(Enterprise_Name_cleaned %in% Min_revenue$Enterprise_Name_cleaned)

# DEDICATED/SCS

#------Dedicated offers----------------------#

# calculation of min lease rev for dedicated

dedicated_customers <- filter(Datamart_final,Hyperion.Product.Line=="RYDER DEDICATED")%>%
  select(Enterprise_Name_cleaned)%>% distinct()

Product_package <- Datamart_final %>%
  filter(Enterprise_Name_cleaned %in% dedicated_customers$Enterprise_Name_cleaned)%>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  arrange(MonthStart,Enterprise_Name_cleaned) %>%
  mutate(Dummy_col=1) %>%
  spread(Hyperion.Sub.Product.Line.Nm,Dummy_col,fill=0)

Product_package$Package=apply(Product_package[,!names(Product_package) %in% 
                                                c('MonthStart','Enterprise_Name_cleaned')], 1,
                              function(x) names(which(x=="1")))

# First Product Package
Enterprise_additional_8 <- Product_package %>%
  group_by(Enterprise_Name_cleaned) %>%
  arrange(Enterprise_Name_cleaned,MonthStart) %>%
  filter(row_number()==1)

colnames(Enterprise_additional_8) <- paste("First_Product", colnames(Enterprise_additional_8), sep = "_")

dedicated_customers<-left_join(dedicated_customers,Enterprise_additional_8 ,by=c("Enterprise_Name_cleaned"="First_Product_Enterprise_Name_cleaned"))

dedicated_customers$First_Product_Package <- vapply(dedicated_customers$First_Product_Package, paste, collapse = ", ", character(1L))

lease_to_dts <- filter(dedicated_customers,(`First_Product_RYDER DEDICATED`==0)& 
                         (`First_Product_CHOICE LEASE`==1))
lease_avg_rev <-Datamart_final%>% filter(Enterprise_Name_cleaned %in% lease_to_dts$Enterprise_Name_cleaned)%>% 
  filter(Hyperion.Sub.Product.Line.Nm=="CHOICE LEASE")%>%
  group_by(Enterprise_Name_cleaned)%>%
  summarise(months=n_distinct(MonthStart),
            revenue= sum(Total.Revenue,na.rm=T))%>%
  mutate(mean_rev=revenue/months)

outliers<- as.data.frame(boxplot.stats(lease_avg_rev$mean_rev)[1])

lease_avg_rev_rm_outliers=filter(lease_avg_rev,mean_rev >= outliers[1,]
                      & mean_rev <= outliers[5,] )

lease_cutoff_rev = mean(lease_avg_rev_rm_outliers$mean_rev)

rm(Enterprise_additional_8,lease_to_dts,Product_package)

# mean lease rev for all customers

lease_rev <-Datamart_final%>% filter(Enterprise_Name_cleaned %in% Clusters$Enterprise_Name_cleaned)%>% 
  filter(Hyperion.Sub.Product.Line.Nm=="CHOICE LEASE")%>%
  group_by(Enterprise_Name_cleaned)%>%
  summarise(months=n_distinct(MonthStart),
            revenue= sum(Total.Revenue,na.rm=T))%>%
  mutate(mean_rev=revenue/months)


# joining mean lease revenue with clusters

Clusters= left_join(Clusters,lease_rev[,c("Enterprise_Name_cleaned","mean_rev")],by="Enterprise_Name_cleaned")


#upsell dedicated

Upsell_cust <- Clusters %>% filter((`CHOICE LEASE`==6 & Segment_ID %in% c("3","4","5") & mean_rev>=lease_cutoff_rev )) %>%
  mutate(Upsell_offer="RYDER DEDICATED")

Offer_upsell=left_join(Offer_upsell,Upsell_cust[,c("Enterprise_Name_cleaned","Upsell_offer")],by="Enterprise_Name_cleaned")

Offer_upsell <- left_join(Offer_upsell,Enterprise_level[,c("Enterprise_Name_cleaned","Ryder_MonthlyFleetCnt", 
                                                           "Final_AnnualSalesRevenue_Used","Marketing.Industry.Grp.Vertical")],
                          by="Enterprise_Name_cleaned")

Offer_upsell[,6:12] <-NULL


#joining last six months flags

Offer_upsell <- left_join(Offer_upsell,Product_last_6,by="Enterprise_Name_cleaned")

Offer_upsell[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)][Offer_upsell[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)]>0] <- 1

Offer_upsell[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)][Offer_upsell[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)]==0] <- NA

Offer_upsell[as.character(product_names$Hyperion.Sub.Product.Line.Nm)] <- sapply(Offer_upsell[as.character(product_names$Hyperion.Sub.Product.Line.Nm)],as.numeric)

# product count in last six months

Offer_upsell$Product_count = rowSums(Offer_upsell[,as.character(product_names$Hyperion.Sub.Product.Line.Nm)],na.rm=TRUE)

# scs dts customers
scs_customers <- filter(Datamart_final,Hyperion.Product.Line=="SUPPLY CHAIN")%>%
  select(Enterprise_Name_cleaned)%>% distinct()
scs_dts_customers <- inner_join(scs_customers,dedicated_customers,by="Enterprise_Name_cleaned")

scs_dts_customers$scs_dts <- 1

Offer_upsell<- left_join(Offer_upsell,scs_dts_customers[,c("Enterprise_Name_cleaned","scs_dts")],by="Enterprise_Name_cleaned")



# Industries previously engaged in dedicated
dedicated_industry <- Datamart_final %>% filter(Hyperion.Product.Line=="RYDER DEDICATED") %>%
  distinct(Marketing.Industry.Grp.Vertical)

# All Industries
all_industry <- Datamart_final %>%select(Marketing.Industry.Grp.Vertical)%>%distinct()

not_dedicated=anti_join(all_industry,dedicated_industry)

Offer_upsell <- Offer_upsell %>% mutate(no_up_sell=ifelse((Marketing.Industry.Grp.Vertical %in% c(c("FOR-HIRE"),
                                    as.character(not_dedicated$Marketing.Industry.Grp.Vertical))
                                    & Upsell_offer =="RYDER DEDICATED" ) | NBO_Association=="SCS" | !(is.na(`RYDER DEDICATED`)),"Revert",NA))

# dedicated offers

Offer_upsell <-Offer_upsell %>% mutate(Next_best_offer= ifelse(is.na(no_up_sell) & !(is.na(Upsell_offer)),"RYDER DEDICATED",
                                                               ifelse(!(is.na(NBO_Association)),NBO_Association,
                                                                      ifelse(!(is.na(NBO_Ind_conf)),NBO_Ind_conf,
                                                                             ifelse(is.na(NBO_Ind_conf) & !(is.na(`USED VEHICLE SALES`)) & Product_count==1,
                                                                                    "CHOICE LEASE/COMMERCIAL RENTAL",ifelse(is.na(NBO_Ind_conf) & !(is.na(`COMMERCIAL RENTAL`))
                                                                                                          & Product_count==1,"CHOICE LEASE","No Offer"))))))

#--------------- offer selection criteria

Offer_upsell$`Offer Selection Criteria` <- ifelse(!is.na(Offer_upsell$NBO_Ind_conf) & (Offer_upsell$Next_best_offer != "RYDER DEDICATED" | 
                                                                                         Offer_upsell$NBO_Ind_conf=="RYDER DEDICATED" ),
                                                  "Product with maximum association and lower purchase",
                                                  ifelse(!is.na(Offer_upsell$NBO_Association)| Offer_upsell$Next_best_offer =="RYDER DEDICATED",
                                                         "Product purchased by similar customers but not opted by this customer in last six months",
                                                         ifelse(Offer_upsell$Next_best_offer=="No Offer","No Offer","Business Logic")))
#-------------------- offer type 
Offer_upsell <- Offer_upsell %>% mutate(offer = ifelse(((Next_best_offer=="CHOICE LEASE" & !(is.na(`COMMERCIAL RENTAL`)) & is.na(`CHOICE LEASE`)) | 
                                                           
                                                          (Next_best_offer == "RYDER DEDICATED"& (!is.na(`CHOICE LEASE`))& is.na(`RYDER DEDICATED`)) |
                                                          (Next_best_offer == "CHOICE LEASE" & !(is.na(`USED VEHICLE SALES`))&is.na(`CHOICE LEASE`))|
                                                          (Next_best_offer == "CHOICE LEASE" & !(is.na(`SELECT CARE CONTRACTUAL`))&is.na(`CHOICE LEASE`))|
                                                        (Next_best_offer=="COMMERCIAL RENTAL" & !(is.na(`USED VEHICLE SALES`)) & Product_count=="1")
                                                        |(Next_best_offer=="CHOICE LEASE/COMMERCIAL RENTAL")
                                                        |(Next_best_offer=="CHOICE LEASE" & !is.na(`COMMERCIAL RENTAL`) & Product_count==1)),"Up-sell",NA))


Offer_upsell$`Offer Type` <- ifelse(Offer_upsell$Next_best_offer != "No Offer"&
                                      (is.na(Offer_upsell$offer)) & Offer_upsell$`Offer Selection Criteria`=="Product with maximum association and lower purchase"
                                    ,"Growth Opportunity",ifelse(Offer_upsell$Next_best_offer != "No Offer"&
                                                                   (is.na(Offer_upsell$offer)),"Cross-Sell" ,Offer_upsell$offer))

Offer_upsell$`Offer Type`<- ifelse(is.na(Offer_upsell$`Offer Type`),"No Offer",Offer_upsell$`Offer Type`)


Offer_upsell$To <-ifelse(Offer_upsell$Next_best_offer=="No Offer",NA,Offer_upsell$To)

Offer_upsell$From <-ifelse(Offer_upsell$Next_best_offer=="No Offer",NA,Offer_upsell$From)

#Seprating name and account ID

enterprise_names <- Datamart_final %>% select(Marketing.Enterprise.Customer.Nm,Enterprise_Name_cleaned)%>% distinct() %>% 
  filter(Enterprise_Name_cleaned %in% as.character(Offer_upsell$Enterprise_Name_cleaned))

Offer_upsell <- left_join(enterprise_names,Offer_upsell,by=c("Enterprise_Name_cleaned"))

# importing location file
location_codes <- read.csv(file = "location-hierachy.csv")
location_codes$Financial.Domicile.Location<-as.character(location_codes$Financial.Domicile.Location)
#unique list of customers and locations

cust_locations <- Datamart_final %>% select(Enterprise_Name_cleaned,Financial.Domicile.Location)%>% distinct()

cust_locations_1 <- left_join(cust_locations,location_codes,by="Financial.Domicile.Location")

cust_locations_1 <- filter(cust_locations_1,!is.na(Hyperion.Domicile.Country))%>% 
  select(Enterprise_Name_cleaned,Hyperion.Domicile.Country)%>%
  distinct()

cust_loc_counts <- cust_locations_1%>% group_by(Enterprise_Name_cleaned)%>%
  summarise(loc_count=n_distinct(Hyperion.Domicile.Country))

cust_loc_counts_1 <- filter(cust_loc_counts,loc_count==1)

cust_loc_counts_1<- left_join(cust_loc_counts_1,cust_locations_1,by="Enterprise_Name_cleaned")

cust_loc_counts_2<-filter(cust_loc_counts,loc_count==2)

cust_loc_counts_2$Hyperion.Domicile.Country="USA/Canada"

final_location<- rbind(cust_loc_counts_2,cust_loc_counts_1)

rm(cust_loc_counts_2,cust_loc_counts_1,cust_loc_counts,cust_locations,location_codes,cust_locations_1)

# joining locations

Offer_upsell <- left_join(Offer_upsell,final_location,by=c("Enterprise_Name_cleaned"))

write.csv(Offer_upsell,"offers_v31July.csv")

# Revenue trend for last 24 months at enterprise level
Revenue_Last_24<- Datamart_final %>% filter(MonthStart %in% seq(max(MonthStart), by= "-1 month",length.out=24))%>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  summarise(Revenue= sum(TotalRev))
Revenue_Last_24<-spread(Revenue_Last_24,key=MonthStart,value=Revenue,fill=0)

test<-as.data.frame(colnames(Revenue_Last_24[,-1]))
test$`colnames(Revenue_Last_24[, -1])`<- format(as.Date(test$`colnames(Revenue_Last_24[, -1])`), "%b'%y")

colnames(Revenue_Last_24)<- c(c("Enterprise_Name_cleaned"),as.character(test$`colnames(Revenue_Last_24[, -1])`))

#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#
#----------------------------------- DATA FOR TOOL -------------------------------------#
#xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx#


Data_tool <-  Offer_upsell[,c("SFDC_AccountID","Final_MasterEnterpriseName_Cleaned","Segment_ID", "active_customers_flag",
                              "Next_best_offer","Offer Type","Offer Selection Criteria",
                              "contract_maint","dedicated","on_demand",
                              "Lease","Rental","SCS","uvs","Product_count",
                              "ToprevSic_Industry_Vertical_grouped","Final_AnnualSalesRevenue_Used",
                              "MarketPower_FleetCnt","Ryder_MonthlyFleetCnt")]
              


Data_tool[, as.character(product_names$NewProductLine)][is.na(Data_tool[, as.character(product_names$NewProductLine)])] <- 0


# Ordering Columns

Data_tool$Final_AnnualSalesRevenue_Used[Data_tool$Final_AnnualSalesRevenue_Used==0]<-NA

colnames(Data_tool)[colnames(Data_tool) == "SFDC_AccountID"] <- "Enterprise_Name_cleaned"
colnames(Data_tool)[colnames(Data_tool) == "Next_best_offer"] <- "Next Best Offer"
colnames(Data_tool)[colnames(Data_tool) == "Segment_ID"] <- "Segment ID"
colnames(Data_tool)[colnames(Data_tool) == "active_customers_flag"] <- "Active Customer Flag"
colnames(Data_tool)[colnames(Data_tool) == "contract_maint"] <- "Select Care"
colnames(Data_tool)[colnames(Data_tool) == "uvs"] <- "UVS"
colnames(Data_tool)[colnames(Data_tool) == "Lease"] <- "ChoiceLease"
colnames(Data_tool)[colnames(Data_tool) == "dedicated"] <- "Dedicated"
colnames(Data_tool)[colnames(Data_tool) == "on_demand"] <- "On Demand"
colnames(Data_tool)[colnames(Data_tool) == "Product_count"] <- "Product Count"
colnames(Data_tool)[colnames(Data_tool) == "ToprevSic_Industry_Vertical_grouped"] <- "Industry"
colnames(Data_tool)[colnames(Data_tool) == "Ryder_MonthlyFleetCnt"] <- "Total Ryder Fleet"
colnames(Data_tool)[colnames(Data_tool) == "Final_AnnualSalesRevenue_Used"] <- "Annual Sales"
colnames(Data_tool)[colnames(Data_tool) == "MarketPower_FleetCnt"] <- "Market Power Fleet Count"


Data_tool<-left_join(Data_tool,Revenue_Last_24,by="Enterprise_Name_cleaned")

colnames(Data_tool)[colnames(Data_tool) == "Enterprise_Name_cleaned"] <- "SFDC_AccountID"

Data_tool <- as.data.frame(Data_tool)

#save(Data_tool,file = "Datasets/Data_Tool.RData")

# Separate files for active and inactive customers
active<- Data_tool%>% filter(`Active Customer Flag`=="Active")%>%
  arrange(Final_MasterEnterpriseName_Cleaned)
active<- active[,c(2,4,16,1,3,17,15,19,18,5,6,7,20:43)]


inactive <- Data_tool%>%filter(`Active Customer Flag`=="Inactive")%>%
  arrange(Final_MasterEnterpriseName_Cleaned)
inactive<- inactive[,c(2,4,16,1,3,17,15,19,18,5,6,7,20:43)]

write.csv(active,"Output/active.csv")
write.csv(inactive,"Output/inactive.csv")


# exporting output

Data_tool<- as.data.frame(Data_tool)
Data_tool <- Data_tool%>%  arrange(Final_MasterEnterpriseName_Cleaned)
Data_tool<- Data_tool[,c(1:19)]

write.csv(Data_tool,"Output/consolidated.csv")
#------------------------------ EDA Summary data for tool ------------------------------#

# Revenue distribution
monthly_revenue <- as.data.frame(Datamart_final) %>%
  group_by(Year,MonthStart)%>%
  summarise(Revenue= sum(TotalRev,na.rm=TRUE))
monthly_revenue$MonthStart<- format(as.Date(monthly_revenue$MonthStart), "%m")

monthly_revenue<-spread(monthly_revenue,key=Year,value =Revenue)
write.csv(monthly_revenue,"Output/monthly_revenue.csv")

# Product-wise Revenue trend
product_revenue <- Datamart_final %>%
  group_by(Year,MonthStart)%>%
  summarise(ChoiceLease= sum(CL_Rev[LeaseCust_WithRev==1],na.rm=T),
            Rental= sum(CR_Rev[Rental_Cust_WithRev==1],na.rm=T),
            SCS= sum(SCS.Revenue[SCS_Cust_WithRev==1],na.rm=T),
            Dedicated_revenue= sum(DTS.Revenue[DTS_Cust_WithRev==1],na.rm=T),
            UVS= sum(UVS_Proceeds[UVS_Cust_WithProceeds==1],na.rm=T),
            SelectCare= sum(SC_Rev[Maint_Cust_WithRev==1],na.rm=T),
            'On Demand'= sum(SC_ODM_Rev[Ondemand_Cust_WithRev==1],na.rm=T))
product_revenue$MonthStart<- format(as.Date(product_revenue$MonthStart), "%m")

write.csv(product_revenue,"Output/product_revene.csv")


# Industry revenue
industry_revenue <- as.data.frame(Enterprise_level) %>%
  group_by(ToprevSic_Industry_Vertical_grouped)%>%
  summarise(Revenue = sum(Revenue,na.rm= TRUE),
            x=0,
            y=0,
            `No. of Customers` = n_distinct(Enterprise_Name_cleaned))%>%
  arrange(desc(Revenue))%>%
  filter(!is.na(ToprevSic_Industry_Vertical_grouped))

write.csv(industry_revenue,"Output/industry_revenue.csv")

Sys.time()

#XXXXXXXXXXXXXXXXXXXXXXXXXXX
# -------UVS
#XXXXXXXXXXXXXXXXXXXXXXXXXXX
uvs_customers  <- filter(Datamart_final,Hyperion.Product.Line=="UVS" & 
                           MonthStart > (seq(max(Datamart_final$MonthStart), by= "-30 month",length.out=2)[2]))%>%
  select(Enterprise_Name_cleaned)%>% distinct()

uvs_customer_data <- filter(Datamart_final,Enterprise_Name_cleaned %in% 
                              (uvs_customers$Enterprise_Name_cleaned))

number_of_products <- uvs_customer_data %>% group_by(Enterprise_Name_cleaned)%>%
  summarise(count=n_distinct(Hyperion.Product.Line))


#-------------Company - Product Average Gap
Average_product_gap <- uvs_customer_data %>%
  group_by(Enterprise_Name_cleaned,MonthStart)%>%
  distinct(Hyperion.Sub.Product.Line.Nm) %>%
  arrange(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm,MonthStart) %>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm) %>%
  mutate(from_date=lag(MonthStart),to_date=MonthStart) %>%
  group_by(Enterprise_Name_cleaned,MonthStart,Hyperion.Sub.Product.Line.Nm) %>%
  mutate(Company_product_ave_gap=ifelse(is.na(from_date),NA,length(seq(from=from_date,to=to_date,by='month'))-1)) %>%
  group_by(Enterprise_Name_cleaned,Hyperion.Sub.Product.Line.Nm) %>%
  summarise(Company_product_ave_gap=mean(Company_product_ave_gap,na.rm=TRUE)) %>%
  filter(Hyperion.Sub.Product.Line.Nm=="USED VEHICLE SALES")

# check <- filter(Average_product_gap, is.na(Company_product_ave_gap))
# 
# check_2 <- Datamart_final%>% filter((Enterprise_Name_cleaned %in% check$Enterprise_Name_cleaned)&
#   Hyperion.Sub.Product.Line.Nm=="USED VEHICLE SALES")
# 
# check_3 <- check_2 %>% group_by(Enterprise_Name_cleaned)%>%
#     summarise(months=n_distinct(MonthStart))


# Time from last transaction of the customer
Enterprise_additional_16 <- Datamart_final%>%
  filter((Enterprise_Name_cleaned %in% Average_product_gap$Enterprise_Name_cleaned)&
          Hyperion.Sub.Product.Line.Nm=="USED VEHICLE SALES")%>%
  group_by(Enterprise_Name_cleaned)%>%
  select(Enterprise_Name_cleaned,MonthStart)%>%
  summarise(last_engagment_date= max(MonthStart))

end_date <- max(Datamart_final$MonthStart)

Enterprise_additional_16$months_from_last_engagment = sapply(Enterprise_additional_16$last_engagment_date,
                                                             function(start_date) {
                                                               ed <- as.POSIXlt(end_date)
                                                               sd <- as.POSIXlt(start_date)
                                                               12 * (ed$year - sd$year) + (ed$mon - sd$mon)})

average_uvs_gap <- left_join(Average_product_gap, Enterprise_additional_16,by="Enterprise_Name_cleaned")

# No of engagment months of customer (for the period of 2014-till date)
Engagement_months <- Datamart_final %>%
  filter((Enterprise_Name_cleaned %in% Average_product_gap$Enterprise_Name_cleaned)&
           Hyperion.Sub.Product.Line.Nm=="USED VEHICLE SALES")%>%
  group_by(Enterprise_Name_cleaned,MonthStart) %>%
  distinct() %>%
  arrange(Enterprise_Name_cleaned,MonthStart) %>%
  group_by(Enterprise_Name_cleaned) %>%
  summarise(No_of_months=length(Enterprise_Name_cleaned))

average_uvs_gap <- left_join(average_uvs_gap, Engagement_months,by="Enterprise_Name_cleaned")

#Seprating name and account ID

enterprise_names <- Datamart_final %>% select(Marketing.Enterprise.Customer.Nm,Enterprise_Name_cleaned)%>% distinct() %>% 
  filter(Enterprise_Name_cleaned %in% as.character(average_uvs_gap$Enterprise_Name_cleaned))


average_uvs_gap <- left_join(average_uvs_gap,enterprise_names,by="Enterprise_Name_cleaned")

write.csv(average_uvs_gap,file = "average_uvs_gap.csv")
