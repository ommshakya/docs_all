path = "D:\\z.Oms\\Learn.R\\Analytics Vidhya - Tutorial"
setwd(path)
getwd()

#Load Datasets
train <- read.csv("Train_UWu5bXk.csv")
test <- read.csv("Test_u94Q5KV.csv")

#check dimesions ( number of row & columns) in data set
dim(train)
dim(test)

#check the variables and their types in train
str(train)
str(test)

#first check if this data has missing values
table(is.na(train))

colSums(is.na(train))


summary(train)

#Here are some quick inferences drawn from variables in train data set:
  
#Item_Fat_Content has mis-matched factor levels.
#Minimum value of item_visibility is 0. Practically, this is not possible. If an item occupies shelf space in a grocery store, it ought to have some visibility. We'll treat all 0's as missing values.
#Item_Weight has 1463 missing values (already explained above).
#Outlet_Size has a unmatched factor levels.
#These inference will help us in treating these variable more accurately.

#Graphical Representation of Variables
#For visualization, I'll use ggplot2 package. These graphs would help us understand the distribution and frequency of variables in the data set.

ggplot(train, aes(x= Item_Visibility, y = Item_Outlet_Sales)) + geom_point(size = 2.5, color="navy") + xlab("Item Visibility") + ylab("Item Outlet Sales") + ggtitle("Item Visibility vs Item Outlet Sales")

#We can see that majority of sales has been obtained from products having visibility less than 0.2. This suggests that item_visibility < 2 must be an important factor in determining sales

#Let's plot few more interesting graphs and explore such hidden stories.
ggplot(train, aes(Outlet_Identifier, Item_Outlet_Sales)) + geom_bar(stat = "identity", color = "purple") +theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "black"))  + ggtitle("Outlets vs Total Sales") + theme_bw()

#Here, we infer that OUT027 has contributed to majority of sales followed by OUT35. OUT10 and OUT19 have probably the least footfall, thereby contributing to the least outlet sales.

ggplot(train, aes(Item_Type, Item_Outlet_Sales)) + geom_bar( stat = "identity") +theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "navy")) + xlab("Item Type") + ylab("Item Outlet Sales")+ggtitle("Item Type vs Sales")

#From this graph, we can infer that Fruits and Vegetables contribute to the highest amount of outlet sales followed by snack foods and household products. This information can also be represented using a box plot chart. The benefit of using a box plot is, you get to see the outlier and mean deviation of corresponding levels of a variable (shown below).
ggplot(train, aes(Item_Type, Item_MRP)) +geom_boxplot() +ggtitle("Box Plot") + theme(axis.text.x = element_text(angle = 70, vjust = 0.5, color = "red")) + xlab("Item Type") + ylab("Item MRP") + ggtitle("Item Type vs Item MRP")

#The black point you see, is an outlier. The mid line you see in the box, is the mean value of each item type


#Now, we have an idea of the variables and their importance on response variable. Let's now move back to where we started. Missing values. Now we'll impute the missing values.
#We saw variable Item_Weight has missing values. Item_Weight is an continuous variable. Hence, in this case we can impute missing values with mean / median of item_weight.
#Let's first combine the data sets.

dim(train)
dim(test)

#Test data set has one less column (response variable). Let's first add the column. We can give this column any value.
test$Item_Outlet_Sales <-  1
combi <- rbind(train, test)
dim(combi)

#Impute missing value by median. I'm using median because it is known to be highly robust to outliers
combi$Item_Weight[is.na(combi$Item_Weight)] <- median(combi$Item_Weight, na.rm = TRUE)
table(is.na(combi$Item_Weight))


#Trouble with Continuous Variables & Categorical Variables
str(combi)
#It's important to learn to deal with continuous and categorical variables separately in a data set. In other words, they need special attention. In this data set, we have only 3 continuous variables and rest are categorical in nature. If you are still confused, I'll suggest you to once again look at the data set using str() and proceed.
#Let's take up Item_Visibility. In the graph above, we saw item visibility has zero value also, which is practically not feasible. Hence, we'll consider it as a missing value and once again make the imputation using median.

combi$Item_Visibility <- ifelse(combi$Item_Visibility == 0, median(combi$Item_Visibility), combi$Item_Visibility) 
str(combi)

#Let's proceed to categorical variables now. During exploration, we saw there are mis-matched levels in variables 
# which needs to be corrected.
levels(combi$Outlet_Size)
levels(combi$Outlet_Size)[1] <- "Other"
levels(combi$Outlet_Size)


#library(plyr)
levels(combi$Item_Fat_Content)
combi$Item_Fat_Content <- revalue(combi$Item_Fat_Content, c("LF" = "Low Fat", "reg" = "Regular"))
combi$Item_Fat_Content <- revalue(combi$Item_Fat_Content, c("low fat" = "Low Fat"))
levels(combi$Item_Fat_Content)
table(combi$Item_Fat_Content)

#Note: Using the commands above, I've assigned the name 'Other' to unnamed level in Outlet_Size variable. Rest, I've simply renamed the various levels of Item_Fat_Content.

####### 4. Data Manipulation in R #########
levels(combi$Outlet_Identifier)
library(dplyr)
a <- combi %>% group_by(Outlet_Identifier) %>% tally()
head(a)

names(a)[2] <- "Outlet_Count"
combi <- full_join(a, combi, by = "Outlet_Identifier")
#head(combi)

b <- combi %>% group_by(Item_Identifier)%>% tally()

names(b)[2] <- "Item_Count"
b


combi <- merge(b, combi, by = "Item_Identifier")
str(combi)
head(combi)


c <- combi %>% select(Outlet_Establishment_Year) %>% mutate(Outlet_Year = 2013 - combi$Outlet_Establishment_Year)
head(c)
combi <- full_join(c, combi)

############# 4. Item Type New  #########

q <- substr(combi$Item_Identifier,1,2)
q <- gsub("FD","Food",q)
q <- gsub("DR","Drinks",q)
q <- gsub("NC","Non-Consumable",q)
table(q)

combi$Item_Type_New <- q
str(combi)
combi$Item_Fat_Content <- ifelse(combi$Item_Fat_Content == "Regular",1,0)
