# Linear Regression Project
setwd("D:\\z.Oms\\Learn.R\\R-Course-HTML-Notes\\R-Course-HTML-Notes\\R-for-Data-Science-and-Machine-Learning\\Training Exercises\\Machine Learning Projects\\CSV files for ML Projects")
getwd()

######################## Get the data ########################
# Read in bikeshare.csv file and set it to a dataframe called bike.
bike = read.csv('bikeshare.csv')

# Check the head of df
head(bike)

# Can you figure out what is the target we are trying to predict? Check the Kaggle Link above if you are confused on this.
# COUNT is what we are trying to predict

######################## Exploratory Data Analysis ########################
# Create a scatter plot of count vs temp. Set a good alpha value.
library(ggplot2)
ggplot(bike, aes(temp, count)) + geom_point(alpha = 0.2, aes(color = temp)) + theme_bw()

# Plot count versus datetime as a scatterplot with a color gradient based on temperature. 
# You'll need to convert the datetime column into POSIXct before plotting.

bike$datetime <- as.POSIXct(bike$datetime)
ggplot(bike, aes(datetime, count)) + geom_point(alpha = 0.5, aes(color = temp)) + scale_color_continuous(low = '#55D8CE', high = '#FF6E2E') + theme_bw()

# Hopefully you noticed two things: A seasonality to the data, for winter and summer. Also that bike rental counts 
# are increasing in general. This may present a problem with using a linear regression model if the data is non-linear. 

# What is the correlation between temp and count?
cor(bike[,c('temp','count')])

# Let's explore the season data. Create a boxplot, with the y axis indicating count and the x axis begin a box for each season.
ggplot(bike, aes(factor(season), count)) + geom_boxplot(aes(color = factor(season))) + theme_bw()

# Notice what this says:
#  A line can't capture a non-linear relationship.
#There are more rentals in winter than in spring
#We know of these issues because of the growth of rental count, this isn't due to the actual season!

######################## Feature Engineering ########################
# Create an "hour" column that takes the hour from the datetime column.

bike$hour <- sapply(bike$datetime,function(x){format(x,"%H")})
#bike$hour = format(bike$datetime, "%H")
head(bike)

# Now create a scatterplot of count versus hour, with color scale based on temp. Only use bike data where workingday==1.
library(dplyr)
pl <- ggplot(filter(bike, workingday == 1), aes(hour, count)) 
pl <- pl + geom_point(position = position_jitter(w = 1, h = 0), aes(color = temp), alpha = 0.5)
pl <- pl + scale_color_gradientn(colours = c('dark blue','blue','light blue','light green','yellow','orange','red'))
pl + theme_bw()

# Now create the same plot for non working days:
pl <- ggplot(filter(bike, workingday == 0), aes(hour, count)) 
pl <- pl + geom_point(position = position_jitter(w = 1, h = 0), aes(color = temp), alpha = 0.8)
pl <- pl + scale_color_gradientn(colours = c('dark blue','blue','light blue','light green','yellow','orange','red'))
pl + theme_bw()

# You should have noticed that working days have peak activity during the morning (~8am) and 
# right after work gets out (~5pm), with some lunchtime activity. While the non-work days 
# have a steady rise and fall for the afternoon

### Now let's continue by trying to build a model, we'll begin by just looking at a single feature.

######################## Building the Model ########################
# Use lm() to build a model that predicts count based solely on the temp feature, name it temp.model
temp.model <- lm(count ~ temp, bike)

# Get the summary of the temp.model
summary(temp.model)

#How many bike rentals would we predict if the temperature was 25 degrees Celsius? Calculate this two ways:
#  Using the values we just got above
#  Using the predict() function

## Method 1
6.0462 + 9.1705 * 25

## Method 2
temp.test <- data.frame(temp = c(25))
predict(temp.model, temp.test)

# Use sapply() and as.numeric to change the hour column to a column of numeric values.
bike$hour <- sapply(bike$hour, as.numeric)

# Finally build a model that attempts to predict count based off of the following features. 
# Figure out if theres a way to not have to pass/write all these variables into the lm() function. 
# Hint: StackOverflow or Google may be quicker than the documentation.
#season
#holiday
#workingday
#weather
#temp
#humidity
#windspeed
#hour (factor)

#str(bike)

model <- lm(count ~ . -casual - registered - datetime - atemp - hour_om, bike)
summary(model)










