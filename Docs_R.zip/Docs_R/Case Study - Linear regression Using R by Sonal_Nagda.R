#Get and Set the working directory

getwd()
setwd('D:\\z.Oms\\Learn.R\\Case Study - Linear regression Using R by Sonal_Nagda')
getwd()

#read the csv data file
data1 = read.csv('cs1data1.csv', header = T, sep =',')

#check the column names of the data
names(data1)

#check the characteristics of columns/variables
str(data1)

#Transform "LOCATION" variable into factor
data1$LOCATION = as.factor(data1$LOCATION)

#Again check the characteristics of columns/variables
str(data1)

#attach the data to avoid full name for example, instead of 
#data1$LOCATION you can use LOCATION only
attach(data1)


####Data Exploration##########
#The first step, before undertaking any statistical analysis, is to explore the data.
summary(data1)


aggregate(data.frame(TOTALM = TOTALM), by = list(LOCATION),mean)
aggregate(data.frame(TOTALM = TOTALM), by = list(LOCATION),sd)
aggregate(data.frame(TOTALM = TOTALM), by = list(LOCATION),min)
aggregate(data.frame(TOTALM = TOTALM), by = list(LOCATION),max)
aggregate(data.frame(TOTALM = TOTALM), by = list(LOCATION),median) 

#To view the differences in variation in milk offtakes use the commands below to produce a boxplot:
boxplot(TOTALM~LOCATION, col="orange",xlab="Location", ylab="Milk offtake (litres)")


#A boxplot illustrates the differences in variation in milk offtakes in Bilisa and Asssa. It shows three
#outliers for Bilisa ( Location 1) and one for Assa (Location 2).
#One can see the four outliers (but not as clearly) in a scatter plot, produced using the following
#commands:

psymb=as.numeric(LOCATION)
plot(TOTALM~AGEC,pch=psymb,xlab="Age of calf", ylab="Milk offtake (litres)")
legend("top","center",legend = c("Bisila","Assa"),pch=1:2,bty="n") 


#The graph shows the different patterns between the milk offtake and age of the calf for the two
#locations. These patterns support the use of a multiple regression analysis to describe different intercepts
#on the y-axis for the two locations and potential differing slopes. 


########## 4. Statistical modelling  #############

#The first step in the analysis of the milk offtake is to fit a regression with a term to describe a common
#slope for the pattern (AGEC) and a term to allow separate intercepts (LOCATION) on the y-axis for the
#location. We can do this by fitting these two parameters (AGEC, LOCATION) using the commands:

fm2 = lm(TOTALM ~ LOCATION + AGEC)
fm2
summary(fm2)

LOCATIONB = (ifelse(LOCATION == 1, "Bilisa", "Assa"))
fm3 = lm(TOTALM~LOCATIONB + AGEC)
fm3
summary(fm3)

#The next step is to investigate whether non-parallel lines would better represent the data. This is
#achieved by fitting an interaction in the model (LOCATIONB*AGEC). In this case we will also request
#for the accumulated analysis of variance (ANOVA) to be shown:

fm4 = lm(TOTALM ~ LOCATIONB + AGEC + LOCATIONB * AGEC)
fm4
summary(fm4)
anova(fm4)

#Similarly, we can run the model with Bisila (Location 1) as the reference level:
fm5 = lm(TOTALM ~ LOCATION + AGEC + LOCATION * AGEC)
fm5
summary(fm5)


#To plot the fitted two regression lines use the commands:
psymb = as.numeric(LOCATION)
plot(TOTALM ~ AGEC, pch = psymb, xlab = "Age of calf", ylab = "Milk offtake (litres)")
abline(lm(TOTALM ~ AGEC, subset = LOCATION == 1))
abline(lm(TOTALM ~ AGEC, subset = LOCATION == 2), lty = 2)
legend("topright", legend = c("Bisila","Assa"),pch = 1:2,lty = 1:2,bty = "n")

#The output shows how milk offtake decreases with stage of lactation for cows residing in Bisila but not
#at Assa where milk offtakes remain low throughout the lactation.


#Findings, implications and lessons learned
#Regression analysis
#. There is a difference in mean milk offtake between cows sampled in Bilisa and Assa.
#. Milk offtake declined with age of calf (or stage of lactation) at Bilisa but not at Assa.
#. Patterns in the data suggest that certain observations may have been influential in determining
#the fitted patterns and that there were others that there were others that possibly did not belong to
#the overall pattern.
#. Switching the order in which the factor LOCATION is coded, i.e. redefining the reference level,
#allows the standard errors for both levels to be easily extracted.
